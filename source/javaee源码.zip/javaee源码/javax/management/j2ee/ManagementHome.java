// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ManagementHome.java

package javax.management.j2ee;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

// Referenced classes of package javax.management.j2ee:
//			Management

public interface ManagementHome
	extends EJBHome
{

	public abstract Management create()
		throws CreateException, RemoteException;
}
