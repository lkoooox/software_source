// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Management.java

package javax.management.j2ee;

import java.rmi.RemoteException;
import java.util.Set;
import javax.ejb.EJBObject;
import javax.management.*;

// Referenced classes of package javax.management.j2ee:
//			ListenerRegistration

public interface Management
	extends EJBObject
{

	public abstract Set queryNames(ObjectName objectname, QueryExp queryexp)
		throws RemoteException;

	public abstract boolean isRegistered(ObjectName objectname)
		throws RemoteException;

	public abstract Integer getMBeanCount()
		throws RemoteException;

	public abstract MBeanInfo getMBeanInfo(ObjectName objectname)
		throws IntrospectionException, InstanceNotFoundException, ReflectionException, RemoteException;

	public abstract Object getAttribute(ObjectName objectname, String s)
		throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, RemoteException;

	public abstract AttributeList getAttributes(ObjectName objectname, String as[])
		throws InstanceNotFoundException, ReflectionException, RemoteException;

	public abstract void setAttribute(ObjectName objectname, Attribute attribute)
		throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, RemoteException;

	public abstract AttributeList setAttributes(ObjectName objectname, AttributeList attributelist)
		throws InstanceNotFoundException, ReflectionException, RemoteException;

	public abstract Object invoke(ObjectName objectname, String s, Object aobj[], String as[])
		throws InstanceNotFoundException, MBeanException, ReflectionException, RemoteException;

	public abstract String getDefaultDomain()
		throws RemoteException;

	public abstract ListenerRegistration getListenerRegistry()
		throws RemoteException;
}
