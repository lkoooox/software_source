// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JMSProducerStats.java

package javax.management.j2ee.statistics;


// Referenced classes of package javax.management.j2ee.statistics:
//			JMSEndpointStats

public interface JMSProducerStats
	extends JMSEndpointStats
{

	public abstract String getDestination();
}
