// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JDBCConnectionPoolStats.java

package javax.management.j2ee.statistics;


// Referenced classes of package javax.management.j2ee.statistics:
//			JDBCConnectionStats, CountStatistic, BoundedRangeStatistic, RangeStatistic

public interface JDBCConnectionPoolStats
	extends JDBCConnectionStats
{

	public abstract CountStatistic getCreateCount();

	public abstract CountStatistic getCloseCount();

	public abstract BoundedRangeStatistic getPoolSize();

	public abstract BoundedRangeStatistic getFreePoolSize();

	public abstract RangeStatistic getWaitingThreadCount();
}
