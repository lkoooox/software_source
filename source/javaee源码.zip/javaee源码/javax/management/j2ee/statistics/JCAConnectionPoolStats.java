// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JCAConnectionPoolStats.java

package javax.management.j2ee.statistics;


// Referenced classes of package javax.management.j2ee.statistics:
//			JCAConnectionStats, CountStatistic, BoundedRangeStatistic, RangeStatistic

public interface JCAConnectionPoolStats
	extends JCAConnectionStats
{

	public abstract CountStatistic getCloseCount();

	public abstract CountStatistic getCreateCount();

	public abstract BoundedRangeStatistic getFreePoolSize();

	public abstract BoundedRangeStatistic getPoolSize();

	public abstract RangeStatistic getWaitingThreadCount();
}
