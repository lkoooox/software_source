// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JMSSessionStats.java

package javax.management.j2ee.statistics;


// Referenced classes of package javax.management.j2ee.statistics:
//			Stats, JMSProducerStats, JMSConsumerStats, CountStatistic, 
//			TimeStatistic

public interface JMSSessionStats
	extends Stats
{

	public abstract JMSProducerStats[] getProducers();

	public abstract JMSConsumerStats[] getConsumers();

	public abstract CountStatistic getMessageCount();

	public abstract CountStatistic getPendingMessageCount();

	public abstract CountStatistic getExpiredMessageCount();

	public abstract TimeStatistic getMessageWaitTime();

	public abstract CountStatistic getDurableSubscriptionCount();
}
