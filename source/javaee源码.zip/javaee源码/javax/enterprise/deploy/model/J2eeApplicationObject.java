// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   J2eeApplicationObject.java

package javax.enterprise.deploy.model;

import javax.enterprise.deploy.shared.ModuleType;

// Referenced classes of package javax.enterprise.deploy.model:
//			DeployableObject, DDBean, XpathListener

public interface J2eeApplicationObject
	extends DeployableObject
{

	public abstract DeployableObject getDeployableObject(String s);

	public abstract DeployableObject[] getDeployableObjects(ModuleType moduletype);

	public abstract DeployableObject[] getDeployableObjects();

	public abstract String[] getModuleUris(ModuleType moduletype);

	public abstract String[] getModuleUris();

	public abstract DDBean[] getChildBean(ModuleType moduletype, String s);

	public abstract String[] getText(ModuleType moduletype, String s);

	public abstract void addXpathListener(ModuleType moduletype, String s, XpathListener xpathlistener);

	public abstract void removeXpathListener(ModuleType moduletype, String s, XpathListener xpathlistener);
}
