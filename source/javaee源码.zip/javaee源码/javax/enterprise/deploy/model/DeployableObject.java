// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DeployableObject.java

package javax.enterprise.deploy.model;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Enumeration;
import javax.enterprise.deploy.model.exceptions.DDBeanCreateException;
import javax.enterprise.deploy.shared.ModuleType;

// Referenced classes of package javax.enterprise.deploy.model:
//			DDBeanRoot, DDBean

public interface DeployableObject
{

	public abstract ModuleType getType();

	public abstract DDBeanRoot getDDBeanRoot();

	public abstract DDBean[] getChildBean(String s);

	public abstract String[] getText(String s);

	public abstract Class getClassFromScope(String s);

	/**
	 * @deprecated Method getModuleDTDVersion is deprecated
	 */

	public abstract String getModuleDTDVersion();

	public abstract DDBeanRoot getDDBeanRoot(String s)
		throws FileNotFoundException, DDBeanCreateException;

	public abstract Enumeration entries();

	public abstract InputStream getEntry(String s);
}
