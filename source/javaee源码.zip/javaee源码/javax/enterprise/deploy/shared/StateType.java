// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   StateType.java

package javax.enterprise.deploy.shared;


public class StateType
{

	private int value;
	public static final StateType RUNNING;
	public static final StateType COMPLETED;
	public static final StateType FAILED;
	public static final StateType RELEASED;
	private static final String stringTable[] = {
		"running", "completed", "failed", "released"
	};
	private static final StateType enumValueTable[];

	protected StateType(int value)
	{
		this.value = value;
	}

	public int getValue()
	{
		return value;
	}

	protected String[] getStringTable()
	{
		return stringTable;
	}

	protected StateType[] getEnumValueTable()
	{
		return enumValueTable;
	}

	public static StateType getStateType(int value)
	{
		return enumValueTable[value];
	}

	public String toString()
	{
		String strTable[] = getStringTable();
		int index = value - getOffset();
		if (strTable != null && index >= 0 && index < strTable.length)
			return strTable[index];
		else
			return Integer.toString(value);
	}

	protected int getOffset()
	{
		return 0;
	}

	static 
	{
		RUNNING = new StateType(0);
		COMPLETED = new StateType(1);
		FAILED = new StateType(2);
		RELEASED = new StateType(3);
		enumValueTable = (new StateType[] {
			RUNNING, COMPLETED, FAILED, RELEASED
		});
	}
}
