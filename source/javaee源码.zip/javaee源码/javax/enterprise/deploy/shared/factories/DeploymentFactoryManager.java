// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DeploymentFactoryManager.java

package javax.enterprise.deploy.shared.factories;

import java.util.Vector;
import javax.enterprise.deploy.spi.DeploymentManager;
import javax.enterprise.deploy.spi.exceptions.DeploymentManagerCreationException;
import javax.enterprise.deploy.spi.factories.DeploymentFactory;

public final class DeploymentFactoryManager
{

	private Vector deploymentFactories;
	private static DeploymentFactoryManager deploymentFactoryManager = null;

	private DeploymentFactoryManager()
	{
		deploymentFactories = null;
		deploymentFactories = new Vector();
	}

	public static DeploymentFactoryManager getInstance()
	{
		if (deploymentFactoryManager == null)
			deploymentFactoryManager = new DeploymentFactoryManager();
		return deploymentFactoryManager;
	}

	public DeploymentFactory[] getDeploymentFactories()
	{
		Vector deploymentFactoriesSnapShot = null;
		synchronized (this)
		{
			deploymentFactoriesSnapShot = (Vector)deploymentFactories.clone();
		}
		DeploymentFactory factoriesArray[] = new DeploymentFactory[deploymentFactoriesSnapShot.size()];
		deploymentFactoriesSnapShot.copyInto(factoriesArray);
		return factoriesArray;
	}

	public DeploymentManager getDeploymentManager(String uri, String username, String password)
		throws DeploymentManagerCreationException
	{
		DeploymentFactory factories[];
		int factoryIndex;
		factories = getDeploymentFactories();
		factoryIndex = 0;
_L1:
		if (factoryIndex >= factories.length)
			break MISSING_BLOCK_LABEL_51;
		if (factories[factoryIndex].handlesURI(uri))
			return factories[factoryIndex].getDeploymentManager(uri, username, password);
		factoryIndex++;
		  goto _L1
		throw new DeploymentManagerCreationException((new StringBuilder()).append("URL [").append(uri).append("] not supported by any available factories").toString());
		Throwable t;
		t;
		throw new DeploymentManagerCreationException("Could not get DeploymentManager");
	}

	public void registerDeploymentFactory(DeploymentFactory factory)
	{
		deploymentFactories.add(factory);
	}

	public DeploymentManager getDisconnectedDeploymentManager(String uri)
		throws DeploymentManagerCreationException
	{
		DeploymentFactory factories[];
		int factoryIndex;
		factories = getDeploymentFactories();
		factoryIndex = 0;
_L1:
		if (factoryIndex >= factories.length)
			break MISSING_BLOCK_LABEL_41;
		if (factories[factoryIndex].handlesURI(uri))
			return factories[factoryIndex].getDisconnectedDeploymentManager(uri);
		factoryIndex++;
		  goto _L1
		throw new DeploymentManagerCreationException((new StringBuilder()).append("URL [").append(uri).append("] not supported by any available factories").toString());
		Throwable t;
		t;
		throw new DeploymentManagerCreationException("Could not get DeploymentManager");
	}

}
