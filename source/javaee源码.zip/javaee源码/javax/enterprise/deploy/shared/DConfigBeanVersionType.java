// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DConfigBeanVersionType.java

package javax.enterprise.deploy.shared;


public class DConfigBeanVersionType
{

	private int value;
	public static final DConfigBeanVersionType V1_3;
	public static final DConfigBeanVersionType V1_3_1;
	public static final DConfigBeanVersionType V1_4;
	public static final DConfigBeanVersionType V5;
	private static final String stringTable[] = {
		"V1_3", "V1_3_1", "V1_4", "V5"
	};
	private static final DConfigBeanVersionType enumValueTable[];

	protected DConfigBeanVersionType(int value)
	{
		this.value = value;
	}

	public int getValue()
	{
		return value;
	}

	protected String[] getStringTable()
	{
		return stringTable;
	}

	protected DConfigBeanVersionType[] getEnumValueTable()
	{
		return enumValueTable;
	}

	public static DConfigBeanVersionType getDConfigBeanVersionType(int value)
	{
		return enumValueTable[value];
	}

	public String toString()
	{
		String strTable[] = getStringTable();
		int index = value - getOffset();
		if (strTable != null && index >= 0 && index < strTable.length)
			return strTable[index];
		else
			return Integer.toString(value);
	}

	protected int getOffset()
	{
		return 0;
	}

	static 
	{
		V1_3 = new DConfigBeanVersionType(0);
		V1_3_1 = new DConfigBeanVersionType(1);
		V1_4 = new DConfigBeanVersionType(2);
		V5 = new DConfigBeanVersionType(3);
		enumValueTable = (new DConfigBeanVersionType[] {
			V1_3, V1_3_1, V1_4, V5
		});
	}
}
