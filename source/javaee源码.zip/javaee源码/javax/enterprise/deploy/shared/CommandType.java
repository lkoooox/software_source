// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   CommandType.java

package javax.enterprise.deploy.shared;


public class CommandType
{

	private int value;
	public static final CommandType DISTRIBUTE;
	public static final CommandType START;
	public static final CommandType STOP;
	public static final CommandType UNDEPLOY;
	public static final CommandType REDEPLOY;
	private static final String stringTable[] = {
		"distribute", "start", "stop", "undeploy", "redeploy"
	};
	private static final CommandType enumValueTable[];

	protected CommandType(int value)
	{
		this.value = value;
	}

	public int getValue()
	{
		return value;
	}

	protected String[] getStringTable()
	{
		return stringTable;
	}

	protected CommandType[] getEnumValueTable()
	{
		return enumValueTable;
	}

	public static CommandType getCommandType(int value)
	{
		return enumValueTable[value];
	}

	public String toString()
	{
		String strTable[] = getStringTable();
		int index = value - getOffset();
		if (strTable != null && index >= 0 && index < strTable.length)
			return strTable[index];
		else
			return Integer.toString(value);
	}

	protected int getOffset()
	{
		return 0;
	}

	static 
	{
		DISTRIBUTE = new CommandType(0);
		START = new CommandType(1);
		STOP = new CommandType(2);
		UNDEPLOY = new CommandType(3);
		REDEPLOY = new CommandType(4);
		enumValueTable = (new CommandType[] {
			DISTRIBUTE, START, STOP, UNDEPLOY, REDEPLOY
		});
	}
}
