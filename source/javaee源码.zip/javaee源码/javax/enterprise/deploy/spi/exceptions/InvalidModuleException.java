// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   InvalidModuleException.java

package javax.enterprise.deploy.spi.exceptions;


public class InvalidModuleException extends Exception
{

	public InvalidModuleException(String s)
	{
		super(s);
	}
}
