// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TargetException.java

package javax.enterprise.deploy.spi.exceptions;


public class TargetException extends Exception
{

	public TargetException(String s)
	{
		super(s);
	}
}
