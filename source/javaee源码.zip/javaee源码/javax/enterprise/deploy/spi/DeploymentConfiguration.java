// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DeploymentConfiguration.java

package javax.enterprise.deploy.spi;

import java.io.InputStream;
import java.io.OutputStream;
import javax.enterprise.deploy.model.DDBeanRoot;
import javax.enterprise.deploy.model.DeployableObject;
import javax.enterprise.deploy.spi.exceptions.BeanNotFoundException;
import javax.enterprise.deploy.spi.exceptions.ConfigurationException;

// Referenced classes of package javax.enterprise.deploy.spi:
//			DConfigBeanRoot

public interface DeploymentConfiguration
{

	public abstract DeployableObject getDeployableObject();

	public abstract DConfigBeanRoot getDConfigBeanRoot(DDBeanRoot ddbeanroot)
		throws ConfigurationException;

	public abstract void removeDConfigBean(DConfigBeanRoot dconfigbeanroot)
		throws BeanNotFoundException;

	public abstract DConfigBeanRoot restoreDConfigBean(InputStream inputstream, DDBeanRoot ddbeanroot)
		throws ConfigurationException;

	public abstract void saveDConfigBean(OutputStream outputstream, DConfigBeanRoot dconfigbeanroot)
		throws ConfigurationException;

	public abstract void restore(InputStream inputstream)
		throws ConfigurationException;

	public abstract void save(OutputStream outputstream)
		throws ConfigurationException;
}
