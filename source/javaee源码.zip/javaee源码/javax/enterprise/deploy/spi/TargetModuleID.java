// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TargetModuleID.java

package javax.enterprise.deploy.spi;


// Referenced classes of package javax.enterprise.deploy.spi:
//			Target

public interface TargetModuleID
{

	public abstract Target getTarget();

	public abstract String getModuleID();

	public abstract String getWebURL();

	public abstract String toString();

	public abstract TargetModuleID getParentTargetModuleID();

	public abstract TargetModuleID[] getChildTargetModuleID();
}
