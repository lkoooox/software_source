// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ProgressEvent.java

package javax.enterprise.deploy.spi.status;

import java.util.EventObject;
import javax.enterprise.deploy.spi.TargetModuleID;

// Referenced classes of package javax.enterprise.deploy.spi.status:
//			DeploymentStatus

public class ProgressEvent extends EventObject
{

	private DeploymentStatus statuscode;
	private TargetModuleID targetModuleID;

	public ProgressEvent(Object source, TargetModuleID targetModuleID, DeploymentStatus sCode)
	{
		super(source);
		statuscode = sCode;
		this.targetModuleID = targetModuleID;
	}

	public TargetModuleID getTargetModuleID()
	{
		return targetModuleID;
	}

	public DeploymentStatus getDeploymentStatus()
	{
		return statuscode;
	}
}
