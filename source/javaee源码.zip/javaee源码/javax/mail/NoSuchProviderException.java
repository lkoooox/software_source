// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   NoSuchProviderException.java

package javax.mail;


// Referenced classes of package javax.mail:
//			MessagingException

public class NoSuchProviderException extends MessagingException
{

	private static final long serialVersionUID = 0x6fd4e6b3cb29cd5bL;

	public NoSuchProviderException()
	{
	}

	public NoSuchProviderException(String message)
	{
		super(message);
	}
}
