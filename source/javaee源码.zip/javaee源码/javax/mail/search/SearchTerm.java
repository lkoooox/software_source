// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SearchTerm.java

package javax.mail.search;

import java.io.Serializable;
import javax.mail.Message;

public abstract class SearchTerm
	implements Serializable
{

	private static final long serialVersionUID = 0xa3ae133bc1b1c4abL;

	public SearchTerm()
	{
	}

	public abstract boolean match(Message message);
}
