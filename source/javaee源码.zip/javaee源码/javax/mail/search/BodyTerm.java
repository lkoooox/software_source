// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BodyTerm.java

package javax.mail.search;

import javax.mail.*;

// Referenced classes of package javax.mail.search:
//			StringTerm

public final class BodyTerm extends StringTerm
{

	private static final long serialVersionUID = 0xbc27456ee3cb54e7L;

	public BodyTerm(String pattern)
	{
		super(pattern);
	}

	public boolean match(Message msg)
	{
		return matchPart(msg);
	}

	private boolean matchPart(Part p)
	{
		String s;
		if (!p.isMimeType("text/*"))
			break MISSING_BLOCK_LABEL_33;
		s = (String)p.getContent();
		if (s == null)
			return false;
		return super.match(s);
		Multipart mp;
		int count;
		int i;
		if (!p.isMimeType("multipart/*"))
			break MISSING_BLOCK_LABEL_92;
		mp = (Multipart)p.getContent();
		count = mp.getCount();
		i = 0;
_L1:
		if (i >= count)
			break MISSING_BLOCK_LABEL_121;
		if (matchPart(((Part) (mp.getBodyPart(i)))))
			return true;
		i++;
		  goto _L1
		if (p.isMimeType("message/rfc822"))
			return matchPart((Part)p.getContent());
		break MISSING_BLOCK_LABEL_121;
		Exception ex;
		ex;
		return false;
	}

	public boolean equals(Object obj)
	{
		if (!(obj instanceof BodyTerm))
			return false;
		else
			return super.equals(obj);
	}
}
