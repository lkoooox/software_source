// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   AddressStringTerm.java

package javax.mail.search;

import javax.mail.Address;
import javax.mail.internet.InternetAddress;

// Referenced classes of package javax.mail.search:
//			StringTerm

public abstract class AddressStringTerm extends StringTerm
{

	private static final long serialVersionUID = 0x2ad6978ecdebb490L;

	protected AddressStringTerm(String pattern)
	{
		super(pattern, true);
	}

	protected boolean match(Address a)
	{
		if (a instanceof InternetAddress)
		{
			InternetAddress ia = (InternetAddress)a;
			return super.match(ia.toUnicodeString());
		} else
		{
			return super.match(a.toString());
		}
	}

	public boolean equals(Object obj)
	{
		if (!(obj instanceof AddressStringTerm))
			return false;
		else
			return super.equals(obj);
	}
}
