// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HeaderTerm.java

package javax.mail.search;

import javax.mail.Message;

// Referenced classes of package javax.mail.search:
//			StringTerm

public final class HeaderTerm extends StringTerm
{

	protected String headerName;
	private static final long serialVersionUID = 0x73c690dfba9d2142L;

	public HeaderTerm(String headerName, String pattern)
	{
		super(pattern);
		this.headerName = headerName;
	}

	public String getHeaderName()
	{
		return headerName;
	}

	public boolean match(Message msg)
	{
		String headers[];
		try
		{
			headers = msg.getHeader(headerName);
		}
		catch (Exception e)
		{
			return false;
		}
		if (headers == null)
			return false;
		for (int i = 0; i < headers.length; i++)
			if (super.match(headers[i]))
				return true;

		return false;
	}

	public boolean equals(Object obj)
	{
		if (!(obj instanceof HeaderTerm))
		{
			return false;
		} else
		{
			HeaderTerm ht = (HeaderTerm)obj;
			return ht.headerName.equalsIgnoreCase(headerName) && super.equals(ht);
		}
	}

	public int hashCode()
	{
		return headerName.toLowerCase().hashCode() + super.hashCode();
	}
}
