// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FolderAdapter.java

package javax.mail.event;


// Referenced classes of package javax.mail.event:
//			FolderListener, FolderEvent

public abstract class FolderAdapter
	implements FolderListener
{

	public FolderAdapter()
	{
	}

	public void folderCreated(FolderEvent folderevent)
	{
	}

	public void folderRenamed(FolderEvent folderevent)
	{
	}

	public void folderDeleted(FolderEvent folderevent)
	{
	}
}
