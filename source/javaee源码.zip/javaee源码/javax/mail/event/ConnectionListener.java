// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ConnectionListener.java

package javax.mail.event;

import java.util.EventListener;

// Referenced classes of package javax.mail.event:
//			ConnectionEvent

public interface ConnectionListener
	extends EventListener
{

	public abstract void opened(ConnectionEvent connectionevent);

	public abstract void disconnected(ConnectionEvent connectionevent);

	public abstract void closed(ConnectionEvent connectionevent);
}
