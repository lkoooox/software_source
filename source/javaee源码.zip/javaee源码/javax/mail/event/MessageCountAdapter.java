// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageCountAdapter.java

package javax.mail.event;


// Referenced classes of package javax.mail.event:
//			MessageCountListener, MessageCountEvent

public abstract class MessageCountAdapter
	implements MessageCountListener
{

	public MessageCountAdapter()
	{
	}

	public void messagesAdded(MessageCountEvent messagecountevent)
	{
	}

	public void messagesRemoved(MessageCountEvent messagecountevent)
	{
	}
}
