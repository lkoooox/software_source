// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransportAdapter.java

package javax.mail.event;


// Referenced classes of package javax.mail.event:
//			TransportListener, TransportEvent

public abstract class TransportAdapter
	implements TransportListener
{

	public TransportAdapter()
	{
	}

	public void messageDelivered(TransportEvent transportevent)
	{
	}

	public void messageNotDelivered(TransportEvent transportevent)
	{
	}

	public void messagePartiallyDelivered(TransportEvent transportevent)
	{
	}
}
