// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FolderListener.java

package javax.mail.event;

import java.util.EventListener;

// Referenced classes of package javax.mail.event:
//			FolderEvent

public interface FolderListener
	extends EventListener
{

	public abstract void folderCreated(FolderEvent folderevent);

	public abstract void folderDeleted(FolderEvent folderevent);

	public abstract void folderRenamed(FolderEvent folderevent);
}
