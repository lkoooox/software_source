// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   StoreClosedException.java

package javax.mail;


// Referenced classes of package javax.mail:
//			MessagingException, Store

public class StoreClosedException extends MessagingException
{

	private transient Store store;
	private static final long serialVersionUID = 0xd4595255d6538f21L;

	public StoreClosedException(Store store)
	{
		this(store, null);
	}

	public StoreClosedException(Store store, String message)
	{
		super(message);
		this.store = store;
	}

	public Store getStore()
	{
		return store;
	}
}
