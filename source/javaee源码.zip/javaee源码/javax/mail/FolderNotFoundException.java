// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FolderNotFoundException.java

package javax.mail;


// Referenced classes of package javax.mail:
//			MessagingException, Folder

public class FolderNotFoundException extends MessagingException
{

	private transient Folder folder;
	private static final long serialVersionUID = 0x68f0e358302dafbL;

	public FolderNotFoundException()
	{
	}

	public FolderNotFoundException(Folder folder)
	{
		this.folder = folder;
	}

	public FolderNotFoundException(Folder folder, String s)
	{
		super(s);
		this.folder = folder;
	}

	public FolderNotFoundException(String s, Folder folder)
	{
		super(s);
		this.folder = folder;
	}

	public Folder getFolder()
	{
		return folder;
	}
}
