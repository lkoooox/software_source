// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BodyPart.java

package javax.mail;


// Referenced classes of package javax.mail:
//			Part, Multipart

public abstract class BodyPart
	implements Part
{

	protected Multipart parent;

	public BodyPart()
	{
	}

	public Multipart getParent()
	{
		return parent;
	}

	void setParent(Multipart parent)
	{
		this.parent = parent;
	}
}
