// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ByteArrayDataSource.java

package javax.mail.util;

import java.io.*;
import javax.activation.DataSource;
import javax.mail.internet.*;

public class ByteArrayDataSource
	implements DataSource
{

	private byte data[];
	private String type;
	private String name;

	public ByteArrayDataSource(InputStream is, String type)
		throws IOException
	{
		name = "";
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		byte buf[] = new byte[8192];
		int len;
		while ((len = is.read(buf)) > 0) 
			os.write(buf, 0, len);
		data = os.toByteArray();
		this.type = type;
	}

	public ByteArrayDataSource(byte data[], String type)
	{
		name = "";
		this.data = data;
		this.type = type;
	}

	public ByteArrayDataSource(String data, String type)
		throws IOException
	{
		name = "";
		String charset = null;
		try
		{
			ContentType ct = new ContentType(type);
			charset = ct.getParameter("charset");
		}
		catch (ParseException pex) { }
		if (charset == null)
			charset = MimeUtility.getDefaultJavaCharset();
		this.data = data.getBytes(charset);
		this.type = type;
	}

	public InputStream getInputStream()
		throws IOException
	{
		if (data == null)
			throw new IOException("no data");
		else
			return new ByteArrayInputStream(data);
	}

	public OutputStream getOutputStream()
		throws IOException
	{
		throw new IOException("cannot do this");
	}

	public String getContentType()
	{
		return type;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}
}
