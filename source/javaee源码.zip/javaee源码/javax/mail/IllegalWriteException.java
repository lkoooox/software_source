// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   IllegalWriteException.java

package javax.mail;


// Referenced classes of package javax.mail:
//			MessagingException

public class IllegalWriteException extends MessagingException
{

	private static final long serialVersionUID = 0x3727cca9375f0eedL;

	public IllegalWriteException()
	{
	}

	public IllegalWriteException(String s)
	{
		super(s);
	}
}
