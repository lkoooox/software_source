// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   AuthenticationFailedException.java

package javax.mail;


// Referenced classes of package javax.mail:
//			MessagingException

public class AuthenticationFailedException extends MessagingException
{

	private static final long serialVersionUID = 0x6d438d6b238969fL;

	public AuthenticationFailedException()
	{
	}

	public AuthenticationFailedException(String message)
	{
		super(message);
	}
}
