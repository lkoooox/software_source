// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParameterList.java

package javax.mail.internet;

import java.io.UnsupportedEncodingException;
import java.util.*;

// Referenced classes of package javax.mail.internet:
//			HeaderTokenizer, MimeUtility, ParseException

public class ParameterList
{
	private static class ParamEnum
		implements Enumeration
	{

		private Iterator it;

		public boolean hasMoreElements()
		{
			return it.hasNext();
		}

		public Object nextElement()
		{
			return it.next();
		}

		ParamEnum(Iterator it)
		{
			this.it = it;
		}
	}

	private static class Value
	{

		String value;
		String encodedValue;

		private Value()
		{
		}

	}


	private Map list;
	private static boolean encodeParameters = false;
	private static boolean decodeParameters = false;
	private static boolean decodeParametersStrict = false;
	private static final char hex[] = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
		'A', 'B', 'C', 'D', 'E', 'F'
	};

	public ParameterList()
	{
		list = new LinkedHashMap();
	}

	public ParameterList(String s)
		throws ParseException
	{
		list = new LinkedHashMap();
		HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
		do
		{
			HeaderTokenizer.Token tk = h.next();
			int type = tk.getType();
			if (type == -4)
				return;
			if ((char)type == ';')
			{
				tk = h.next();
				if (tk.getType() == -4)
					return;
				if (tk.getType() != -1)
					throw new ParseException("Expected parameter name, got \"" + tk.getValue() + "\"");
				String name = tk.getValue().toLowerCase();
				tk = h.next();
				if ((char)tk.getType() != '=')
					throw new ParseException("Expected '=', got \"" + tk.getValue() + "\"");
				tk = h.next();
				type = tk.getType();
				if (type != -1 && type != -2)
					throw new ParseException("Expected parameter value, got \"" + tk.getValue() + "\"");
				String value = tk.getValue();
				if (decodeParameters && name.endsWith("*"))
				{
					name = name.substring(0, name.length() - 1);
					list.put(name, decodeValue(value));
				} else
				{
					list.put(name, value);
				}
			} else
			{
				throw new ParseException("Expected ';', got \"" + tk.getValue() + "\"");
			}
		} while (true);
	}

	public int size()
	{
		return list.size();
	}

	public String get(String name)
	{
		Object v = list.get(name.trim().toLowerCase());
		String value;
		if (v instanceof Value)
			value = ((Value)v).value;
		else
			value = (String)v;
		return value;
	}

	public void set(String name, String value)
	{
		list.put(name.trim().toLowerCase(), value);
	}

	public void set(String name, String value, String charset)
	{
		if (encodeParameters)
		{
			Value ev = encodeValue(value, charset);
			if (ev != null)
				list.put(name.trim().toLowerCase(), ev);
			else
				set(name, value);
		} else
		{
			set(name, value);
		}
	}

	public void remove(String name)
	{
		list.remove(name.trim().toLowerCase());
	}

	public Enumeration getNames()
	{
		return new ParamEnum(list.keySet().iterator());
	}

	public String toString()
	{
		return toString(0);
	}

	public String toString(int used)
	{
		StringBuffer sb = new StringBuffer();
		for (Iterator e = list.keySet().iterator(); e.hasNext();)
		{
			String name = (String)e.next();
			Object v = list.get(name);
			String value;
			if (v instanceof Value)
			{
				value = ((Value)v).encodedValue;
				name = name + '*';
			} else
			{
				value = (String)v;
			}
			value = quote(value);
			sb.append("; ");
			used += 2;
			int len = name.length() + value.length() + 1;
			if (used + len > 76)
			{
				sb.append("\r\n\t");
				used = 8;
			}
			sb.append(name).append('=');
			used += name.length() + 1;
			if (used + value.length() > 76)
			{
				String s = MimeUtility.fold(used, value);
				sb.append(s);
				int lastlf = s.lastIndexOf('\n');
				if (lastlf >= 0)
					used += s.length() - lastlf - 1;
				else
					used += s.length();
			} else
			{
				sb.append(value);
				used += value.length();
			}
		}

		return sb.toString();
	}

	private String quote(String value)
	{
		return MimeUtility.quote(value, "()<>@,;:\\\"\t []/?=");
	}

	private Value encodeValue(String value, String charset)
	{
		if (MimeUtility.checkAscii(value) == 1)
			return null;
		byte b[];
		try
		{
			b = value.getBytes(MimeUtility.javaCharset(charset));
		}
		catch (UnsupportedEncodingException ex)
		{
			return null;
		}
		StringBuffer sb = new StringBuffer(b.length + charset.length() + 2);
		sb.append(charset).append("''");
		for (int i = 0; i < b.length; i++)
		{
			char c = (char)(b[i] & 0xff);
			if (c <= ' ' || c >= '\177' || c == '*' || c == '\'' || c == '%' || "()<>@,;:\\\"\t []/?=".indexOf(c) >= 0)
				sb.append('%').append(hex[c >> 4]).append(hex[c & 0xf]);
			else
				sb.append(c);
		}

		Value v = new Value();
		v.value = value;
		v.encodedValue = sb.toString();
		return v;
	}

	private Value decodeValue(String value)
		throws ParseException
	{
		Value v;
		v = new Value();
		v.encodedValue = value;
		v.value = value;
		int i;
		i = value.indexOf('\'');
		if (i > 0)
			break MISSING_BLOCK_LABEL_65;
		if (decodeParametersStrict)
			throw new ParseException("Missing charset in encoded value: " + value);
		return v;
		String charset;
		int li;
		charset = value.substring(0, i);
		li = value.indexOf('\'', i + 1);
		if (li >= 0)
			break MISSING_BLOCK_LABEL_124;
		if (decodeParametersStrict)
			throw new ParseException("Missing language in encoded value: " + value);
		return v;
		try
		{
			String lang = value.substring(i + 1, li);
			value = value.substring(li + 1);
			byte b[] = new byte[value.length()];
			i = 0;
			int bi = 0;
			for (; i < value.length(); i++)
			{
				char c = value.charAt(i);
				if (c == '%')
				{
					String hex = value.substring(i + 1, i + 3);
					c = (char)Integer.parseInt(hex, 16);
					i += 2;
				}
				b[bi++] = (byte)c;
			}

			v.value = new String(b, 0, bi, MimeUtility.javaCharset(charset));
		}
		catch (NumberFormatException nex)
		{
			if (decodeParametersStrict)
				throw new ParseException(nex.toString());
		}
		catch (UnsupportedEncodingException uex)
		{
			if (decodeParametersStrict)
				throw new ParseException(uex.toString());
		}
		catch (StringIndexOutOfBoundsException ex)
		{
			if (decodeParametersStrict)
				throw new ParseException(ex.toString());
		}
		return v;
	}

	static 
	{
		try
		{
			String s = System.getProperty("mail.mime.encodeparameters");
			encodeParameters = s != null && s.equalsIgnoreCase("true");
			s = System.getProperty("mail.mime.decodeparameters");
			decodeParameters = s != null && s.equalsIgnoreCase("true");
			s = System.getProperty("mail.mime.decodeparameters.strict");
			decodeParametersStrict = s != null && s.equalsIgnoreCase("true");
		}
		catch (SecurityException sex) { }
	}
}
