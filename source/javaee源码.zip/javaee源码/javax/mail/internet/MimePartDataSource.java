// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MimePartDataSource.java

package javax.mail.internet;

import java.io.*;
import java.net.UnknownServiceException;
import javax.activation.DataSource;
import javax.mail.*;

// Referenced classes of package javax.mail.internet:
//			ContentType, MimeBodyPart, MimeMessage, MimePart, 
//			MimeUtility, ParseException

public class MimePartDataSource
	implements DataSource, MessageAware
{

	protected MimePart part;
	private MessageContext context;
	private static boolean ignoreMultipartEncoding = true;

	public MimePartDataSource(MimePart part)
	{
		this.part = part;
	}

	public InputStream getInputStream()
		throws IOException
	{
		InputStream is;
		String encoding;
		if (part instanceof MimeBodyPart)
			is = ((MimeBodyPart)part).getContentStream();
		else
		if (part instanceof MimeMessage)
			is = ((MimeMessage)part).getContentStream();
		else
			throw new MessagingException("Unknown part");
		encoding = restrictEncoding(part.getEncoding(), part);
		if (encoding != null)
			return MimeUtility.decode(is, encoding);
		return is;
		MessagingException mex;
		mex;
		throw new IOException(mex.getMessage());
	}

	private static String restrictEncoding(String encoding, MimePart part)
		throws MessagingException
	{
		String type;
		if (!ignoreMultipartEncoding || encoding == null)
			return encoding;
		if (encoding.equalsIgnoreCase("7bit") || encoding.equalsIgnoreCase("8bit") || encoding.equalsIgnoreCase("binary"))
			return encoding;
		type = part.getContentType();
		if (type == null)
			return encoding;
		ContentType cType = new ContentType(type);
		if (cType.match("multipart/*") || cType.match("message/*"))
			return null;
		break MISSING_BLOCK_LABEL_87;
		ParseException pex;
		pex;
		return encoding;
	}

	public OutputStream getOutputStream()
		throws IOException
	{
		throw new UnknownServiceException();
	}

	public String getContentType()
	{
		return part.getContentType();
		MessagingException mex;
		mex;
		return null;
	}

	public String getName()
	{
		if (part instanceof MimeBodyPart)
			return ((MimeBodyPart)part).getFileName();
		break MISSING_BLOCK_LABEL_25;
		MessagingException mex;
		mex;
		return "";
	}

	public synchronized MessageContext getMessageContext()
	{
		if (context == null)
			context = new MessageContext(part);
		return context;
	}

	static 
	{
		try
		{
			String s = System.getProperty("mail.mime.ignoremultipartencoding");
			ignoreMultipartEncoding = s == null || !s.equalsIgnoreCase("false");
		}
		catch (SecurityException sex) { }
	}
}
