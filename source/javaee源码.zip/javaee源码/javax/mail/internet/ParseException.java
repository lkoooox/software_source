// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseException.java

package javax.mail.internet;

import javax.mail.MessagingException;

public class ParseException extends MessagingException
{

	private static final long serialVersionUID = 0x6a2a3a783fd59869L;

	public ParseException()
	{
	}

	public ParseException(String s)
	{
		super(s);
	}
}
