// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MimeMultipart.java

package javax.mail.internet;

import com.sun.mail.util.*;
import java.io.*;
import java.util.Vector;
import javax.activation.DataSource;
import javax.mail.*;

// Referenced classes of package javax.mail.internet:
//			ContentType, InternetHeaders, MimeBodyPart, SharedInputStream, 
//			UniqueValue

public class MimeMultipart extends Multipart
{

	private static boolean ignoreMissingEndBoundary = true;
	private static boolean ignoreMissingBoundaryParameter = true;
	private static boolean bmparse = true;
	protected DataSource ds;
	protected boolean parsed;
	private boolean complete;
	private String preamble;

	public MimeMultipart()
	{
		this("mixed");
	}

	public MimeMultipart(String subtype)
	{
		ds = null;
		parsed = true;
		complete = true;
		preamble = null;
		String boundary = UniqueValue.getUniqueBoundaryValue();
		ContentType cType = new ContentType("multipart", subtype, null);
		cType.setParameter("boundary", boundary);
		contentType = cType.toString();
	}

	public MimeMultipart(DataSource ds)
		throws MessagingException
	{
		this.ds = null;
		parsed = true;
		complete = true;
		preamble = null;
		if (ds instanceof MessageAware)
		{
			MessageContext mc = ((MessageAware)ds).getMessageContext();
			setParent(mc.getPart());
		}
		if (ds instanceof MultipartDataSource)
		{
			setMultipartDataSource((MultipartDataSource)ds);
			return;
		} else
		{
			parsed = false;
			this.ds = ds;
			contentType = ds.getContentType();
			return;
		}
	}

	public synchronized void setSubType(String subtype)
		throws MessagingException
	{
		ContentType cType = new ContentType(contentType);
		cType.setSubType(subtype);
		contentType = cType.toString();
	}

	public synchronized int getCount()
		throws MessagingException
	{
		parse();
		return super.getCount();
	}

	public synchronized BodyPart getBodyPart(int index)
		throws MessagingException
	{
		parse();
		return super.getBodyPart(index);
	}

	public synchronized BodyPart getBodyPart(String CID)
		throws MessagingException
	{
		parse();
		int count = getCount();
		for (int i = 0; i < count; i++)
		{
			MimeBodyPart part = (MimeBodyPart)getBodyPart(i);
			String s = part.getContentID();
			if (s != null && s.equals(CID))
				return part;
		}

		return null;
	}

	public boolean isComplete()
		throws MessagingException
	{
		parse();
		return complete;
	}

	public String getPreamble()
		throws MessagingException
	{
		parse();
		return preamble;
	}

	public void setPreamble(String preamble)
		throws MessagingException
	{
		this.preamble = preamble;
	}

	protected void updateHeaders()
		throws MessagingException
	{
		for (int i = 0; i < parts.size(); i++)
			((MimeBodyPart)parts.elementAt(i)).updateHeaders();

	}

	public void writeTo(OutputStream os)
		throws IOException, MessagingException
	{
		parse();
		String boundary = "--" + (new ContentType(contentType)).getParameter("boundary");
		LineOutputStream los = new LineOutputStream(os);
		if (preamble != null)
		{
			byte pb[] = ASCIIUtility.getBytes(preamble);
			los.write(pb);
			if (pb.length > 0 && pb[pb.length - 1] != 13 && pb[pb.length - 1] != 10)
				los.writeln();
		}
		for (int i = 0; i < parts.size(); i++)
		{
			los.writeln(boundary);
			((MimeBodyPart)parts.elementAt(i)).writeTo(os);
			los.writeln();
		}

		los.writeln(boundary + "--");
	}

	protected synchronized void parse()
		throws MessagingException
	{
		InputStream in;
		Exception exception;
		if (parsed)
			return;
		if (bmparse)
		{
			parsebm();
			return;
		}
		in = null;
		SharedInputStream sin = null;
		long start = 0L;
		long end = 0L;
		try
		{
			in = ds.getInputStream();
			if (!(in instanceof ByteArrayInputStream) && !(in instanceof BufferedInputStream) && !(in instanceof SharedInputStream))
				in = new BufferedInputStream(in);
		}
		catch (Exception ex)
		{
			throw new MessagingException("No inputstream from datasource");
		}
		if (in instanceof SharedInputStream)
			sin = (SharedInputStream)in;
		ContentType cType = new ContentType(contentType);
		String boundary = null;
		String bp = cType.getParameter("boundary");
		if (bp != null)
			boundary = "--" + bp;
		else
		if (!ignoreMissingBoundaryParameter)
			throw new MessagingException("Missing boundary parameter");
		try
		{
			LineInputStream lin = new LineInputStream(in);
			String lineSeparator = null;
			String line;
			do
			{
				if ((line = lin.readLine()) == null)
					break;
				int i = line.length() - 1;
				do
				{
					if (i < 0)
						break;
					char c = line.charAt(i);
					if (c != ' ' && c != '\t')
						break;
					i--;
				} while (true);
				line = line.substring(0, i + 1);
				if (boundary != null)
				{
					if (line.equals(boundary))
						break;
				} else
				if (line.startsWith("--"))
				{
					boundary = line;
					break;
				}
				if (line.length() > 0)
				{
					if (lineSeparator == null)
						try
						{
							lineSeparator = System.getProperty("line.separator", "\n");
						}
						catch (SecurityException ex)
						{
							lineSeparator = "\n";
						}
					if (preamble == null)
						preamble = line + lineSeparator;
					else
						preamble += line + lineSeparator;
				}
			} while (true);
			if (line == null)
				throw new MessagingException("Missing start boundary");
			byte bndbytes[] = ASCIIUtility.getBytes(boundary);
			int bl = bndbytes.length;
			boolean done = false;
			while (!done) 
			{
				InternetHeaders headers = null;
				if (sin != null)
				{
					start = sin.getPosition();
					while ((line = lin.readLine()) != null && line.length() > 0) ;
					if (line == null)
					{
						if (!ignoreMissingEndBoundary)
							throw new MessagingException("missing multipart end boundary");
						complete = false;
						break;
					}
				} else
				{
					headers = createInternetHeaders(in);
				}
				if (!in.markSupported())
					throw new MessagingException("Stream doesn't support mark");
				ByteArrayOutputStream buf = null;
				if (sin == null)
					buf = new ByteArrayOutputStream();
				else
					end = sin.getPosition();
				boolean bol = true;
				int eol1 = -1;
				int eol2 = -1;
				do
				{
					if (bol)
					{
						in.mark(bl + 4 + 1000);
						int i;
						for (i = 0; i < bl && in.read() == (bndbytes[i] & 0xff); i++);
						if (i == bl)
						{
							int b2 = in.read();
							if (b2 == 45 && in.read() == 45)
							{
								complete = true;
								done = true;
								break;
							}
							for (; b2 == 32 || b2 == 9; b2 = in.read());
							if (b2 == 10)
								break;
							if (b2 == 13)
							{
								in.mark(1);
								if (in.read() != 10)
									in.reset();
								break;
							}
						}
						in.reset();
						if (buf != null && eol1 != -1)
						{
							buf.write(eol1);
							if (eol2 != -1)
								buf.write(eol2);
							eol1 = eol2 = -1;
						}
					}
					int b;
					if ((b = in.read()) < 0)
					{
						if (!ignoreMissingEndBoundary)
							throw new MessagingException("missing multipart end boundary");
						complete = false;
						done = true;
						break;
					}
					if (b == 13 || b == 10)
					{
						bol = true;
						if (sin != null)
							end = sin.getPosition() - 1L;
						eol1 = b;
						if (b == 13)
						{
							in.mark(1);
							if ((b = in.read()) == 10)
								eol2 = b;
							else
								in.reset();
						}
					} else
					{
						bol = false;
						if (buf != null)
							buf.write(b);
					}
				} while (true);
				MimeBodyPart part;
				if (sin != null)
					part = createMimeBodyPart(sin.newStream(start, end));
				else
					part = createMimeBodyPart(headers, buf.toByteArray());
				addBodyPart(part);
			}
		}
		catch (IOException ioex)
		{
			throw new MessagingException("IO Error", ioex);
		}
		finally { }
		try
		{
			in.close();
		}
		catch (IOException cex) { }
		break MISSING_BLOCK_LABEL_948;
		try
		{
			in.close();
		}
		catch (IOException cex) { }
		throw exception;
		parsed = true;
		return;
	}

	private synchronized void parsebm()
		throws MessagingException
	{
		InputStream in;
		Exception exception;
		if (parsed)
			return;
		in = null;
		SharedInputStream sin = null;
		long start = 0L;
		long end = 0L;
		try
		{
			in = ds.getInputStream();
			if (!(in instanceof ByteArrayInputStream) && !(in instanceof BufferedInputStream) && !(in instanceof SharedInputStream))
				in = new BufferedInputStream(in);
		}
		catch (Exception ex)
		{
			throw new MessagingException("No inputstream from datasource");
		}
		if (in instanceof SharedInputStream)
			sin = (SharedInputStream)in;
		ContentType cType = new ContentType(contentType);
		String boundary = null;
		String bp = cType.getParameter("boundary");
		if (bp != null)
			boundary = "--" + bp;
		else
		if (!ignoreMissingBoundaryParameter)
			throw new MessagingException("Missing boundary parameter");
		try
		{
			LineInputStream lin = new LineInputStream(in);
			String lineSeparator = null;
			String line;
			do
			{
				if ((line = lin.readLine()) == null)
					break;
				int i = line.length() - 1;
				do
				{
					if (i < 0)
						break;
					char c = line.charAt(i);
					if (c != ' ' && c != '\t')
						break;
					i--;
				} while (true);
				line = line.substring(0, i + 1);
				if (boundary != null)
				{
					if (line.equals(boundary))
						break;
				} else
				if (line.startsWith("--"))
				{
					boundary = line;
					break;
				}
				if (line.length() > 0)
				{
					if (lineSeparator == null)
						try
						{
							lineSeparator = System.getProperty("line.separator", "\n");
						}
						catch (SecurityException ex)
						{
							lineSeparator = "\n";
						}
					if (preamble == null)
						preamble = line + lineSeparator;
					else
						preamble += line + lineSeparator;
				}
			} while (true);
			if (line == null)
				throw new MessagingException("Missing start boundary");
			byte bndbytes[] = ASCIIUtility.getBytes(boundary);
			int bl = bndbytes.length;
			int bcs[] = new int[256];
			for (int i = 0; i < bl; i++)
				bcs[bndbytes[i]] = i + 1;

			int gss[] = new int[bl];
label0:
			for (int i = bl; i > 0; i--)
			{
				int j;
				for (j = bl - 1; j >= i; j--)
				{
					if (bndbytes[j] != bndbytes[j - i])
						continue label0;
					gss[j - 1] = i;
				}

				while (j > 0) 
					gss[--j] = i;
			}

			gss[bl - 1] = 1;
			MimeBodyPart part;
			for (boolean done = false; !done; addBodyPart(part))
			{
				InternetHeaders headers = null;
				if (sin != null)
				{
					start = sin.getPosition();
					while ((line = lin.readLine()) != null && line.length() > 0) ;
					if (line == null)
					{
						if (!ignoreMissingEndBoundary)
							throw new MessagingException("missing multipart end boundary");
						complete = false;
						break;
					}
				} else
				{
					headers = createInternetHeaders(in);
				}
				if (!in.markSupported())
					throw new MessagingException("Stream doesn't support mark");
				ByteArrayOutputStream buf = null;
				if (sin == null)
					buf = new ByteArrayOutputStream();
				else
					end = sin.getPosition();
				byte inbuf[] = new byte[bl];
				byte previnbuf[] = new byte[bl];
				int inSize = 0;
				int prevSize = 0;
				boolean first = true;
				int eolLen;
				do
				{
					in.mark(bl + 4 + 1000);
					eolLen = 0;
					inSize = in.read(inbuf, 0, bl);
					if (inSize < bl)
					{
						if (!ignoreMissingEndBoundary)
							throw new MessagingException("missing multipart end boundary");
						if (sin != null)
							end = sin.getPosition();
						complete = false;
						done = true;
						break;
					}
					int i;
					for (i = bl - 1; i >= 0 && inbuf[i] == bndbytes[i]; i--);
					if (i < 0)
					{
						eolLen = 0;
						if (!first)
						{
							int b = previnbuf[prevSize - 1];
							if (b == 13 || b == 10)
							{
								eolLen = 1;
								if (b == 10 && prevSize >= 2)
								{
									b = previnbuf[prevSize - 2];
									if (b == 13)
										eolLen = 2;
								}
							}
						}
						if (first || eolLen > 0)
						{
							if (sin != null)
								end = sin.getPosition() - (long)bl - (long)eolLen;
							int b2 = in.read();
							if (b2 == 45 && in.read() == 45)
							{
								complete = true;
								done = true;
								break;
							}
							for (; b2 == 32 || b2 == 9; b2 = in.read());
							if (b2 == 10)
								break;
							if (b2 == 13)
							{
								in.mark(1);
								if (in.read() != 10)
									in.reset();
								break;
							}
						}
						i = 0;
					}
					int skip = Math.max((i + 1) - bcs[inbuf[i] & 0x7f], gss[i]);
					if (skip < 2)
					{
						if (sin == null && prevSize > 1)
							buf.write(previnbuf, 0, prevSize - 1);
						in.reset();
						in.skip(1L);
						if (prevSize >= 1)
						{
							previnbuf[0] = previnbuf[prevSize - 1];
							previnbuf[1] = inbuf[0];
							prevSize = 2;
						} else
						{
							previnbuf[0] = inbuf[0];
							prevSize = 1;
						}
					} else
					{
						if (prevSize > 0 && sin == null)
							buf.write(previnbuf, 0, prevSize);
						prevSize = skip;
						in.reset();
						in.skip(prevSize);
						byte tmp[] = inbuf;
						inbuf = previnbuf;
						previnbuf = tmp;
					}
					first = false;
				} while (true);
				if (sin != null)
				{
					part = createMimeBodyPart(sin.newStream(start, end));
					continue;
				}
				if (prevSize - eolLen > 0)
					buf.write(previnbuf, 0, prevSize - eolLen);
				if (!complete && inSize > 0)
					buf.write(inbuf, 0, inSize);
				part = createMimeBodyPart(headers, buf.toByteArray());
			}

		}
		catch (IOException ioex)
		{
			throw new MessagingException("IO Error", ioex);
		}
		finally { }
		try
		{
			in.close();
		}
		catch (IOException cex) { }
		break MISSING_BLOCK_LABEL_1261;
		try
		{
			in.close();
		}
		catch (IOException cex) { }
		throw exception;
		parsed = true;
		return;
	}

	protected InternetHeaders createInternetHeaders(InputStream is)
		throws MessagingException
	{
		return new InternetHeaders(is);
	}

	protected MimeBodyPart createMimeBodyPart(InternetHeaders headers, byte content[])
		throws MessagingException
	{
		return new MimeBodyPart(headers, content);
	}

	protected MimeBodyPart createMimeBodyPart(InputStream is)
		throws MessagingException
	{
		return new MimeBodyPart(is);
	}

	static 
	{
		try
		{
			String s = System.getProperty("mail.mime.multipart.ignoremissingendboundary");
			ignoreMissingEndBoundary = s == null || !s.equalsIgnoreCase("false");
			s = System.getProperty("mail.mime.multipart.ignoremissingboundaryparameter");
			ignoreMissingBoundaryParameter = s == null || !s.equalsIgnoreCase("false");
			s = System.getProperty("mail.mime.multipart.bmparse");
			bmparse = s == null || !s.equalsIgnoreCase("false");
		}
		catch (SecurityException sex) { }
	}
}
