// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MimeBodyPart.java

package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import java.io.*;
import java.util.Enumeration;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;

// Referenced classes of package javax.mail.internet:
//			CachedDataHandler, ContentDisposition, ContentType, HeaderTokenizer, 
//			InternetHeaders, MimeMultipart, MimePart, MimePartDataSource, 
//			MimeUtility, ParseException, SharedInputStream

public class MimeBodyPart extends BodyPart
	implements MimePart
{

	private static boolean setDefaultTextCharset = true;
	private static boolean setContentTypeFileName = true;
	private static boolean encodeFileName = false;
	private static boolean decodeFileName = false;
	static boolean cacheMultipart = true;
	protected DataHandler dh;
	protected byte content[];
	protected InputStream contentStream;
	protected InternetHeaders headers;

	public MimeBodyPart()
	{
		headers = new InternetHeaders();
	}

	public MimeBodyPart(InputStream is)
		throws MessagingException
	{
		if (!(is instanceof ByteArrayInputStream) && !(is instanceof BufferedInputStream) && !(is instanceof SharedInputStream))
			is = new BufferedInputStream(is);
		headers = new InternetHeaders(is);
		if (is instanceof SharedInputStream)
		{
			SharedInputStream sis = (SharedInputStream)is;
			contentStream = sis.newStream(sis.getPosition(), -1L);
		} else
		{
			try
			{
				content = ASCIIUtility.getBytes(is);
			}
			catch (IOException ioex)
			{
				throw new MessagingException("Error reading input stream", ioex);
			}
		}
	}

	public MimeBodyPart(InternetHeaders headers, byte content[])
		throws MessagingException
	{
		this.headers = headers;
		this.content = content;
	}

	public int getSize()
		throws MessagingException
	{
		if (content != null)
			return content.length;
		if (contentStream == null)
			break MISSING_BLOCK_LABEL_38;
		int size = contentStream.available();
		if (size > 0)
			return size;
		break MISSING_BLOCK_LABEL_38;
		IOException ex;
		ex;
		return -1;
	}

	public int getLineCount()
		throws MessagingException
	{
		return -1;
	}

	public String getContentType()
		throws MessagingException
	{
		String s = getHeader("Content-Type", null);
		if (s == null)
			s = "text/plain";
		return s;
	}

	public boolean isMimeType(String mimeType)
		throws MessagingException
	{
		return isMimeType(((MimePart) (this)), mimeType);
	}

	public String getDisposition()
		throws MessagingException
	{
		return getDisposition(((MimePart) (this)));
	}

	public void setDisposition(String disposition)
		throws MessagingException
	{
		setDisposition(((MimePart) (this)), disposition);
	}

	public String getEncoding()
		throws MessagingException
	{
		return getEncoding(((MimePart) (this)));
	}

	public String getContentID()
		throws MessagingException
	{
		return getHeader("Content-Id", null);
	}

	public void setContentID(String cid)
		throws MessagingException
	{
		if (cid == null)
			removeHeader("Content-ID");
		else
			setHeader("Content-ID", cid);
	}

	public String getContentMD5()
		throws MessagingException
	{
		return getHeader("Content-MD5", null);
	}

	public void setContentMD5(String md5)
		throws MessagingException
	{
		setHeader("Content-MD5", md5);
	}

	public String[] getContentLanguage()
		throws MessagingException
	{
		return getContentLanguage(((MimePart) (this)));
	}

	public void setContentLanguage(String languages[])
		throws MessagingException
	{
		setContentLanguage(((MimePart) (this)), languages);
	}

	public String getDescription()
		throws MessagingException
	{
		return getDescription(((MimePart) (this)));
	}

	public void setDescription(String description)
		throws MessagingException
	{
		setDescription(description, null);
	}

	public void setDescription(String description, String charset)
		throws MessagingException
	{
		setDescription(((MimePart) (this)), description, charset);
	}

	public String getFileName()
		throws MessagingException
	{
		return getFileName(((MimePart) (this)));
	}

	public void setFileName(String filename)
		throws MessagingException
	{
		setFileName(((MimePart) (this)), filename);
	}

	public InputStream getInputStream()
		throws IOException, MessagingException
	{
		return getDataHandler().getInputStream();
	}

	protected InputStream getContentStream()
		throws MessagingException
	{
		if (contentStream != null)
			return ((SharedInputStream)contentStream).newStream(0L, -1L);
		if (content != null)
			return new ByteArrayInputStream(content);
		else
			throw new MessagingException("No content");
	}

	public InputStream getRawInputStream()
		throws MessagingException
	{
		return getContentStream();
	}

	public DataHandler getDataHandler()
		throws MessagingException
	{
		if (dh == null)
			dh = new DataHandler(new MimePartDataSource(this));
		return dh;
	}

	public Object getContent()
		throws IOException, MessagingException
	{
		Object c = getDataHandler().getContent();
		if (cacheMultipart && ((c instanceof Multipart) || (c instanceof Message)) && !(dh instanceof CachedDataHandler) && (content != null || contentStream != null))
			dh = createCachedDataHandler(c, getContentType());
		return c;
	}

	public void setDataHandler(DataHandler dh)
		throws MessagingException
	{
		this.dh = dh;
		invalidateContentHeaders(this);
	}

	public void setContent(Object o, String type)
		throws MessagingException
	{
		if (o instanceof Multipart)
			setContent((Multipart)o);
		else
			setDataHandler(new DataHandler(o, type));
	}

	public void setText(String text)
		throws MessagingException
	{
		setText(text, null);
	}

	public void setText(String text, String charset)
		throws MessagingException
	{
		setText(((MimePart) (this)), text, charset, "plain");
	}

	public void setText(String text, String charset, String subtype)
		throws MessagingException
	{
		setText(((MimePart) (this)), text, charset, subtype);
	}

	public void setContent(Multipart mp)
		throws MessagingException
	{
		setDataHandler(new DataHandler(mp, mp.getContentType()));
		mp.setParent(this);
	}

	public void attachFile(File file)
		throws IOException, MessagingException
	{
		FileDataSource fds = new FileDataSource(file);
		setDataHandler(new DataHandler(fds));
		setFileName(fds.getName());
	}

	public void attachFile(String file)
		throws IOException, MessagingException
	{
		File f = new File(file);
		attachFile(f);
	}

	public void saveFile(File file)
		throws IOException, MessagingException
	{
		OutputStream out;
		InputStream in;
		out = new BufferedOutputStream(new FileOutputStream(file));
		in = getInputStream();
		byte buf[] = new byte[8192];
		int len;
		while ((len = in.read(buf)) > 0) 
			out.write(buf, 0, len);
		try
		{
			if (in != null)
				in.close();
		}
		catch (IOException ex) { }
		try
		{
			if (out != null)
				out.close();
		}
		catch (IOException ex) { }
		break MISSING_BLOCK_LABEL_112;
		Exception exception;
		exception;
		try
		{
			if (in != null)
				in.close();
		}
		catch (IOException ex) { }
		try
		{
			if (out != null)
				out.close();
		}
		catch (IOException ex) { }
		throw exception;
	}

	public void saveFile(String file)
		throws IOException, MessagingException
	{
		File f = new File(file);
		saveFile(f);
	}

	public void writeTo(OutputStream os)
		throws IOException, MessagingException
	{
		writeTo(((MimePart) (this)), os, null);
	}

	public String[] getHeader(String name)
		throws MessagingException
	{
		return headers.getHeader(name);
	}

	public String getHeader(String name, String delimiter)
		throws MessagingException
	{
		return headers.getHeader(name, delimiter);
	}

	public void setHeader(String name, String value)
		throws MessagingException
	{
		headers.setHeader(name, value);
	}

	public void addHeader(String name, String value)
		throws MessagingException
	{
		headers.addHeader(name, value);
	}

	public void removeHeader(String name)
		throws MessagingException
	{
		headers.removeHeader(name);
	}

	public Enumeration getAllHeaders()
		throws MessagingException
	{
		return headers.getAllHeaders();
	}

	public Enumeration getMatchingHeaders(String names[])
		throws MessagingException
	{
		return headers.getMatchingHeaders(names);
	}

	public Enumeration getNonMatchingHeaders(String names[])
		throws MessagingException
	{
		return headers.getNonMatchingHeaders(names);
	}

	public void addHeaderLine(String line)
		throws MessagingException
	{
		headers.addHeaderLine(line);
	}

	public Enumeration getAllHeaderLines()
		throws MessagingException
	{
		return headers.getAllHeaderLines();
	}

	public Enumeration getMatchingHeaderLines(String names[])
		throws MessagingException
	{
		return headers.getMatchingHeaderLines(names);
	}

	public Enumeration getNonMatchingHeaderLines(String names[])
		throws MessagingException
	{
		return headers.getNonMatchingHeaderLines(names);
	}

	protected void updateHeaders()
		throws MessagingException
	{
		updateHeaders(((MimePart) (this)));
	}

	static boolean isMimeType(MimePart part, String mimeType)
		throws MessagingException
	{
		ContentType ct = new ContentType(part.getContentType());
		return ct.match(mimeType);
		ParseException ex;
		ex;
		return part.getContentType().equalsIgnoreCase(mimeType);
	}

	static void setText(MimePart part, String text, String charset, String subtype)
		throws MessagingException
	{
		if (charset == null)
			if (MimeUtility.checkAscii(text) != 1)
				charset = MimeUtility.getDefaultMIMECharset();
			else
				charset = "us-ascii";
		part.setContent(text, "text/" + subtype + "; charset=" + MimeUtility.quote(charset, "()<>@,;:\\\"\t []/?="));
	}

	static String getDisposition(MimePart part)
		throws MessagingException
	{
		String s = part.getHeader("Content-Disposition", null);
		if (s == null)
		{
			return null;
		} else
		{
			ContentDisposition cd = new ContentDisposition(s);
			return cd.getDisposition();
		}
	}

	static void setDisposition(MimePart part, String disposition)
		throws MessagingException
	{
		if (disposition == null)
		{
			part.removeHeader("Content-Disposition");
		} else
		{
			String s = part.getHeader("Content-Disposition", null);
			if (s != null)
			{
				ContentDisposition cd = new ContentDisposition(s);
				cd.setDisposition(disposition);
				disposition = cd.toString();
			}
			part.setHeader("Content-Disposition", disposition);
		}
	}

	static String getDescription(MimePart part)
		throws MessagingException
	{
		String rawvalue;
		rawvalue = part.getHeader("Content-Description", null);
		if (rawvalue == null)
			return null;
		return MimeUtility.decodeText(MimeUtility.unfold(rawvalue));
		UnsupportedEncodingException ex;
		ex;
		return rawvalue;
	}

	static void setDescription(MimePart part, String description, String charset)
		throws MessagingException
	{
		if (description == null)
		{
			part.removeHeader("Content-Description");
			return;
		}
		try
		{
			part.setHeader("Content-Description", MimeUtility.fold(21, MimeUtility.encodeText(description, charset, null)));
		}
		catch (UnsupportedEncodingException uex)
		{
			throw new MessagingException("Encoding error", uex);
		}
	}

	static String getFileName(MimePart part)
		throws MessagingException
	{
		String filename = null;
		String s = part.getHeader("Content-Disposition", null);
		if (s != null)
		{
			ContentDisposition cd = new ContentDisposition(s);
			filename = cd.getParameter("filename");
		}
		if (filename == null)
		{
			s = part.getHeader("Content-Type", null);
			if (s != null)
				try
				{
					ContentType ct = new ContentType(s);
					filename = ct.getParameter("name");
				}
				catch (ParseException pex) { }
		}
		if (decodeFileName && filename != null)
			try
			{
				filename = MimeUtility.decodeText(filename);
			}
			catch (UnsupportedEncodingException ex)
			{
				throw new MessagingException("Can't decode filename", ex);
			}
		return filename;
	}

	static void setFileName(MimePart part, String name)
		throws MessagingException
	{
		if (encodeFileName && name != null)
			try
			{
				name = MimeUtility.encodeText(name);
			}
			catch (UnsupportedEncodingException ex)
			{
				throw new MessagingException("Can't encode filename", ex);
			}
		String s = part.getHeader("Content-Disposition", null);
		ContentDisposition cd = new ContentDisposition(s != null ? s : "attachment");
		cd.setParameter("filename", name);
		part.setHeader("Content-Disposition", cd.toString());
		if (setContentTypeFileName)
		{
			s = part.getHeader("Content-Type", null);
			if (s != null)
				try
				{
					ContentType cType = new ContentType(s);
					cType.setParameter("name", name);
					part.setHeader("Content-Type", cType.toString());
				}
				catch (ParseException pex) { }
		}
	}

	static String[] getContentLanguage(MimePart part)
		throws MessagingException
	{
		String s = part.getHeader("Content-Language", null);
		if (s == null)
			return null;
		HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
		Vector v = new Vector();
		do
		{
			HeaderTokenizer.Token tk = h.next();
			int tkType = tk.getType();
			if (tkType == -4)
				break;
			if (tkType == -1)
				v.addElement(tk.getValue());
		} while (true);
		if (v.size() == 0)
		{
			return null;
		} else
		{
			String language[] = new String[v.size()];
			v.copyInto(language);
			return language;
		}
	}

	static void setContentLanguage(MimePart part, String languages[])
		throws MessagingException
	{
		StringBuffer sb = new StringBuffer(languages[0]);
		for (int i = 1; i < languages.length; i++)
			sb.append(',').append(languages[i]);

		part.setHeader("Content-Language", sb.toString());
	}

	static String getEncoding(MimePart part)
		throws MessagingException
	{
		String s = part.getHeader("Content-Transfer-Encoding", null);
		if (s == null)
			return null;
		s = s.trim();
		if (s.equalsIgnoreCase("7bit") || s.equalsIgnoreCase("8bit") || s.equalsIgnoreCase("quoted-printable") || s.equalsIgnoreCase("binary") || s.equalsIgnoreCase("base64"))
			return s;
		HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
		do
		{
			HeaderTokenizer.Token tk = h.next();
			int tkType = tk.getType();
			if (tkType != -4)
			{
				if (tkType == -1)
					return tk.getValue();
			} else
			{
				return s;
			}
		} while (true);
	}

	static void setEncoding(MimePart part, String encoding)
		throws MessagingException
	{
		part.setHeader("Content-Transfer-Encoding", encoding);
	}

	static DataHandler createCachedDataHandler(Object o, String mimeType)
	{
		return new CachedDataHandler(o, mimeType);
	}

	static void updateHeaders(MimePart part)
		throws MessagingException
	{
		DataHandler dh = part.getDataHandler();
		if (dh == null)
			return;
		try
		{
			String type = dh.getContentType();
			boolean composite = false;
			boolean needCTHeader = part.getHeader("Content-Type") == null;
			ContentType cType = new ContentType(type);
			if (cType.match("multipart/*"))
			{
				composite = true;
				Object o = dh.getContent();
				if (o instanceof MimeMultipart)
					((MimeMultipart)o).updateHeaders();
				else
					throw new MessagingException("MIME part of type \"" + type + "\" contains object of type " + o.getClass().getName() + " instead of MimeMultipart");
			} else
			if (cType.match("message/rfc822"))
				composite = true;
			if (!composite)
			{
				if (part.getHeader("Content-Transfer-Encoding") == null)
					setEncoding(part, MimeUtility.getEncoding(dh));
				if (needCTHeader && setDefaultTextCharset && cType.match("text/*") && cType.getParameter("charset") == null)
				{
					String enc = part.getEncoding();
					String charset;
					if (enc != null && enc.equalsIgnoreCase("7bit"))
						charset = "us-ascii";
					else
						charset = MimeUtility.getDefaultMIMECharset();
					cType.setParameter("charset", charset);
					type = cType.toString();
				}
			}
			if (needCTHeader)
			{
				String s = part.getHeader("Content-Disposition", null);
				if (s != null)
				{
					ContentDisposition cd = new ContentDisposition(s);
					String filename = cd.getParameter("filename");
					if (filename != null)
					{
						cType.setParameter("name", filename);
						type = cType.toString();
					}
				}
				part.setHeader("Content-Type", type);
			}
		}
		catch (IOException ex)
		{
			throw new MessagingException("IOException updating headers", ex);
		}
	}

	static void invalidateContentHeaders(MimePart part)
		throws MessagingException
	{
		part.removeHeader("Content-Type");
		part.removeHeader("Content-Transfer-Encoding");
	}

	static void writeTo(MimePart part, OutputStream os, String ignoreList[])
		throws IOException, MessagingException
	{
		LineOutputStream los = null;
		if (os instanceof LineOutputStream)
			los = (LineOutputStream)os;
		else
			los = new LineOutputStream(os);
		for (Enumeration hdrLines = part.getNonMatchingHeaderLines(ignoreList); hdrLines.hasMoreElements(); los.writeln((String)hdrLines.nextElement()));
		los.writeln();
		os = MimeUtility.encode(os, part.getEncoding());
		part.getDataHandler().writeTo(os);
		os.flush();
	}

	static 
	{
		try
		{
			String s = System.getProperty("mail.mime.setdefaulttextcharset");
			setDefaultTextCharset = s == null || !s.equalsIgnoreCase("false");
			s = System.getProperty("mail.mime.setcontenttypefilename");
			setContentTypeFileName = s == null || !s.equalsIgnoreCase("false");
			s = System.getProperty("mail.mime.encodefilename");
			encodeFileName = s != null && !s.equalsIgnoreCase("false");
			s = System.getProperty("mail.mime.decodefilename");
			decodeFileName = s != null && !s.equalsIgnoreCase("false");
			s = System.getProperty("mail.mime.cachemultipart");
			cacheMultipart = s == null || !s.equalsIgnoreCase("false");
		}
		catch (SecurityException sex) { }
	}
}
