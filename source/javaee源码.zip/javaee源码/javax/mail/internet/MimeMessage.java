// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MimeMessage.java

package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import java.io.*;
import java.text.ParseException;
import java.util.*;
import javax.activation.DataHandler;
import javax.mail.*;
import javax.mail.util.SharedByteArrayInputStream;

// Referenced classes of package javax.mail.internet:
//			CachedDataHandler, InternetAddress, InternetHeaders, MailDateFormat, 
//			MimeBodyPart, MimePart, MimePartDataSource, MimeUtility, 
//			NewsAddress, SharedInputStream, UniqueValue

public class MimeMessage extends Message
	implements MimePart
{
	public static class RecipientType extends javax.mail.Message.RecipientType
	{

		private static final long serialVersionUID = 0xb41cba943bbdee69L;
		public static final RecipientType NEWSGROUPS = new RecipientType("Newsgroups");

		protected Object readResolve()
			throws ObjectStreamException
		{
			if (type.equals("Newsgroups"))
				return NEWSGROUPS;
			else
				return super.readResolve();
		}


		protected RecipientType(String type)
		{
			super(type);
		}
	}


	protected DataHandler dh;
	protected byte content[];
	protected InputStream contentStream;
	protected InternetHeaders headers;
	protected Flags flags;
	protected boolean modified;
	protected boolean saved;
	private static MailDateFormat mailDateFormat = new MailDateFormat();
	private boolean strict;
	private static final Flags answeredFlag;

	public MimeMessage(Session session)
	{
		super(session);
		modified = false;
		saved = false;
		strict = true;
		modified = true;
		headers = new InternetHeaders();
		flags = new Flags();
		initStrict();
	}

	public MimeMessage(Session session, InputStream is)
		throws MessagingException
	{
		super(session);
		modified = false;
		saved = false;
		strict = true;
		flags = new Flags();
		initStrict();
		parse(is);
		saved = true;
	}

	public MimeMessage(MimeMessage source)
		throws MessagingException
	{
		super(source.session);
		modified = false;
		saved = false;
		strict = true;
		flags = source.getFlags();
		int size = source.getSize();
		ByteArrayOutputStream bos;
		if (size > 0)
			bos = new ByteArrayOutputStream(size);
		else
			bos = new ByteArrayOutputStream();
		try
		{
			strict = source.strict;
			source.writeTo(bos);
			bos.close();
			SharedByteArrayInputStream bis = new SharedByteArrayInputStream(bos.toByteArray());
			parse(bis);
			bis.close();
			saved = true;
		}
		catch (IOException ex)
		{
			throw new MessagingException("IOException while copying message", ex);
		}
	}

	protected MimeMessage(Folder folder, int msgnum)
	{
		super(folder, msgnum);
		modified = false;
		saved = false;
		strict = true;
		flags = new Flags();
		saved = true;
		initStrict();
	}

	protected MimeMessage(Folder folder, InputStream is, int msgnum)
		throws MessagingException
	{
		this(folder, msgnum);
		initStrict();
		parse(is);
	}

	protected MimeMessage(Folder folder, InternetHeaders headers, byte content[], int msgnum)
		throws MessagingException
	{
		this(folder, msgnum);
		this.headers = headers;
		this.content = content;
		initStrict();
	}

	private void initStrict()
	{
		if (session != null)
		{
			String s = session.getProperty("mail.mime.address.strict");
			strict = s == null || !s.equalsIgnoreCase("false");
		}
	}

	protected void parse(InputStream is)
		throws MessagingException
	{
		if (!(is instanceof ByteArrayInputStream) && !(is instanceof BufferedInputStream) && !(is instanceof SharedInputStream))
			is = new BufferedInputStream(is);
		headers = createInternetHeaders(is);
		if (is instanceof SharedInputStream)
		{
			SharedInputStream sis = (SharedInputStream)is;
			contentStream = sis.newStream(sis.getPosition(), -1L);
		} else
		{
			try
			{
				content = ASCIIUtility.getBytes(is);
			}
			catch (IOException ioex)
			{
				throw new MessagingException("IOException", ioex);
			}
		}
		modified = false;
	}

	public Address[] getFrom()
		throws MessagingException
	{
		Address a[] = getAddressHeader("From");
		if (a == null)
			a = getAddressHeader("Sender");
		return a;
	}

	public void setFrom(Address address)
		throws MessagingException
	{
		if (address == null)
			removeHeader("From");
		else
			setHeader("From", address.toString());
	}

	public void setFrom()
		throws MessagingException
	{
		InternetAddress me = InternetAddress.getLocalAddress(session);
		if (me != null)
			setFrom(((Address) (me)));
		else
			throw new MessagingException("No From address");
	}

	public void addFrom(Address addresses[])
		throws MessagingException
	{
		addAddressHeader("From", addresses);
	}

	public Address getSender()
		throws MessagingException
	{
		Address a[] = getAddressHeader("Sender");
		if (a == null || a.length == 0)
			return null;
		else
			return a[0];
	}

	public void setSender(Address address)
		throws MessagingException
	{
		if (address == null)
			removeHeader("Sender");
		else
			setHeader("Sender", address.toString());
	}

	public Address[] getRecipients(javax.mail.Message.RecipientType type)
		throws MessagingException
	{
		if (type == RecipientType.NEWSGROUPS)
		{
			String s = getHeader("Newsgroups", ",");
			return s != null ? NewsAddress.parse(s) : null;
		} else
		{
			return getAddressHeader(getHeaderName(type));
		}
	}

	public Address[] getAllRecipients()
		throws MessagingException
	{
		Address all[] = super.getAllRecipients();
		Address ng[] = getRecipients(RecipientType.NEWSGROUPS);
		if (ng == null)
			return all;
		int numRecip = (all == null ? 0 : all.length) + (ng == null ? 0 : ng.length);
		Address addresses[] = new Address[numRecip];
		int pos = 0;
		if (all != null)
		{
			System.arraycopy(all, 0, addresses, pos, all.length);
			pos += all.length;
		}
		if (ng != null)
		{
			System.arraycopy(ng, 0, addresses, pos, ng.length);
			pos += ng.length;
		}
		return addresses;
	}

	public void setRecipients(javax.mail.Message.RecipientType type, Address addresses[])
		throws MessagingException
	{
		if (type == RecipientType.NEWSGROUPS)
		{
			if (addresses == null || addresses.length == 0)
				removeHeader("Newsgroups");
			else
				setHeader("Newsgroups", NewsAddress.toString(addresses));
		} else
		{
			setAddressHeader(getHeaderName(type), addresses);
		}
	}

	public void setRecipients(javax.mail.Message.RecipientType type, String addresses)
		throws MessagingException
	{
		if (type == RecipientType.NEWSGROUPS)
		{
			if (addresses == null || addresses.length() == 0)
				removeHeader("Newsgroups");
			else
				setHeader("Newsgroups", addresses);
		} else
		{
			setAddressHeader(getHeaderName(type), InternetAddress.parse(addresses));
		}
	}

	public void addRecipients(javax.mail.Message.RecipientType type, Address addresses[])
		throws MessagingException
	{
		if (type == RecipientType.NEWSGROUPS)
		{
			String s = NewsAddress.toString(addresses);
			if (s != null)
				addHeader("Newsgroups", s);
		} else
		{
			addAddressHeader(getHeaderName(type), addresses);
		}
	}

	public void addRecipients(javax.mail.Message.RecipientType type, String addresses)
		throws MessagingException
	{
		if (type == RecipientType.NEWSGROUPS)
		{
			if (addresses != null && addresses.length() != 0)
				addHeader("Newsgroups", addresses);
		} else
		{
			addAddressHeader(getHeaderName(type), InternetAddress.parse(addresses));
		}
	}

	public Address[] getReplyTo()
		throws MessagingException
	{
		Address a[] = getAddressHeader("Reply-To");
		if (a == null)
			a = getFrom();
		return a;
	}

	public void setReplyTo(Address addresses[])
		throws MessagingException
	{
		setAddressHeader("Reply-To", addresses);
	}

	private Address[] getAddressHeader(String name)
		throws MessagingException
	{
		String s = getHeader(name, ",");
		return s != null ? InternetAddress.parseHeader(s, strict) : null;
	}

	private void setAddressHeader(String name, Address addresses[])
		throws MessagingException
	{
		String s = InternetAddress.toString(addresses);
		if (s == null)
			removeHeader(name);
		else
			setHeader(name, s);
	}

	private void addAddressHeader(String name, Address addresses[])
		throws MessagingException
	{
		String s = InternetAddress.toString(addresses);
		if (s == null)
		{
			return;
		} else
		{
			addHeader(name, s);
			return;
		}
	}

	public String getSubject()
		throws MessagingException
	{
		String rawvalue;
		rawvalue = getHeader("Subject", null);
		if (rawvalue == null)
			return null;
		return MimeUtility.decodeText(MimeUtility.unfold(rawvalue));
		UnsupportedEncodingException ex;
		ex;
		return rawvalue;
	}

	public void setSubject(String subject)
		throws MessagingException
	{
		setSubject(subject, null);
	}

	public void setSubject(String subject, String charset)
		throws MessagingException
	{
		if (subject == null)
			removeHeader("Subject");
		try
		{
			setHeader("Subject", MimeUtility.fold(9, MimeUtility.encodeText(subject, charset, null)));
		}
		catch (UnsupportedEncodingException uex)
		{
			throw new MessagingException("Encoding error", uex);
		}
	}

	public Date getSentDate()
		throws MessagingException
	{
		String s;
		s = getHeader("Date", null);
		if (s == null)
			break MISSING_BLOCK_LABEL_36;
		MailDateFormat maildateformat = mailDateFormat;
		JVM INSTR monitorenter ;
		return mailDateFormat.parse(s);
		Exception exception;
		exception;
		throw exception;
		ParseException pex;
		pex;
		return null;
		return null;
	}

	public void setSentDate(Date d)
		throws MessagingException
	{
		if (d == null)
			removeHeader("Date");
		else
			synchronized (mailDateFormat)
			{
				setHeader("Date", mailDateFormat.format(d));
			}
	}

	public Date getReceivedDate()
		throws MessagingException
	{
		return null;
	}

	public int getSize()
		throws MessagingException
	{
		if (content != null)
			return content.length;
		if (contentStream == null)
			break MISSING_BLOCK_LABEL_38;
		int size = contentStream.available();
		if (size > 0)
			return size;
		break MISSING_BLOCK_LABEL_38;
		IOException ex;
		ex;
		return -1;
	}

	public int getLineCount()
		throws MessagingException
	{
		return -1;
	}

	public String getContentType()
		throws MessagingException
	{
		String s = getHeader("Content-Type", null);
		if (s == null)
			return "text/plain";
		else
			return s;
	}

	public boolean isMimeType(String mimeType)
		throws MessagingException
	{
		return MimeBodyPart.isMimeType(this, mimeType);
	}

	public String getDisposition()
		throws MessagingException
	{
		return MimeBodyPart.getDisposition(this);
	}

	public void setDisposition(String disposition)
		throws MessagingException
	{
		MimeBodyPart.setDisposition(this, disposition);
	}

	public String getEncoding()
		throws MessagingException
	{
		return MimeBodyPart.getEncoding(this);
	}

	public String getContentID()
		throws MessagingException
	{
		return getHeader("Content-Id", null);
	}

	public void setContentID(String cid)
		throws MessagingException
	{
		if (cid == null)
			removeHeader("Content-ID");
		else
			setHeader("Content-ID", cid);
	}

	public String getContentMD5()
		throws MessagingException
	{
		return getHeader("Content-MD5", null);
	}

	public void setContentMD5(String md5)
		throws MessagingException
	{
		setHeader("Content-MD5", md5);
	}

	public String getDescription()
		throws MessagingException
	{
		return MimeBodyPart.getDescription(this);
	}

	public void setDescription(String description)
		throws MessagingException
	{
		setDescription(description, null);
	}

	public void setDescription(String description, String charset)
		throws MessagingException
	{
		MimeBodyPart.setDescription(this, description, charset);
	}

	public String[] getContentLanguage()
		throws MessagingException
	{
		return MimeBodyPart.getContentLanguage(this);
	}

	public void setContentLanguage(String languages[])
		throws MessagingException
	{
		MimeBodyPart.setContentLanguage(this, languages);
	}

	public String getMessageID()
		throws MessagingException
	{
		return getHeader("Message-ID", null);
	}

	public String getFileName()
		throws MessagingException
	{
		return MimeBodyPart.getFileName(this);
	}

	public void setFileName(String filename)
		throws MessagingException
	{
		MimeBodyPart.setFileName(this, filename);
	}

	private String getHeaderName(javax.mail.Message.RecipientType type)
		throws MessagingException
	{
		String headerName;
		if (type == javax.mail.Message.RecipientType.TO)
			headerName = "To";
		else
		if (type == javax.mail.Message.RecipientType.CC)
			headerName = "Cc";
		else
		if (type == javax.mail.Message.RecipientType.BCC)
			headerName = "Bcc";
		else
		if (type == RecipientType.NEWSGROUPS)
			headerName = "Newsgroups";
		else
			throw new MessagingException("Invalid Recipient Type");
		return headerName;
	}

	public InputStream getInputStream()
		throws IOException, MessagingException
	{
		return getDataHandler().getInputStream();
	}

	protected InputStream getContentStream()
		throws MessagingException
	{
		if (contentStream != null)
			return ((SharedInputStream)contentStream).newStream(0L, -1L);
		if (content != null)
			return new SharedByteArrayInputStream(content);
		else
			throw new MessagingException("No content");
	}

	public InputStream getRawInputStream()
		throws MessagingException
	{
		return getContentStream();
	}

	public synchronized DataHandler getDataHandler()
		throws MessagingException
	{
		if (dh == null)
			dh = new DataHandler(new MimePartDataSource(this));
		return dh;
	}

	public Object getContent()
		throws IOException, MessagingException
	{
		Object c = getDataHandler().getContent();
		if (MimeBodyPart.cacheMultipart && ((c instanceof Multipart) || (c instanceof Message)) && !(dh instanceof CachedDataHandler) && (content != null || contentStream != null))
			dh = MimeBodyPart.createCachedDataHandler(c, getContentType());
		return c;
	}

	public synchronized void setDataHandler(DataHandler dh)
		throws MessagingException
	{
		this.dh = dh;
		MimeBodyPart.invalidateContentHeaders(this);
	}

	public void setContent(Object o, String type)
		throws MessagingException
	{
		setDataHandler(new DataHandler(o, type));
	}

	public void setText(String text)
		throws MessagingException
	{
		setText(text, null);
	}

	public void setText(String text, String charset)
		throws MessagingException
	{
		MimeBodyPart.setText(this, text, charset, "plain");
	}

	public void setText(String text, String charset, String subtype)
		throws MessagingException
	{
		MimeBodyPart.setText(this, text, charset, subtype);
	}

	public void setContent(Multipart mp)
		throws MessagingException
	{
		setDataHandler(new DataHandler(mp, mp.getContentType()));
		mp.setParent(this);
	}

	public Message reply(boolean replyToAll)
		throws MessagingException
	{
		MimeMessage reply = createMimeMessage(session);
		String subject = getHeader("Subject", null);
		if (subject != null)
		{
			if (!subject.regionMatches(true, 0, "Re: ", 0, 4))
				subject = "Re: " + subject;
			reply.setHeader("Subject", subject);
		}
		Address a[] = getReplyTo();
		reply.setRecipients(javax.mail.Message.RecipientType.TO, a);
		if (replyToAll)
		{
			Vector v = new Vector();
			InternetAddress me = InternetAddress.getLocalAddress(session);
			if (me != null)
				v.addElement(me);
			String alternates = null;
			if (session != null)
				alternates = session.getProperty("mail.alternates");
			if (alternates != null)
				eliminateDuplicates(v, InternetAddress.parse(alternates, false));
			String replyallccStr = null;
			if (session != null)
				replyallccStr = session.getProperty("mail.replyallcc");
			boolean replyallcc = replyallccStr != null && replyallccStr.equalsIgnoreCase("true");
			eliminateDuplicates(v, a);
			a = getRecipients(javax.mail.Message.RecipientType.TO);
			a = eliminateDuplicates(v, a);
			if (a != null && a.length > 0)
				if (replyallcc)
					reply.addRecipients(javax.mail.Message.RecipientType.CC, a);
				else
					reply.addRecipients(javax.mail.Message.RecipientType.TO, a);
			a = getRecipients(javax.mail.Message.RecipientType.CC);
			a = eliminateDuplicates(v, a);
			if (a != null && a.length > 0)
				reply.addRecipients(javax.mail.Message.RecipientType.CC, a);
			a = getRecipients(RecipientType.NEWSGROUPS);
			if (a != null && a.length > 0)
				reply.setRecipients(RecipientType.NEWSGROUPS, a);
		}
		String msgId = getHeader("Message-Id", null);
		if (msgId != null)
			reply.setHeader("In-Reply-To", msgId);
		try
		{
			setFlags(answeredFlag, true);
		}
		catch (MessagingException mex) { }
		return reply;
	}

	private Address[] eliminateDuplicates(Vector v, Address addrs[])
	{
		if (addrs == null)
			return null;
		int gone = 0;
		for (int i = 0; i < addrs.length; i++)
		{
			boolean found = false;
			int j = 0;
			do
			{
				if (j >= v.size())
					break;
				if (((InternetAddress)v.elementAt(j)).equals(addrs[i]))
				{
					found = true;
					gone++;
					addrs[i] = null;
					break;
				}
				j++;
			} while (true);
			if (!found)
				v.addElement(addrs[i]);
		}

		if (gone != 0)
		{
			Address a[];
			if (addrs instanceof InternetAddress[])
				a = new InternetAddress[addrs.length - gone];
			else
				a = new Address[addrs.length - gone];
			int i = 0;
			int j = 0;
			for (; i < addrs.length; i++)
				if (addrs[i] != null)
					a[j++] = addrs[i];

			addrs = a;
		}
		return addrs;
	}

	public void writeTo(OutputStream os)
		throws IOException, MessagingException
	{
		writeTo(os, null);
	}

	public void writeTo(OutputStream os, String ignoreList[])
		throws IOException, MessagingException
	{
		if (!saved)
			saveChanges();
		if (modified)
		{
			MimeBodyPart.writeTo(this, os, ignoreList);
			return;
		}
		Enumeration hdrLines = getNonMatchingHeaderLines(ignoreList);
		LineOutputStream los = new LineOutputStream(os);
		for (; hdrLines.hasMoreElements(); los.writeln((String)hdrLines.nextElement()));
		los.writeln();
		if (content == null)
		{
			InputStream is = getContentStream();
			byte buf[] = new byte[8192];
			int len;
			while ((len = is.read(buf)) > 0) 
				os.write(buf, 0, len);
			is.close();
			buf = null;
		} else
		{
			os.write(content);
		}
		os.flush();
	}

	public String[] getHeader(String name)
		throws MessagingException
	{
		return headers.getHeader(name);
	}

	public String getHeader(String name, String delimiter)
		throws MessagingException
	{
		return headers.getHeader(name, delimiter);
	}

	public void setHeader(String name, String value)
		throws MessagingException
	{
		headers.setHeader(name, value);
	}

	public void addHeader(String name, String value)
		throws MessagingException
	{
		headers.addHeader(name, value);
	}

	public void removeHeader(String name)
		throws MessagingException
	{
		headers.removeHeader(name);
	}

	public Enumeration getAllHeaders()
		throws MessagingException
	{
		return headers.getAllHeaders();
	}

	public Enumeration getMatchingHeaders(String names[])
		throws MessagingException
	{
		return headers.getMatchingHeaders(names);
	}

	public Enumeration getNonMatchingHeaders(String names[])
		throws MessagingException
	{
		return headers.getNonMatchingHeaders(names);
	}

	public void addHeaderLine(String line)
		throws MessagingException
	{
		headers.addHeaderLine(line);
	}

	public Enumeration getAllHeaderLines()
		throws MessagingException
	{
		return headers.getAllHeaderLines();
	}

	public Enumeration getMatchingHeaderLines(String names[])
		throws MessagingException
	{
		return headers.getMatchingHeaderLines(names);
	}

	public Enumeration getNonMatchingHeaderLines(String names[])
		throws MessagingException
	{
		return headers.getNonMatchingHeaderLines(names);
	}

	public synchronized Flags getFlags()
		throws MessagingException
	{
		return (Flags)flags.clone();
	}

	public synchronized boolean isSet(javax.mail.Flags.Flag flag)
		throws MessagingException
	{
		return flags.contains(flag);
	}

	public synchronized void setFlags(Flags flag, boolean set)
		throws MessagingException
	{
		if (set)
			flags.add(flag);
		else
			flags.remove(flag);
	}

	public void saveChanges()
		throws MessagingException
	{
		modified = true;
		saved = true;
		updateHeaders();
	}

	protected void updateMessageID()
		throws MessagingException
	{
		setHeader("Message-ID", "<" + UniqueValue.getUniqueMessageIDValue(session) + ">");
	}

	protected void updateHeaders()
		throws MessagingException
	{
		MimeBodyPart.updateHeaders(this);
		setHeader("MIME-Version", "1.0");
		updateMessageID();
	}

	protected InternetHeaders createInternetHeaders(InputStream is)
		throws MessagingException
	{
		return new InternetHeaders(is);
	}

	protected MimeMessage createMimeMessage(Session session)
		throws MessagingException
	{
		return new MimeMessage(session);
	}

	static 
	{
		answeredFlag = new Flags(javax.mail.Flags.Flag.ANSWERED);
	}
}
