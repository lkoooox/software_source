// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ContentType.java

package javax.mail.internet;


// Referenced classes of package javax.mail.internet:
//			HeaderTokenizer, ParameterList, ParseException

public class ContentType
{

	private String primaryType;
	private String subType;
	private ParameterList list;

	public ContentType()
	{
	}

	public ContentType(String primaryType, String subType, ParameterList list)
	{
		this.primaryType = primaryType;
		this.subType = subType;
		this.list = list;
	}

	public ContentType(String s)
		throws ParseException
	{
		HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
		HeaderTokenizer.Token tk = h.next();
		if (tk.getType() != -1)
			throw new ParseException();
		primaryType = tk.getValue();
		tk = h.next();
		if ((char)tk.getType() != '/')
			throw new ParseException();
		tk = h.next();
		if (tk.getType() != -1)
			throw new ParseException();
		subType = tk.getValue();
		String rem = h.getRemainder();
		if (rem != null)
			list = new ParameterList(rem);
	}

	public String getPrimaryType()
	{
		return primaryType;
	}

	public String getSubType()
	{
		return subType;
	}

	public String getBaseType()
	{
		return primaryType + '/' + subType;
	}

	public String getParameter(String name)
	{
		if (list == null)
			return null;
		else
			return list.get(name);
	}

	public ParameterList getParameterList()
	{
		return list;
	}

	public void setPrimaryType(String primaryType)
	{
		this.primaryType = primaryType;
	}

	public void setSubType(String subType)
	{
		this.subType = subType;
	}

	public void setParameter(String name, String value)
	{
		if (list == null)
			list = new ParameterList();
		list.set(name, value);
	}

	public void setParameterList(ParameterList list)
	{
		this.list = list;
	}

	public String toString()
	{
		if (primaryType == null || subType == null)
			return null;
		StringBuffer sb = new StringBuffer();
		sb.append(primaryType).append('/').append(subType);
		if (list != null)
			sb.append(list.toString(sb.length() + 14));
		return sb.toString();
	}

	public boolean match(ContentType cType)
	{
		if (!primaryType.equalsIgnoreCase(cType.getPrimaryType()))
			return false;
		String sType = cType.getSubType();
		if (subType.charAt(0) == '*' || sType.charAt(0) == '*')
			return true;
		return subType.equalsIgnoreCase(sType);
	}

	public boolean match(String s)
	{
		return match(new ContentType(s));
		ParseException pex;
		pex;
		return false;
	}
}
