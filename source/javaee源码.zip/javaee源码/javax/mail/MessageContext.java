// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageContext.java

package javax.mail;


// Referenced classes of package javax.mail:
//			BodyPart, Message, MessagingException, Multipart, 
//			Part, Session

public class MessageContext
{

	private Part part;

	public MessageContext(Part part)
	{
		this.part = part;
	}

	public Part getPart()
	{
		return part;
	}

	public Message getMessage()
	{
		return getMessage(part);
		MessagingException ex;
		ex;
		return null;
	}

	private static Message getMessage(Part p)
		throws MessagingException
	{
		Multipart mp;
		for (; p != null; p = mp.getParent())
		{
			if (p instanceof Message)
				return (Message)p;
			BodyPart bp = (BodyPart)p;
			mp = bp.getParent();
			if (mp == null)
				return null;
		}

		return null;
	}

	public Session getSession()
	{
		Message msg = getMessage();
		return msg == null ? null : msg.session;
	}
}
