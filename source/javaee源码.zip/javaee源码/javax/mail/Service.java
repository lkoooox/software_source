// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Service.java

package javax.mail;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Vector;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import javax.mail.event.MailEvent;

// Referenced classes of package javax.mail:
//			AuthenticationFailedException, EventQueue, MessagingException, PasswordAuthentication, 
//			Session, URLName

public abstract class Service
{
	static class TerminatorEvent extends MailEvent
	{

		private static final long serialVersionUID = 0x4ce9c033019effa0L;

		public void dispatch(Object listener)
		{
			Thread.currentThread().interrupt();
		}

		TerminatorEvent()
		{
			super(new Object());
		}
	}


	protected Session session;
	protected URLName url;
	protected boolean debug;
	private boolean connected;
	private Vector connectionListeners;
	private EventQueue q;
	private Object qLock;

	protected Service(Session session, URLName urlname)
	{
		url = null;
		debug = false;
		connected = false;
		connectionListeners = null;
		qLock = new Object();
		this.session = session;
		url = urlname;
		debug = session.getDebug();
	}

	public void connect()
		throws MessagingException
	{
		connect(null, null, null);
	}

	public void connect(String host, String user, String password)
		throws MessagingException
	{
		connect(host, -1, user, password);
	}

	public void connect(String user, String password)
		throws MessagingException
	{
		connect(null, user, password);
	}

	public void connect(String host, int port, String user, String password)
		throws MessagingException
	{
		if (isConnected())
			throw new IllegalStateException("already connected");
		boolean connected = false;
		boolean save = false;
		String protocol = null;
		String file = null;
		if (url != null)
		{
			protocol = url.getProtocol();
			if (host == null)
				host = url.getHost();
			if (port == -1)
				port = url.getPort();
			if (user == null)
			{
				user = url.getUsername();
				if (password == null)
					password = url.getPassword();
			} else
			if (password == null && user.equals(url.getUsername()))
				password = url.getPassword();
			file = url.getFile();
		}
		if (protocol != null)
		{
			if (host == null)
				host = session.getProperty("mail." + protocol + ".host");
			if (user == null)
				user = session.getProperty("mail." + protocol + ".user");
		}
		if (host == null)
			host = session.getProperty("mail.host");
		if (user == null)
			user = session.getProperty("mail.user");
		if (user == null)
			try
			{
				user = System.getProperty("user.name");
			}
			catch (SecurityException sex)
			{
				if (debug)
					sex.printStackTrace(session.getDebugOut());
			}
		if (password == null && url != null)
		{
			setURLName(new URLName(protocol, host, port, file, user, password));
			PasswordAuthentication pw = session.getPasswordAuthentication(getURLName());
			if (pw != null)
			{
				if (user == null)
				{
					user = pw.getUserName();
					password = pw.getPassword();
				} else
				if (user.equals(pw.getUserName()))
					password = pw.getPassword();
			} else
			{
				save = true;
			}
		}
		AuthenticationFailedException authEx = null;
		try
		{
			connected = protocolConnect(host, port, user, password);
		}
		catch (AuthenticationFailedException ex)
		{
			authEx = ex;
		}
		if (!connected)
		{
			InetAddress addr;
			try
			{
				addr = InetAddress.getByName(host);
			}
			catch (UnknownHostException e)
			{
				addr = null;
			}
			PasswordAuthentication pw = session.requestPasswordAuthentication(addr, port, protocol, null, user);
			if (pw != null)
			{
				user = pw.getUserName();
				password = pw.getPassword();
				connected = protocolConnect(host, port, user, password);
			}
		}
		if (!connected)
			if (authEx != null)
				throw authEx;
			else
				throw new AuthenticationFailedException();
		setURLName(new URLName(protocol, host, port, file, user, password));
		if (save)
			session.setPasswordAuthentication(getURLName(), new PasswordAuthentication(user, password));
		setConnected(true);
		notifyConnectionListeners(1);
	}

	protected boolean protocolConnect(String host, int port, String user, String s)
		throws MessagingException
	{
		return false;
	}

	public boolean isConnected()
	{
		return connected;
	}

	protected void setConnected(boolean connected)
	{
		this.connected = connected;
	}

	public synchronized void close()
		throws MessagingException
	{
		setConnected(false);
		notifyConnectionListeners(3);
	}

	public URLName getURLName()
	{
		if (url != null && (url.getPassword() != null || url.getFile() != null))
			return new URLName(url.getProtocol(), url.getHost(), url.getPort(), null, url.getUsername(), null);
		else
			return url;
	}

	protected void setURLName(URLName url)
	{
		this.url = url;
	}

	public synchronized void addConnectionListener(ConnectionListener l)
	{
		if (connectionListeners == null)
			connectionListeners = new Vector();
		connectionListeners.addElement(l);
	}

	public synchronized void removeConnectionListener(ConnectionListener l)
	{
		if (connectionListeners != null)
			connectionListeners.removeElement(l);
	}

	protected synchronized void notifyConnectionListeners(int type)
	{
		if (connectionListeners != null)
		{
			ConnectionEvent e = new ConnectionEvent(this, type);
			queueEvent(e, connectionListeners);
		}
		if (type == 3)
			terminateQueue();
	}

	public String toString()
	{
		URLName url = getURLName();
		if (url != null)
			return url.toString();
		else
			return super.toString();
	}

	protected void queueEvent(MailEvent event, Vector vector)
	{
		synchronized (qLock)
		{
			if (q == null)
				q = new EventQueue();
		}
		Vector v = (Vector)vector.clone();
		q.enqueue(event, v);
	}

	private void terminateQueue()
	{
		synchronized (qLock)
		{
			if (q != null)
			{
				Vector dummyListeners = new Vector();
				dummyListeners.setSize(1);
				q.enqueue(new TerminatorEvent(), dummyListeners);
				q = null;
			}
		}
	}

	protected void finalize()
		throws Throwable
	{
		super.finalize();
		terminateQueue();
	}
}
