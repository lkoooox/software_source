// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Address.java

package javax.mail;

import java.io.Serializable;

public abstract class Address
	implements Serializable
{

	private static final long serialVersionUID = 0xaf3277d17464de2aL;

	public Address()
	{
	}

	public abstract String getType();

	public abstract String toString();

	public abstract boolean equals(Object obj);
}
