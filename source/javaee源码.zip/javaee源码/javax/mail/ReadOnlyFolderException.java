// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ReadOnlyFolderException.java

package javax.mail;


// Referenced classes of package javax.mail:
//			MessagingException, Folder

public class ReadOnlyFolderException extends MessagingException
{

	private transient Folder folder;
	private static final long serialVersionUID = 0x4f447e8d4f54375dL;

	public ReadOnlyFolderException(Folder folder)
	{
		this(folder, null);
	}

	public ReadOnlyFolderException(Folder folder, String message)
	{
		super(message);
		this.folder = folder;
	}

	public Folder getFolder()
	{
		return folder;
	}
}
