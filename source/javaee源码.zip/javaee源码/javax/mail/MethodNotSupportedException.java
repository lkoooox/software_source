// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodNotSupportedException.java

package javax.mail;


// Referenced classes of package javax.mail:
//			MessagingException

public class MethodNotSupportedException extends MessagingException
{

	private static final long serialVersionUID = 0xcbdb14c71b05d986L;

	public MethodNotSupportedException()
	{
	}

	public MethodNotSupportedException(String s)
	{
		super(s);
	}
}
