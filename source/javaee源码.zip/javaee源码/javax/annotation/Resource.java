// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Resource.java

package javax.annotation;

import java.lang.annotation.Annotation;

public interface Resource
	extends Annotation
{
	public static final class AuthenticationType extends Enum
	{

		public static final AuthenticationType CONTAINER;
		public static final AuthenticationType APPLICATION;
		private static final AuthenticationType $VALUES[];

		public static final AuthenticationType[] values()
		{
			return (AuthenticationType[])$VALUES.clone();
		}

		public static AuthenticationType valueOf(String name)
		{
			AuthenticationType arr$[] = $VALUES;
			int len$ = arr$.length;
			for (int i$ = 0; i$ < len$; i$++)
			{
				AuthenticationType authenticationtype = arr$[i$];
				if (authenticationtype.name().equals(name))
					return authenticationtype;
			}

			throw new IllegalArgumentException(name);
		}

		static 
		{
			CONTAINER = new AuthenticationType("CONTAINER", 0);
			APPLICATION = new AuthenticationType("APPLICATION", 1);
			$VALUES = (new AuthenticationType[] {
				CONTAINER, APPLICATION
			});
		}

		private AuthenticationType(String s, int i)
		{
			super(s, i);
		}
	}


	public abstract String name();

	public abstract Class type();

	public abstract AuthenticationType authenticationType();

	public abstract boolean shareable();

	public abstract String mappedName();

	public abstract String description();
}
