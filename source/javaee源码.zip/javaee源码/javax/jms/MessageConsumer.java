// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageConsumer.java

package javax.jms;


// Referenced classes of package javax.jms:
//			JMSException, MessageListener, Message

public interface MessageConsumer
{

	public abstract String getMessageSelector()
		throws JMSException;

	public abstract MessageListener getMessageListener()
		throws JMSException;

	public abstract void setMessageListener(MessageListener messagelistener)
		throws JMSException;

	public abstract Message receive()
		throws JMSException;

	public abstract Message receive(long l)
		throws JMSException;

	public abstract Message receiveNoWait()
		throws JMSException;

	public abstract void close()
		throws JMSException;
}
