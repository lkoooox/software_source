// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   XAQueueConnection.java

package javax.jms;


// Referenced classes of package javax.jms:
//			JMSException, QueueConnection, XAConnection, XAQueueSession, 
//			QueueSession

public interface XAQueueConnection
	extends XAConnection, QueueConnection
{

	public abstract XAQueueSession createXAQueueSession()
		throws JMSException;

	public abstract QueueSession createQueueSession(boolean flag, int i)
		throws JMSException;
}
