// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Topic.java

package javax.jms;


// Referenced classes of package javax.jms:
//			Destination, JMSException

public interface Topic
	extends Destination
{

	public abstract String getTopicName()
		throws JMSException;

	public abstract String toString();
}
