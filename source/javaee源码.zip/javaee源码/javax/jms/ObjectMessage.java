// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ObjectMessage.java

package javax.jms;

import java.io.Serializable;

// Referenced classes of package javax.jms:
//			JMSException, Message

public interface ObjectMessage
	extends Message
{

	public abstract void setObject(Serializable serializable)
		throws JMSException;

	public abstract Serializable getObject()
		throws JMSException;
}
