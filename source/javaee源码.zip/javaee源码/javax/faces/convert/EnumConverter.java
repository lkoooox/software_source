// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   EnumConverter.java

package javax.faces.convert;

import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.convert:
//			Converter, ConverterException, MessageFactory

public class EnumConverter
	implements Converter, StateHolder
{

	public static final String CONVERTER_ID = "javax.faces.Enum";
	public static final String ENUM_ID = "javax.faces.converter.EnumConverter.ENUM";
	public static final String ENUM_NO_CLASS_ID = "javax.faces.converter.EnumConverter.ENUM_NO_CLASS";
	private Class targetClass;
	private transient boolean isTransient;

	public EnumConverter()
	{
		isTransient = false;
	}

	public EnumConverter(Class targetClass)
	{
		isTransient = false;
		this.targetClass = targetClass;
	}

	public Object getAsObject(FacesContext context, UIComponent component, String value)
	{
		if (context == null || component == null)
			throw new NullPointerException();
		if (value == null)
			return null;
		value = value.trim();
		if (value.length() < 1)
			return null;
		return Enum.valueOf(targetClass, value);
		IllegalArgumentException iae;
		iae;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.EnumConverter.ENUM", new Object[] {
			value, value, MessageFactory.getLabel(context, component)
		}));
	}

	public String getAsString(FacesContext context, UIComponent component, Object value)
	{
		if (context == null || component == null)
			throw new NullPointerException();
		else
			return value != null ? value.toString() : "";
	}

	public void restoreState(FacesContext facesContext, Object object)
	{
		targetClass = (Class)object;
	}

	public Object saveState(FacesContext facesContext)
	{
		return targetClass;
	}

	public void setTransient(boolean b)
	{
		isTransient = b;
	}

	public boolean isTransient()
	{
		return isTransient;
	}
}
