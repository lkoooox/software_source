// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BigDecimalConverter.java

package javax.faces.convert;

import java.math.BigDecimal;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.convert:
//			Converter, ConverterException, MessageFactory

public class BigDecimalConverter
	implements Converter
{

	public static final String CONVERTER_ID = "javax.faces.BigDecimal";
	public static final String DECIMAL_ID = "javax.faces.converter.BigDecimalConverter.DECIMAL";
	public static final String STRING_ID = "javax.faces.converter.STRING";

	public BigDecimalConverter()
	{
	}

	public Object getAsObject(FacesContext context, UIComponent component, String value)
	{
		if (context == null || component == null)
			throw new NullPointerException();
		if (value == null)
			return null;
		value = value.trim();
		if (value.length() < 1)
			return null;
		return new BigDecimal(value);
		NumberFormatException nfe;
		nfe;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.BigDecimalConverter.DECIMAL", new Object[] {
			value, "198.23", MessageFactory.getLabel(context, component)
		}));
		Exception e;
		e;
		throw new ConverterException(e);
	}

	public String getAsString(FacesContext context, UIComponent component, Object value)
	{
		if (context == null || component == null)
			throw new NullPointerException();
		if (value == null)
			return "";
		if (value instanceof String)
			return (String)value;
		return ((BigDecimal)value).toString();
		Exception e;
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
	}
}
