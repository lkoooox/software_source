// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   LongConverter.java

package javax.faces.convert;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.convert:
//			Converter, ConverterException, MessageFactory

public class LongConverter
	implements Converter
{

	public static final String CONVERTER_ID = "javax.faces.Long";
	public static final String LONG_ID = "javax.faces.converter.LongConverter.LONG";
	public static final String STRING_ID = "javax.faces.converter.STRING";

	public LongConverter()
	{
	}

	public Object getAsObject(FacesContext context, UIComponent component, String value)
	{
		if (context == null || component == null)
			throw new NullPointerException();
		if (value == null)
			return null;
		value = value.trim();
		if (value.length() < 1)
			return null;
		return Long.valueOf(value);
		NumberFormatException nfe;
		nfe;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.LongConverter.LONG", new Object[] {
			value, "98765432", MessageFactory.getLabel(context, component)
		}));
		Exception e;
		e;
		throw new ConverterException(e);
	}

	public String getAsString(FacesContext context, UIComponent component, Object value)
	{
		if (context == null || component == null)
			throw new NullPointerException();
		if (value == null)
			return "";
		if (value instanceof String)
			return (String)value;
		return Long.toString(((Long)value).longValue());
		Exception e;
		e;
		throw new ConverterException(MessageFactory.getMessage(context, "javax.faces.converter.STRING", new Object[] {
			value, MessageFactory.getLabel(context, component)
		}), e);
	}
}
