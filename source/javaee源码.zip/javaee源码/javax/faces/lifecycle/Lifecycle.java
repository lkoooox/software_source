// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Lifecycle.java

package javax.faces.lifecycle;

import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseListener;

public abstract class Lifecycle
{

	public Lifecycle()
	{
	}

	public abstract void addPhaseListener(PhaseListener phaselistener);

	public abstract void execute(FacesContext facescontext)
		throws FacesException;

	public abstract PhaseListener[] getPhaseListeners();

	public abstract void removePhaseListener(PhaseListener phaselistener);

	public abstract void render(FacesContext facescontext)
		throws FacesException;
}
