// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   LifecycleFactory.java

package javax.faces.lifecycle;

import java.util.Iterator;

// Referenced classes of package javax.faces.lifecycle:
//			Lifecycle

public abstract class LifecycleFactory
{

	public static final String DEFAULT_LIFECYCLE = "DEFAULT";

	public LifecycleFactory()
	{
	}

	public abstract void addLifecycle(String s, Lifecycle lifecycle);

	public abstract Lifecycle getLifecycle(String s);

	public abstract Iterator getLifecycleIds();
}
