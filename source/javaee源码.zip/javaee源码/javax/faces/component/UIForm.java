// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UIForm.java

package javax.faces.component;

import java.util.Iterator;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.component:
//			UIComponentBase, NamingContainer, UIComponent

public class UIForm extends UIComponentBase
	implements NamingContainer
{

	public static final String COMPONENT_TYPE = "javax.faces.Form";
	public static final String COMPONENT_FAMILY = "javax.faces.Form";
	private boolean submitted;
	private boolean prependId;
	private boolean prependIdSet;

	public UIForm()
	{
		submitted = false;
		prependId = true;
		prependIdSet = false;
		setRendererType("javax.faces.Form");
	}

	public String getFamily()
	{
		return "javax.faces.Form";
	}

	public boolean isSubmitted()
	{
		return submitted;
	}

	public void setSubmitted(boolean submitted)
	{
		this.submitted = submitted;
	}

	public boolean isPrependId()
	{
		ValueExpression ve;
		if (prependIdSet)
			return prependId;
		ve = getValueExpression("prependId");
		if (ve == null)
			break MISSING_BLOCK_LABEL_51;
		return Boolean.TRUE.equals(ve.getValue(getFacesContext().getELContext()));
		ELException e;
		e;
		throw new FacesException(e);
		return prependId;
	}

	public void setPrependId(boolean prependId)
	{
		if (prependId != this.prependId)
			this.prependId = prependId;
		prependIdSet = true;
	}

	public void processDecodes(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		decode(context);
		if (!isSubmitted())
			return;
		UIComponent kid;
		for (Iterator kids = getFacetsAndChildren(); kids.hasNext(); kid.processDecodes(context))
			kid = (UIComponent)kids.next();

	}

	public void processValidators(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (!isSubmitted())
			return;
		UIComponent kid;
		for (Iterator kids = getFacetsAndChildren(); kids.hasNext(); kid.processValidators(context))
			kid = (UIComponent)kids.next();

	}

	public void processUpdates(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (!isSubmitted())
			return;
		UIComponent kid;
		for (Iterator kids = getFacetsAndChildren(); kids.hasNext(); kid.processUpdates(context))
			kid = (UIComponent)kids.next();

	}

	public String getContainerClientId(FacesContext context)
	{
		if (isPrependId())
			return super.getContainerClientId(context);
		for (UIComponent parent = getParent(); parent != null; parent = parent.getParent())
			if (parent instanceof NamingContainer)
				return parent.getContainerClientId(context);

		return null;
	}
}
