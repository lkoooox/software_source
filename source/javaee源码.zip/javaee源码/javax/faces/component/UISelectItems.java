// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UISelectItems.java

package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

public class UISelectItems extends UIComponentBase
{

	public static final String COMPONENT_TYPE = "javax.faces.SelectItems";
	public static final String COMPONENT_FAMILY = "javax.faces.SelectItems";
	private Object value;
	private Object values[];

	public UISelectItems()
	{
		value = null;
		setRendererType(null);
	}

	public String getFamily()
	{
		return "javax.faces.SelectItems";
	}

	public Object getValue()
	{
		ValueExpression ve;
		if (value != null)
			return value;
		ve = getValueExpression("value");
		if (ve == null)
			break MISSING_BLOCK_LABEL_45;
		return ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setValue(Object value)
	{
		this.value = value;
	}

	public Object saveState(FacesContext context)
	{
		if (values == null)
			values = new Object[2];
		values[0] = super.saveState(context);
		values[1] = value;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state)
	{
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		value = values[1];
	}
}
