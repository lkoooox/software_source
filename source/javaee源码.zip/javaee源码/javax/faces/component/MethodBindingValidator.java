// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodBindingValidator.java

package javax.faces.component;

import javax.faces.context.FacesContext;
import javax.faces.el.EvaluationException;
import javax.faces.el.MethodBinding;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

// Referenced classes of package javax.faces.component:
//			MethodBindingAdapterBase, StateHolder, UIComponent

class MethodBindingValidator extends MethodBindingAdapterBase
	implements Validator, StateHolder
{

	private MethodBinding methodBinding;
	private boolean tranzient;

	public MethodBindingValidator()
	{
		methodBinding = null;
		tranzient = false;
	}

	public MethodBindingValidator(MethodBinding methodBinding)
	{
		this.methodBinding = null;
		tranzient = false;
		this.methodBinding = methodBinding;
	}

	public MethodBinding getWrapped()
	{
		return methodBinding;
	}

	public void validate(FacesContext context, UIComponent component, Object value)
		throws ValidatorException
	{
		if (null == context || null == component)
			throw new NullPointerException();
		try
		{
			methodBinding.invoke(context, new Object[] {
				context, component, value
			});
		}
		catch (EvaluationException ee)
		{
			Throwable cause = getExpectedCause(javax/faces/validator/ValidatorException, ee);
			if (cause instanceof ValidatorException)
				throw (ValidatorException)cause;
			if (cause instanceof RuntimeException)
				throw (RuntimeException)cause;
			else
				throw new IllegalStateException(ee.getMessage());
		}
	}

	public Object saveState(FacesContext context)
	{
		Object result = null;
		if (!tranzient)
			if (methodBinding instanceof StateHolder)
			{
				Object stateStruct[] = new Object[2];
				stateStruct[0] = ((StateHolder)methodBinding).saveState(context);
				stateStruct[1] = methodBinding.getClass().getName();
				result = ((Object) (stateStruct));
			} else
			{
				result = methodBinding;
			}
		return result;
	}

	public void restoreState(FacesContext context, Object state)
	{
		if (null == state)
			return;
		if (!(state instanceof MethodBinding))
		{
			Object stateStruct[] = (Object[])(Object[])state;
			Object savedState = stateStruct[0];
			String className = stateStruct[1].toString();
			MethodBinding result = null;
			Class toRestoreClass = null;
			if (null != className)
			{
				try
				{
					toRestoreClass = loadClass(className, this);
				}
				catch (ClassNotFoundException e)
				{
					throw new IllegalStateException(e.getMessage());
				}
				if (null != toRestoreClass)
					try
					{
						result = (MethodBinding)toRestoreClass.newInstance();
					}
					catch (InstantiationException e)
					{
						throw new IllegalStateException(e.getMessage());
					}
					catch (IllegalAccessException a)
					{
						throw new IllegalStateException(a.getMessage());
					}
				if (null != result && null != savedState)
					((StateHolder)result).restoreState(context, savedState);
				methodBinding = result;
			}
		} else
		{
			methodBinding = (MethodBinding)state;
		}
	}

	public boolean isTransient()
	{
		return tranzient;
	}

	public void setTransient(boolean newTransientValue)
	{
		tranzient = newTransientValue;
	}

	private static Class loadClass(String name, Object fallbackClass)
		throws ClassNotFoundException
	{
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		if (loader == null)
			loader = fallbackClass.getClass().getClassLoader();
		return Class.forName(name, false, loader);
	}
}
