// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodExpressionMethodBindingAdapter.java

package javax.faces.component;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Arrays;
import javax.el.*;
import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.el.MethodBinding;

// Referenced classes of package javax.faces.component:
//			StateHolder

class MethodExpressionMethodBindingAdapter extends MethodExpression
	implements Serializable, StateHolder
{

	private static final long serialVersionUID = 0xe6b576262835cc3cL;
	private MethodBinding binding;
	private transient MethodInfo info;
	private boolean tranzient;
	static final boolean $assertionsDisabled = !javax/faces/component/MethodExpressionMethodBindingAdapter.desiredAssertionStatus();

	public MethodExpressionMethodBindingAdapter()
	{
		binding = null;
		info = null;
		tranzient = false;
	}

	MethodExpressionMethodBindingAdapter(MethodBinding binding)
	{
		this.binding = null;
		info = null;
		tranzient = false;
		if (!$assertionsDisabled && null == binding)
		{
			throw new AssertionError();
		} else
		{
			this.binding = binding;
			return;
		}
	}

	public MethodInfo getMethodInfo(ELContext context)
		throws ELException
	{
		if (!$assertionsDisabled && null == binding)
			throw new AssertionError();
		if (context == null)
			throw new NullPointerException("ELContext -> null");
		if (null == info)
		{
			FacesContext facesContext = (FacesContext)context.getContext(javax/faces/context/FacesContext);
			if (null != facesContext)
				try
				{
					info = new MethodInfo(null, binding.getType(facesContext), null);
				}
				catch (Exception e)
				{
					throw new ELException(e);
				}
		}
		return info;
	}

	public Object invoke(ELContext context, Object params[])
		throws ELException
	{
		if (!$assertionsDisabled && null == binding)
			throw new AssertionError();
		if (context == null)
			throw new NullPointerException("ELContext -> null");
		Object result = null;
		FacesContext facesContext = (FacesContext)context.getContext(javax/faces/context/FacesContext);
		if (null != facesContext)
			try
			{
				result = binding.invoke(facesContext, params);
			}
			catch (Exception e)
			{
				throw new ELException(e);
			}
		return result;
	}

	public String getExpressionString()
	{
		if (!$assertionsDisabled && null == binding)
			throw new AssertionError();
		else
			return binding.getExpressionString();
	}

	public boolean isLiteralText()
	{
		if (!$assertionsDisabled && binding == null)
		{
			throw new AssertionError();
		} else
		{
			String expr = binding.getExpressionString();
			return !expr.startsWith("#{") || !expr.endsWith("}");
		}
	}

	public boolean equals(Object other)
	{
		if (other == this)
			return true;
		if (other instanceof MethodExpressionMethodBindingAdapter)
		{
			MethodBinding ob = ((MethodExpressionMethodBindingAdapter)other).getWrapped();
			return binding.equals(ob);
		}
		if (other instanceof MethodExpression)
		{
			MethodExpression expression = (MethodExpression)other;
			String expr = binding.getExpressionString();
			int idx = expr.indexOf('.');
			String target = expr.substring(0, idx).substring(2);
			String t = expr.substring(idx + 1);
			String method = t.substring(0, t.length() - 1);
			FacesContext context = FacesContext.getCurrentInstance();
			ELContext elContext = context.getELContext();
			MethodInfo controlInfo = expression.getMethodInfo(elContext);
			if (!controlInfo.getName().equals(method))
				return false;
			ExpressionFactory factory = context.getApplication().getExpressionFactory();
			ValueExpression ve = factory.createValueExpression(elContext, (new StringBuilder()).append("#{").append(target).append('}').toString(), java/lang/Object);
			if (ve == null)
				return false;
			Object result = ve.getValue(elContext);
			if (result == null)
				return false;
			Method methods[] = result.getClass().getMethods();
			Method arr$[] = methods;
			int len$ = arr$.length;
			for (int i$ = 0; i$ < len$; i$++)
			{
				Method meth = arr$[i$];
				if (meth.getName().equals(method) && meth.getReturnType().equals(controlInfo.getReturnType()) && Arrays.equals(meth.getParameterTypes(), controlInfo.getParamTypes()))
					return true;
			}

		}
		return false;
	}

	public int hashCode()
	{
		if (!$assertionsDisabled && null == binding)
			throw new AssertionError();
		else
			return binding.hashCode();
	}

	public String getDelimiterSyntax()
	{
		return "";
	}

	public Object saveState(FacesContext context)
	{
		Object result = null;
		if (!tranzient)
			if (binding instanceof StateHolder)
			{
				Object stateStruct[] = new Object[2];
				stateStruct[0] = ((StateHolder)binding).saveState(context);
				stateStruct[1] = binding.getClass().getName();
				result = ((Object) (stateStruct));
			} else
			{
				result = binding;
			}
		return result;
	}

	public void restoreState(FacesContext context, Object state)
	{
		if (null == state)
			return;
		if (!(state instanceof MethodBinding))
		{
			Object stateStruct[] = (Object[])(Object[])state;
			Object savedState = stateStruct[0];
			String className = stateStruct[1].toString();
			MethodBinding result = null;
			Class toRestoreClass = null;
			if (null != className)
			{
				try
				{
					toRestoreClass = loadClass(className, this);
				}
				catch (ClassNotFoundException e)
				{
					throw new IllegalStateException(e.getMessage());
				}
				if (null != toRestoreClass)
					try
					{
						result = (MethodBinding)toRestoreClass.newInstance();
					}
					catch (InstantiationException e)
					{
						throw new IllegalStateException(e.getMessage());
					}
					catch (IllegalAccessException a)
					{
						throw new IllegalStateException(a.getMessage());
					}
				if (null != result && null != savedState)
					((StateHolder)result).restoreState(context, savedState);
				binding = result;
			}
		} else
		{
			binding = (MethodBinding)state;
		}
	}

	public boolean isTransient()
	{
		return tranzient;
	}

	public void setTransient(boolean newTransientMethod)
	{
		tranzient = newTransientMethod;
	}

	private static Class loadClass(String name, Object fallbackClass)
		throws ClassNotFoundException
	{
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		if (loader == null)
			loader = fallbackClass.getClass().getClassLoader();
		return Class.forName(name, true, loader);
	}

	public MethodBinding getWrapped()
	{
		return binding;
	}

}
