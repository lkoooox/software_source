// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ContextCallback.java

package javax.faces.component;

import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.component:
//			UIComponent

public interface ContextCallback
{

	public abstract void invokeContextCallback(FacesContext facescontext, UIComponent uicomponent);
}
