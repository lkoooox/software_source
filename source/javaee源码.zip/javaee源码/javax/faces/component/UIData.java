// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UIData.java

package javax.faces.component;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.*;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.*;
import javax.faces.model.*;
import javax.servlet.jsp.jstl.sql.Result;

// Referenced classes of package javax.faces.component:
//			UIComponentBase, ContextCallback, EditableValueHolder, NamingContainer, 
//			SavedState, UIColumn, UIComponent, WrapperEvent

public class UIData extends UIComponentBase
	implements NamingContainer
{

	public static final String COMPONENT_TYPE = "javax.faces.Data";
	public static final String COMPONENT_FAMILY = "javax.faces.Data";
	private int first;
	private boolean firstSet;
	private transient DataModel model;
	private transient Object oldVar;
	private int rowIndex;
	private int rows;
	private boolean rowsSet;
	private Map saved;
	private Object value;
	private String var;
	private Object values[];
	static final boolean $assertionsDisabled = !javax/faces/component/UIData.desiredAssertionStatus();

	public UIData()
	{
		first = 0;
		firstSet = false;
		model = null;
		rowIndex = -1;
		rows = 0;
		rowsSet = false;
		saved = new HashMap();
		value = null;
		var = null;
		setRendererType("javax.faces.Table");
	}

	public String getFamily()
	{
		return "javax.faces.Data";
	}

	public int getFirst()
	{
		if (firstSet)
			return first;
		ValueExpression ve = getValueExpression("first");
		if (ve != null)
		{
			Integer value = null;
			try
			{
				value = (Integer)ve.getValue(getFacesContext().getELContext());
			}
			catch (ELException e)
			{
				throw new FacesException(e);
			}
			if (null == value)
				return first;
			else
				return value.intValue();
		} else
		{
			return first;
		}
	}

	public void setFirst(int first)
	{
		if (first < 0)
		{
			throw new IllegalArgumentException((new StringBuilder()).append("").append(first).toString());
		} else
		{
			this.first = first;
			firstSet = true;
			return;
		}
	}

	public UIComponent getFooter()
	{
		return getFacet("footer");
	}

	public void setFooter(UIComponent footer)
	{
		getFacets().put("footer", footer);
	}

	public UIComponent getHeader()
	{
		return getFacet("header");
	}

	public void setHeader(UIComponent header)
	{
		getFacets().put("header", header);
	}

	public boolean isRowAvailable()
	{
		return getDataModel().isRowAvailable();
	}

	public int getRowCount()
	{
		return getDataModel().getRowCount();
	}

	public Object getRowData()
	{
		return getDataModel().getRowData();
	}

	public int getRowIndex()
	{
		return rowIndex;
	}

	public void setRowIndex(int rowIndex)
	{
		saveDescendantState();
		int previous = this.rowIndex;
		this.rowIndex = rowIndex;
		DataModel localModel = getDataModel();
		localModel.setRowIndex(rowIndex);
		if (var != null)
		{
			Map requestMap = getFacesContext().getExternalContext().getRequestMap();
			if (rowIndex == -1)
				oldVar = requestMap.remove(var);
			else
			if (isRowAvailable())
			{
				requestMap.put(var, getRowData());
			} else
			{
				requestMap.remove(var);
				if (null != oldVar)
				{
					requestMap.put("var", oldVar);
					oldVar = null;
				}
			}
		}
		restoreDescendantState();
	}

	public int getRows()
	{
		if (rowsSet)
			return rows;
		ValueExpression ve = getValueExpression("rows");
		if (ve != null)
		{
			Integer value = null;
			try
			{
				value = (Integer)ve.getValue(getFacesContext().getELContext());
			}
			catch (ELException e)
			{
				throw new FacesException(e);
			}
			if (null == value)
				return rows;
			else
				return value.intValue();
		} else
		{
			return rows;
		}
	}

	public void setRows(int rows)
	{
		if (rows < 0)
		{
			throw new IllegalArgumentException((new StringBuilder()).append("").append(rows).toString());
		} else
		{
			this.rows = rows;
			rowsSet = true;
			return;
		}
	}

	public String getVar()
	{
		return var;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public Object saveState(FacesContext context)
	{
		if (values == null)
			values = new Object[9];
		values[0] = super.saveState(context);
		values[1] = new Integer(first);
		values[2] = firstSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[3] = new Integer(rowIndex);
		values[4] = new Integer(rows);
		values[5] = rowsSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[6] = saved;
		values[7] = value;
		values[8] = var;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state)
	{
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		first = ((Integer)values[1]).intValue();
		firstSet = ((Boolean)values[2]).booleanValue();
		rowIndex = ((Integer)values[3]).intValue();
		rows = ((Integer)values[4]).intValue();
		rowsSet = ((Boolean)values[5]).booleanValue();
		saved = (Map)values[6];
		value = values[7];
		var = (String)values[8];
	}

	public Object getValue()
	{
		ValueExpression ve;
		if (value != null)
			return value;
		ve = getValueExpression("value");
		if (ve == null)
			break MISSING_BLOCK_LABEL_45;
		return ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setValue(Object value)
	{
		setDataModel(null);
		this.value = value;
	}

	/**
	 * @deprecated Method setValueBinding is deprecated
	 */

	public void setValueBinding(String name, ValueBinding binding)
	{
		if ("value".equals(name))
			setDataModel(null);
		else
		if ("var".equals(name) || "rowIndex".equals(name))
			throw new IllegalArgumentException();
		super.setValueBinding(name, binding);
	}

	public void setValueExpression(String name, ValueExpression binding)
	{
		if ("value".equals(name))
			model = null;
		else
		if ("var".equals(name) || "rowIndex".equals(name))
			throw new IllegalArgumentException();
		super.setValueExpression(name, binding);
	}

	public String getClientId(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		String baseClientId = super.getClientId(context);
		if (rowIndex >= 0)
			return (new StringBuilder()).append(baseClientId).append(':').append(rowIndex).toString();
		else
			return baseClientId;
	}

	public boolean invokeOnComponent(FacesContext context, String clientId, ContextCallback callback)
		throws FacesException
	{
		String myId;
		boolean found;
		if (null == context || null == clientId || null == callback)
			throw new NullPointerException();
		myId = super.getClientId(context);
		found = false;
		if (!clientId.equals(myId))
			break MISSING_BLOCK_LABEL_64;
		callback.invokeContextCallback(context, this);
		return true;
		Exception e;
		e;
		throw new FacesException(e);
		Exception exception;
		int savedRowIndex = getRowIndex();
		try
		{
			if (myId.endsWith((new StringBuilder()).append("").append(savedRowIndex).toString()))
			{
				int lastSep = myId.lastIndexOf(':');
				if (!$assertionsDisabled && -1 == lastSep)
					throw new AssertionError();
				myId = myId.substring(0, lastSep);
			}
			int preRowIndexSep;
			int postRowIndexSep;
			if (clientId.startsWith(myId) && -1 != (preRowIndexSep = clientId.indexOf(':', myId.length())) && ++preRowIndexSep < clientId.length() && -1 != (postRowIndexSep = clientId.indexOf(':', preRowIndexSep + 1)))
			{
				int newRow;
				try
				{
					newRow = Integer.valueOf(clientId.substring(preRowIndexSep, postRowIndexSep)).intValue();
				}
				catch (NumberFormatException ex)
				{
					String message = (new StringBuilder()).append("Trying to extract rowIndex from clientId '").append(clientId).append("' ").append(ex.getMessage()).toString();
					throw new NumberFormatException(message);
				}
				setRowIndex(newRow);
				if (isRowAvailable())
					found = super.invokeOnComponent(context, clientId, callback);
			}
		}
		catch (FacesException fe)
		{
			throw fe;
		}
		catch (Exception e)
		{
			throw new FacesException(e);
		}
		finally
		{
			setRowIndex(savedRowIndex);
		}
		setRowIndex(savedRowIndex);
		break MISSING_BLOCK_LABEL_317;
		throw exception;
		return found;
	}

	public void queueEvent(FacesEvent event)
	{
		super.queueEvent(new WrapperEvent(this, event, getRowIndex()));
	}

	public void broadcast(FacesEvent event)
		throws AbortProcessingException
	{
		if (!(event instanceof WrapperEvent))
		{
			super.broadcast(event);
			return;
		}
		WrapperEvent revent = (WrapperEvent)event;
		if (isNestedWithinUIData())
			setDataModel(null);
		int oldRowIndex = getRowIndex();
		setRowIndex(revent.getRowIndex());
		FacesEvent rowEvent = revent.getFacesEvent();
		rowEvent.getComponent().broadcast(rowEvent);
		setRowIndex(oldRowIndex);
	}

	public void encodeBegin(FacesContext context)
		throws IOException
	{
		setDataModel(null);
		if (!keepSaved(context))
			saved = new HashMap();
		super.encodeBegin(context);
	}

	public void processDecodes(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		setDataModel(null);
		if (null == saved || !keepSaved(context))
			saved = new HashMap();
		iterate(context, PhaseId.APPLY_REQUEST_VALUES);
		decode(context);
	}

	public void processValidators(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		if (isNestedWithinUIData())
			setDataModel(null);
		iterate(context, PhaseId.PROCESS_VALIDATIONS);
	}

	public void processUpdates(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		if (isNestedWithinUIData())
			setDataModel(null);
		iterate(context, PhaseId.UPDATE_MODEL_VALUES);
	}

	protected DataModel getDataModel()
	{
		if (model != null)
			return model;
		Object current = getValue();
		if (current == null)
			setDataModel(new ListDataModel(Collections.EMPTY_LIST));
		else
		if (current instanceof DataModel)
			setDataModel((DataModel)current);
		else
		if (current instanceof List)
			setDataModel(new ListDataModel((List)current));
		else
		if ([Ljava/lang/Object;.isAssignableFrom(current.getClass()))
			setDataModel(new ArrayDataModel((Object[])(Object[])current));
		else
		if (current instanceof ResultSet)
			setDataModel(new ResultSetDataModel((ResultSet)current));
		else
		if (current instanceof Result)
			setDataModel(new ResultDataModel((Result)current));
		else
			setDataModel(new ScalarDataModel(current));
		return model;
	}

	protected void setDataModel(DataModel dataModel)
	{
		model = dataModel;
	}

	private void iterate(FacesContext context, PhaseId phaseId)
	{
		setRowIndex(-1);
		for (Iterator facets = getFacets().keySet().iterator(); facets.hasNext();)
		{
			UIComponent facet = (UIComponent)getFacets().get(facets.next());
			if (phaseId == PhaseId.APPLY_REQUEST_VALUES)
				facet.processDecodes(context);
			else
			if (phaseId == PhaseId.PROCESS_VALIDATIONS)
				facet.processValidators(context);
			else
			if (phaseId == PhaseId.UPDATE_MODEL_VALUES)
				facet.processUpdates(context);
			else
				throw new IllegalArgumentException();
		}

		setRowIndex(-1);
		Iterator columns = getChildren().iterator();
		do
		{
			if (!columns.hasNext())
				break;
			UIComponent column = (UIComponent)columns.next();
			if ((column instanceof UIColumn) && column.isRendered())
			{
				Iterator columnFacets = column.getFacets().keySet().iterator();
				while (columnFacets.hasNext()) 
				{
					UIComponent columnFacet = (UIComponent)column.getFacets().get(columnFacets.next());
					if (phaseId == PhaseId.APPLY_REQUEST_VALUES)
						columnFacet.processDecodes(context);
					else
					if (phaseId == PhaseId.PROCESS_VALIDATIONS)
						columnFacet.processValidators(context);
					else
					if (phaseId == PhaseId.UPDATE_MODEL_VALUES)
						columnFacet.processUpdates(context);
					else
						throw new IllegalArgumentException();
				}
			}
		} while (true);
		int processed = 0;
		int rowIndex = getFirst() - 1;
		int rows = getRows();
		do
		{
			if (rows > 0 && ++processed > rows)
				break;
			setRowIndex(++rowIndex);
			if (!isRowAvailable())
				break;
			Iterator kids = getChildren().iterator();
			while (kids.hasNext()) 
			{
				UIComponent kid = (UIComponent)kids.next();
				if (kid instanceof UIColumn)
				{
					Iterator grandkids = kid.getChildren().iterator();
					while (grandkids.hasNext()) 
					{
						UIComponent grandkid = (UIComponent)grandkids.next();
						if (grandkid.isRendered())
							if (phaseId == PhaseId.APPLY_REQUEST_VALUES)
								grandkid.processDecodes(context);
							else
							if (phaseId == PhaseId.PROCESS_VALIDATIONS)
								grandkid.processValidators(context);
							else
							if (phaseId == PhaseId.UPDATE_MODEL_VALUES)
								grandkid.processUpdates(context);
							else
								throw new IllegalArgumentException();
					}
				}
			}
		} while (true);
		setRowIndex(-1);
	}

	private boolean keepSaved(FacesContext context)
	{
		Iterator clientIds = saved.keySet().iterator();
label0:
		do
			if (clientIds.hasNext())
			{
				String clientId = (String)clientIds.next();
				Iterator messages = context.getMessages(clientId);
				FacesMessage message;
				do
				{
					if (!messages.hasNext())
						continue label0;
					message = (FacesMessage)messages.next();
				} while (message.getSeverity().compareTo(FacesMessage.SEVERITY_ERROR) < 0);
				break;
			} else
			{
				return isNestedWithinUIData();
			}
		while (true);
		return true;
	}

	private boolean isNestedWithinUIData()
	{
		for (UIComponent parent = this; null != (parent = parent.getParent());)
			if (parent instanceof UIData)
				return true;

		return false;
	}

	private void restoreDescendantState()
	{
		FacesContext context = getFacesContext();
		Iterator kids = getChildren().iterator();
		do
		{
			if (!kids.hasNext())
				break;
			UIComponent kid = (UIComponent)kids.next();
			if (kid instanceof UIColumn)
				restoreDescendantState(kid, context);
		} while (true);
	}

	private void restoreDescendantState(UIComponent component, FacesContext context)
	{
		String id = component.getId();
		component.setId(id);
		if (component instanceof EditableValueHolder)
		{
			EditableValueHolder input = (EditableValueHolder)component;
			String clientId = component.getClientId(context);
			SavedState state = (SavedState)saved.get(clientId);
			if (state == null)
				state = new SavedState();
			input.setValue(state.getValue());
			input.setValid(state.isValid());
			input.setSubmittedValue(state.getSubmittedValue());
			input.setLocalValueSet(state.isLocalValueSet());
		}
		for (Iterator kids = component.getChildren().iterator(); kids.hasNext(); restoreDescendantState((UIComponent)kids.next(), context));
		Iterator facetNames = component.getFacets().keySet().iterator();
		do
		{
			if (!facetNames.hasNext())
				break;
			UIComponent c = component.getFacet((String)facetNames.next());
			if (c != null)
				restoreDescendantState(c, context);
		} while (true);
	}

	private void saveDescendantState()
	{
		FacesContext context = getFacesContext();
		Iterator kids = getChildren().iterator();
		do
		{
			if (!kids.hasNext())
				break;
			UIComponent kid = (UIComponent)kids.next();
			if (kid instanceof UIColumn)
				saveDescendantState(kid, context);
		} while (true);
	}

	private void saveDescendantState(UIComponent component, FacesContext context)
	{
		if (component instanceof EditableValueHolder)
		{
			EditableValueHolder input = (EditableValueHolder)component;
			String clientId = component.getClientId(context);
			SavedState state = (SavedState)saved.get(clientId);
			if (state == null)
			{
				state = new SavedState();
				saved.put(clientId, state);
			}
			state.setValue(input.getLocalValue());
			state.setValid(input.isValid());
			state.setSubmittedValue(input.getSubmittedValue());
			state.setLocalValueSet(input.isLocalValueSet());
		}
		for (Iterator kids = component.getChildren().iterator(); kids.hasNext(); saveDescendantState((UIComponent)kids.next(), context));
		Iterator facetNames = component.getFacets().keySet().iterator();
		do
		{
			if (!facetNames.hasNext())
				break;
			UIComponent c = component.getFacet((String)facetNames.next());
			if (c != null)
				saveDescendantState(c, context);
		} while (true);
	}

}
