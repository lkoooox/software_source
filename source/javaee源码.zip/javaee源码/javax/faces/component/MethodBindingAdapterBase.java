// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodBindingAdapterBase.java

package javax.faces.component;


abstract class MethodBindingAdapterBase
{

	MethodBindingAdapterBase()
	{
	}

	Throwable getExpectedCause(Class expectedExceptionClass, Throwable exception)
	{
		Throwable result = exception.getCause();
		if (null != result && !result.getClass().isAssignableFrom(expectedExceptionClass))
			result = getExpectedCause(expectedExceptionClass, result);
		return result;
	}
}
