// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UIComponentBase.java

package javax.faces.component;

import java.beans.*;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.event.*;
import javax.faces.render.RenderKit;
import javax.faces.render.Renderer;

// Referenced classes of package javax.faces.component:
//			UIComponent, NamingContainer, StateHolderSaver, UIViewRoot, 
//			ValueBindingValueExpressionAdapter, ValueExpressionValueBindingAdapter, ContextCallback

public abstract class UIComponentBase extends UIComponent
{
	private class AttributesMap
		implements Map, Serializable
	{

		private Map attributes;
		final UIComponentBase this$0;

		public boolean containsKey(Object keyObj)
		{
			String key = (String)keyObj;
			PropertyDescriptor pd = getPropertyDescriptor(key);
			if (pd == null)
			{
				if (attributes != null)
					return attributes.containsKey(key);
				else
					return false;
			} else
			{
				return false;
			}
		}

		public Object get(Object keyObj)
		{
			String key;
			PropertyDescriptor pd;
			key = (String)keyObj;
			if (key == null)
				throw new NullPointerException();
			pd = getPropertyDescriptor(key);
			if (pd == null)
				break MISSING_BLOCK_LABEL_90;
			Method readMethod = pd.getReadMethod();
			if (readMethod != null)
				return readMethod.invoke(UIComponentBase.this, UIComponentBase.empty);
			try
			{
				throw new IllegalArgumentException(key);
			}
			catch (IllegalAccessException e)
			{
				throw new FacesException(e);
			}
			catch (InvocationTargetException e)
			{
				throw new FacesException(e.getTargetException());
			}
			ValueExpression ve;
			Object result;
			if (attributes != null && attributes.containsKey(key))
				return attributes.get(key);
			ve = getValueExpression(key);
			if (ve == null)
				break MISSING_BLOCK_LABEL_171;
			result = null;
			result = ve.getValue(getFacesContext().getELContext());
			return result;
			ELException e;
			e;
			throw new FacesException(e);
			return null;
		}

		public Object put(Object keyValue, Object value)
		{
			String key;
			PropertyDescriptor pd;
			if (keyValue == null)
				throw new NullPointerException();
			if (!(keyValue instanceof String))
				throw new ClassCastException("Key must be a String");
			key = keyValue.toString();
			pd = getPropertyDescriptor(key);
			if (pd == null)
				break MISSING_BLOCK_LABEL_149;
			Object result;
			result = null;
			Method readMethod = pd.getReadMethod();
			if (readMethod != null)
				result = readMethod.invoke(UIComponentBase.this, UIComponentBase.empty);
			Method writeMethod = pd.getWriteMethod();
			if (writeMethod != null)
				writeMethod.invoke(UIComponentBase.this, new Object[] {
					value
				});
			else
				throw new IllegalArgumentException();
			return result;
			IllegalAccessException e;
			e;
			throw new FacesException(e);
			e;
			throw new FacesException(e.getTargetException());
			if (value == null)
				throw new NullPointerException();
			if (attributes == null)
				initMap();
			return attributes.put(key, value);
		}

		public void putAll(Map map)
		{
			if (map == null)
				throw new NullPointerException();
			if (attributes == null)
				initMap();
			attributes.putAll(map);
		}

		public Object remove(Object keyObj)
		{
			String key = (String)keyObj;
			if (key == null)
				throw new NullPointerException();
			PropertyDescriptor pd = getPropertyDescriptor(key);
			if (pd != null)
				throw new IllegalArgumentException(key);
			if (attributes != null)
				return attributes.remove(key);
			else
				return null;
		}

		public int size()
		{
			return attributes == null ? 0 : attributes.size();
		}

		public boolean isEmpty()
		{
			return attributes == null || attributes.isEmpty();
		}

		public boolean containsValue(Object value)
		{
			return attributes != null && attributes.containsValue(value);
		}

		public void clear()
		{
			if (attributes != null)
				attributes.clear();
		}

		public Set keySet()
		{
			return attributes == null ? Collections.EMPTY_SET : attributes.keySet();
		}

		public Collection values()
		{
			return ((Collection) (attributes == null ? Collections.EMPTY_LIST : attributes.values()));
		}

		public Set entrySet()
		{
			return attributes == null ? Collections.EMPTY_SET : attributes.entrySet();
		}

		Map getBackingAttributes()
		{
			return attributes;
		}

		public boolean equals(Object o)
		{
			Map t;
			if (o == this)
				return true;
			if (!(o instanceof Map))
				return false;
			t = (Map)o;
			if (t.size() != size())
				return false;
			Iterator i$ = entrySet().iterator();
_L2:
			Object key;
			Object value;
			do
			{
				if (!i$.hasNext())
					break MISSING_BLOCK_LABEL_147;
				Object e = i$.next();
				java.util.Map.Entry entry = (java.util.Map.Entry)e;
				key = entry.getKey();
				value = entry.getValue();
				if (value != null)
					continue; /* Loop/switch isn't completed */
			} while (t.get(key) == null && t.containsKey(key));
			return false;
			if (value.equals(t.get(key))) goto _L2; else goto _L1
_L1:
			return false;
			ClassCastException unused;
			unused;
			return false;
			unused;
			return false;
			return true;
		}

		public int hashCode()
		{
			int h = 0;
			for (Iterator i$ = entrySet().iterator(); i$.hasNext();)
			{
				Object o = i$.next();
				h += o.hashCode();
			}

			return h;
		}

		private void initMap()
		{
			attributes = new HashMap(8);
		}

		private AttributesMap()
		{
			this$0 = UIComponentBase.this;
			super();
		}

		private AttributesMap(Map attributes)
		{
			this$0 = UIComponentBase.this;
			super();
			this.attributes = attributes;
		}


	}

	private class ChildrenList extends ArrayList
	{

		final UIComponentBase this$0;

		public void add(int index, UIComponent element)
		{
			if (element == null)
				throw new NullPointerException();
			if (index < 0 || index > size())
			{
				throw new IndexOutOfBoundsException();
			} else
			{
				eraseParent(element);
				element.setParent(UIComponentBase.this);
				super.add(index, element);
				return;
			}
		}

		public boolean add(UIComponent element)
		{
			if (element == null)
			{
				throw new NullPointerException();
			} else
			{
				eraseParent(element);
				element.setParent(UIComponentBase.this);
				return super.add(element);
			}
		}

		public boolean addAll(Collection collection)
		{
			Iterator elements = (new ArrayList(collection)).iterator();
			boolean changed;
			for (changed = false; elements.hasNext(); changed = true)
			{
				UIComponent element = (UIComponent)elements.next();
				if (element == null)
					throw new NullPointerException();
				add(element);
			}

			return changed;
		}

		public boolean addAll(int index, Collection collection)
		{
			Iterator elements = (new ArrayList(collection)).iterator();
			boolean changed;
			for (changed = false; elements.hasNext(); changed = true)
			{
				UIComponent element = (UIComponent)elements.next();
				if (element == null)
					throw new NullPointerException();
				add(index++, element);
			}

			return changed;
		}

		public void clear()
		{
			int n = size();
			if (n < 1)
				return;
			for (int i = 0; i < n; i++)
			{
				UIComponent child = (UIComponent)get(i);
				child.setParent(null);
			}

			super.clear();
		}

		public Iterator iterator()
		{
			return new ChildrenListIterator(this);
		}

		public ListIterator listIterator()
		{
			return new ChildrenListIterator(this);
		}

		public ListIterator listIterator(int index)
		{
			return new ChildrenListIterator(this, index);
		}

		public UIComponent remove(int index)
		{
			UIComponent child = (UIComponent)get(index);
			super.remove(index);
			child.setParent(null);
			return child;
		}

		public boolean remove(Object elementObj)
		{
			UIComponent element = (UIComponent)elementObj;
			if (element == null)
				throw new NullPointerException();
			if (super.remove(element))
			{
				element.setParent(null);
				return true;
			} else
			{
				return false;
			}
		}

		public boolean removeAll(Collection collection)
		{
			boolean result = false;
			Iterator elements = collection.iterator();
			do
			{
				if (!elements.hasNext())
					break;
				if (remove(elements.next()))
					result = true;
			} while (true);
			return result;
		}

		public boolean retainAll(Collection collection)
		{
			boolean modified = false;
			Iterator items = iterator();
			do
			{
				if (!items.hasNext())
					break;
				if (!collection.contains(items.next()))
				{
					items.remove();
					modified = true;
				}
			} while (true);
			return modified;
		}

		public UIComponent set(int index, UIComponent element)
		{
			if (element == null)
				throw new NullPointerException();
			if (index < 0 || index >= size())
			{
				throw new IndexOutOfBoundsException();
			} else
			{
				eraseParent(element);
				UIComponent previous = (UIComponent)get(index);
				previous.setParent(null);
				element.setParent(UIComponentBase.this);
				super.set(index, element);
				return previous;
			}
		}

		public volatile Object remove(int x0)
		{
			return remove(x0);
		}

		public volatile void add(int x0, Object x1)
		{
			add(x0, (UIComponent)x1);
		}

		public volatile boolean add(Object x0)
		{
			return add((UIComponent)x0);
		}

		public volatile Object set(int x0, Object x1)
		{
			return set(x0, (UIComponent)x1);
		}

		private ChildrenList()
		{
			this$0 = UIComponentBase.this;
			super();
		}

	}

	private static class ChildrenListIterator
		implements ListIterator
	{

		private ChildrenList list;
		private int index;
		private int last;

		public boolean hasNext()
		{
			return index < list.size();
		}

		public UIComponent next()
		{
			UIComponent o;
			o = (UIComponent)list.get(index);
			last = index++;
			return o;
			IndexOutOfBoundsException e;
			e;
			throw new NoSuchElementException((new StringBuilder()).append("").append(index).toString());
		}

		public void remove()
		{
			if (last == -1)
				throw new IllegalStateException();
			list.remove(last);
			if (last < index)
				index--;
			last = -1;
		}

		public void add(UIComponent o)
		{
			last = -1;
			list.add(index++, o);
		}

		public boolean hasPrevious()
		{
			return index > 1;
		}

		public int nextIndex()
		{
			return index;
		}

		public UIComponent previous()
		{
			UIComponent o;
			int current = index - 1;
			o = (UIComponent)list.get(current);
			last = current;
			index = current;
			return o;
			IndexOutOfBoundsException e;
			e;
			throw new NoSuchElementException();
		}

		public int previousIndex()
		{
			return index - 1;
		}

		public void set(UIComponent o)
		{
			if (last == -1)
			{
				throw new IllegalStateException();
			} else
			{
				list.set(last, o);
				return;
			}
		}

		public volatile void add(Object x0)
		{
			add((UIComponent)x0);
		}

		public volatile void set(Object x0)
		{
			set((UIComponent)x0);
		}

		public volatile Object previous()
		{
			return previous();
		}

		public volatile Object next()
		{
			return next();
		}

		public ChildrenListIterator(ChildrenList list)
		{
			last = -1;
			this.list = list;
			index = 0;
		}

		public ChildrenListIterator(ChildrenList list, int index)
		{
			last = -1;
			this.list = list;
			if (index < 0 || index >= list.size())
			{
				throw new IndexOutOfBoundsException((new StringBuilder()).append("").append(index).toString());
			} else
			{
				this.index = index;
				return;
			}
		}
	}

	private static final class FacetsAndChildrenIterator
		implements Iterator
	{

		private Iterator iterator;
		private boolean childMode;
		private UIComponent c;

		private void update()
		{
			if (iterator == null)
			{
				if (c.getFacetCount() != 0)
				{
					iterator = c.getFacets().values().iterator();
					childMode = false;
				} else
				if (c.getChildCount() != 0)
				{
					iterator = c.getChildren().iterator();
					childMode = true;
				} else
				{
					iterator = UIComponentBase.EMPTY_ITERATOR;
					childMode = true;
				}
			} else
			if (!childMode && !iterator.hasNext() && c.getChildCount() != 0)
			{
				iterator = c.getChildren().iterator();
				childMode = true;
			}
		}

		public boolean hasNext()
		{
			update();
			return iterator.hasNext();
		}

		public UIComponent next()
		{
			update();
			return (UIComponent)iterator.next();
		}

		public void remove()
		{
			throw new UnsupportedOperationException();
		}

		public volatile Object next()
		{
			return next();
		}

		public FacetsAndChildrenIterator(UIComponent c)
		{
			this.c = c;
			childMode = false;
		}
	}

	private class FacetsMap extends HashMap
	{

		final UIComponentBase this$0;

		public void clear()
		{
			for (Iterator keys = keySet().iterator(); keys.hasNext(); keys.remove())
			{
				String key = (String)keys.next();
			}

			super.clear();
		}

		public Set entrySet()
		{
			return new FacetsMapEntrySet(this);
		}

		public Set keySet()
		{
			return new FacetsMapKeySet(this);
		}

		public UIComponent put(String key, UIComponent value)
		{
			if (key == null || value == null)
				throw new NullPointerException();
			if (!(key instanceof String) || !(value instanceof UIComponent))
				throw new ClassCastException();
			UIComponent previous = (UIComponent)super.get(key);
			if (previous != null)
				previous.setParent(null);
			eraseParent(value);
			value.setParent(UIComponentBase.this);
			return (UIComponent)super.put(key, value);
		}

		public void putAll(Map map)
		{
			if (map == null)
				throw new NullPointerException();
			java.util.Map.Entry entry;
			for (Iterator i$ = map.entrySet().iterator(); i$.hasNext(); put((String)entry.getKey(), (UIComponent)entry.getValue()))
				entry = (java.util.Map.Entry)i$.next();

		}

		public UIComponent remove(Object key)
		{
			UIComponent previous = (UIComponent)get(key);
			if (previous != null)
				previous.setParent(null);
			super.remove(key);
			return previous;
		}

		public Collection values()
		{
			return new FacetsMapValues(this);
		}

		Iterator keySetIterator()
		{
			return (new ArrayList(super.keySet())).iterator();
		}

		public volatile Object remove(Object x0)
		{
			return remove(x0);
		}

		public volatile Object put(Object x0, Object x1)
		{
			return put((String)x0, (UIComponent)x1);
		}

		private FacetsMap()
		{
			this$0 = UIComponentBase.this;
			super();
		}

	}

	private static class FacetsMapEntrySet extends AbstractSet
	{

		private FacetsMap map;

		public boolean add(java.util.Map.Entry o)
		{
			throw new UnsupportedOperationException();
		}

		public boolean addAll(Collection c)
		{
			throw new UnsupportedOperationException();
		}

		public void clear()
		{
			map.clear();
		}

		public boolean contains(Object o)
		{
			if (o == null)
				throw new NullPointerException();
			if (!(o instanceof java.util.Map.Entry))
				return false;
			java.util.Map.Entry e = (java.util.Map.Entry)o;
			Object k = e.getKey();
			Object v = e.getValue();
			if (!map.containsKey(k))
				return false;
			if (v == null)
				return map.get(k) == null;
			else
				return v.equals(map.get(k));
		}

		public boolean isEmpty()
		{
			return map.isEmpty();
		}

		public Iterator iterator()
		{
			return new FacetsMapEntrySetIterator(map);
		}

		public boolean remove(Object o)
		{
			if (o == null)
				throw new NullPointerException();
			if (!(o instanceof java.util.Map.Entry))
				return false;
			Object k = ((java.util.Map.Entry)o).getKey();
			if (map.containsKey(k))
			{
				map.remove(k);
				return true;
			} else
			{
				return false;
			}
		}

		public boolean removeAll(Collection c)
		{
			boolean result = false;
			Iterator v = c.iterator();
			do
			{
				if (!v.hasNext())
					break;
				if (remove(v.next()))
					result = true;
			} while (true);
			return result;
		}

		public boolean retainAll(Collection c)
		{
			boolean result = false;
			Iterator v = iterator();
			do
			{
				if (!v.hasNext())
					break;
				if (!c.contains(v.next()))
				{
					v.remove();
					result = true;
				}
			} while (true);
			return result;
		}

		public int size()
		{
			return map.size();
		}

		public volatile boolean add(Object x0)
		{
			return add((java.util.Map.Entry)x0);
		}

		public FacetsMapEntrySet(FacetsMap map)
		{
			this.map = null;
			this.map = map;
		}
	}

	private static class FacetsMapEntrySetEntry
		implements java.util.Map.Entry
	{

		private FacetsMap map;
		private String key;

		public boolean equals(Object o)
		{
			if (o == null)
				return false;
			if (!(o instanceof java.util.Map.Entry))
				return false;
			java.util.Map.Entry e = (java.util.Map.Entry)o;
			if (key == null)
			{
				if (e.getKey() != null)
					return false;
			} else
			if (!key.equals(e.getKey()))
				return false;
			UIComponent v = (UIComponent)map.get(key);
			if (v == null)
			{
				if (e.getValue() != null)
					return false;
			} else
			if (!v.equals(e.getValue()))
				return false;
			return true;
		}

		public String getKey()
		{
			return key;
		}

		public UIComponent getValue()
		{
			return (UIComponent)map.get(key);
		}

		public int hashCode()
		{
			Object value = map.get(key);
			return (key != null ? key.hashCode() : 0) ^ (value != null ? value.hashCode() : 0);
		}

		public UIComponent setValue(UIComponent value)
		{
			UIComponent previous = (UIComponent)map.get(key);
			map.put(key, value);
			return previous;
		}

		public volatile Object setValue(Object x0)
		{
			return setValue((UIComponent)x0);
		}

		public volatile Object getValue()
		{
			return getValue();
		}

		public volatile Object getKey()
		{
			return getKey();
		}

		public FacetsMapEntrySetEntry(FacetsMap map, String key)
		{
			this.map = map;
			this.key = key;
		}
	}

	private static class FacetsMapEntrySetIterator
		implements Iterator
	{

		private FacetsMap map;
		private Iterator iterator;
		private java.util.Map.Entry last;

		public boolean hasNext()
		{
			return iterator.hasNext();
		}

		public java.util.Map.Entry next()
		{
			last = new FacetsMapEntrySetEntry(map, (String)iterator.next());
			return last;
		}

		public void remove()
		{
			if (last == null)
			{
				throw new IllegalStateException();
			} else
			{
				map.remove(last.getKey());
				last = null;
				return;
			}
		}

		public volatile Object next()
		{
			return next();
		}

		public FacetsMapEntrySetIterator(FacetsMap map)
		{
			this.map = null;
			iterator = null;
			last = null;
			this.map = map;
			iterator = map.keySetIterator();
		}
	}

	private static class FacetsMapKeySet extends AbstractSet
	{

		private FacetsMap map;

		public boolean add(String o)
		{
			throw new UnsupportedOperationException();
		}

		public boolean addAll(Collection c)
		{
			throw new UnsupportedOperationException();
		}

		public void clear()
		{
			map.clear();
		}

		public boolean contains(Object o)
		{
			return map.containsKey(o);
		}

		public boolean containsAll(Collection c)
		{
			for (Iterator v = c.iterator(); v.hasNext();)
				if (!map.containsKey(v.next()))
					return false;

			return true;
		}

		public boolean isEmpty()
		{
			return map.size() == 0;
		}

		public Iterator iterator()
		{
			return new FacetsMapKeySetIterator(map);
		}

		public boolean remove(Object o)
		{
			if (map.containsKey(o))
			{
				map.remove(o);
				return true;
			} else
			{
				return false;
			}
		}

		public boolean removeAll(Collection c)
		{
			boolean result = false;
			Iterator v = c.iterator();
			do
			{
				if (!v.hasNext())
					break;
				Object o = v.next();
				if (map.containsKey(o))
				{
					map.remove(o);
					result = true;
				}
			} while (true);
			return result;
		}

		public boolean retainAll(Collection c)
		{
			boolean result = false;
			Iterator v = iterator();
			do
			{
				if (!v.hasNext())
					break;
				if (!c.contains(v.next()))
				{
					v.remove();
					result = true;
				}
			} while (true);
			return result;
		}

		public int size()
		{
			return map.size();
		}

		public volatile boolean add(Object x0)
		{
			return add((String)x0);
		}

		public FacetsMapKeySet(FacetsMap map)
		{
			this.map = null;
			this.map = map;
		}
	}

	private static class FacetsMapKeySetIterator
		implements Iterator
	{

		private FacetsMap map;
		private Iterator iterator;
		private String last;

		public boolean hasNext()
		{
			return iterator.hasNext();
		}

		public String next()
		{
			last = (String)iterator.next();
			return last;
		}

		public void remove()
		{
			if (last == null)
			{
				throw new IllegalStateException();
			} else
			{
				map.remove(last);
				last = null;
				return;
			}
		}

		public volatile Object next()
		{
			return next();
		}

		public FacetsMapKeySetIterator(FacetsMap map)
		{
			this.map = null;
			iterator = null;
			last = null;
			this.map = map;
			iterator = map.keySetIterator();
		}
	}

	private static class FacetsMapValues extends AbstractCollection
	{

		private FacetsMap map;

		public boolean add(UIComponent o)
		{
			throw new UnsupportedOperationException();
		}

		public boolean addAll(Collection c)
		{
			throw new UnsupportedOperationException();
		}

		public void clear()
		{
			map.clear();
		}

		public boolean isEmpty()
		{
			return map.size() == 0;
		}

		public Iterator iterator()
		{
			return new FacetsMapValuesIterator(map);
		}

		public int size()
		{
			return map.size();
		}

		public volatile boolean add(Object x0)
		{
			return add((UIComponent)x0);
		}

		public FacetsMapValues(FacetsMap map)
		{
			this.map = map;
		}
	}

	private static class FacetsMapValuesIterator
		implements Iterator
	{

		private FacetsMap map;
		private Iterator iterator;
		private Object last;

		public boolean hasNext()
		{
			return iterator.hasNext();
		}

		public UIComponent next()
		{
			last = iterator.next();
			return (UIComponent)map.get(last);
		}

		public void remove()
		{
			if (last == null)
			{
				throw new IllegalStateException();
			} else
			{
				map.remove(last);
				last = null;
				return;
			}
		}

		public volatile Object next()
		{
			return next();
		}

		public FacetsMapValuesIterator(FacetsMap map)
		{
			this.map = null;
			iterator = null;
			last = null;
			this.map = map;
			iterator = map.keySetIterator();
		}
	}


	private static Logger log = Logger.getLogger("javax.faces.component", "javax.faces.LogStrings");
	private static Map descriptors = new WeakHashMap();
	private Map pdMap;
	private static Object empty[] = new Object[0];
	private AttributesMap attributes;
	private String clientId;
	private String id;
	private UIComponent parent;
	private boolean rendered;
	private boolean renderedSet;
	private String rendererType;
	private List children;
	private static final String SEPARATOR_STRING = ":";
	private Map facets;
	private List listeners;
	private static final int MY_STATE = 0;
	private static final int CHILD_STATE = 1;
	private Object values[];
	private boolean transientFlag;
	private static final Object EMPTY_ARRAY[] = new Object[0];
	private static final Iterator EMPTY_ITERATOR = new Iterator() {

		public void remove()
		{
			throw new UnsupportedOperationException();
		}

		public Object next()
		{
			throw new NoSuchElementException("Empty Iterator");
		}

		public boolean hasNext()
		{
			return false;
		}

	};
	static final boolean $assertionsDisabled = !javax/faces/component/UIComponentBase.desiredAssertionStatus();

	public UIComponentBase()
	{
		pdMap = null;
		attributes = null;
		clientId = null;
		id = null;
		parent = null;
		rendered = true;
		renderedSet = false;
		rendererType = null;
		children = null;
		facets = null;
		transientFlag = false;
		populateDescriptorsMapIfNecessary();
	}

	private void populateDescriptorsMapIfNecessary()
	{
		Class clazz = getClass();
		pdMap = (Map)descriptors.get(clazz);
		if (null != pdMap)
			return;
		PropertyDescriptor pd[] = getPropertyDescriptors();
		if (pd != null)
		{
			pdMap = new WeakHashMap(pd.length);
			PropertyDescriptor arr$[] = pd;
			int len$ = arr$.length;
			for (int i$ = 0; i$ < len$; i$++)
			{
				PropertyDescriptor aPd = arr$[i$];
				pdMap.put(aPd.getName(), aPd);
			}

			if (log.isLoggable(Level.FINE))
				log.log(Level.FINE, "fine.component.populating_descriptor_map", new Object[] {
					clazz, Thread.currentThread().getName()
				});
			Map reCheckMap = (Map)descriptors.get(clazz);
			if (null != reCheckMap)
				return;
			descriptors.put(clazz, pdMap);
		}
	}

	private PropertyDescriptor getPropertyDescriptor(String name)
	{
		if (pdMap != null)
			return (PropertyDescriptor)pdMap.get(name);
		else
			return null;
	}

	private PropertyDescriptor[] getPropertyDescriptors()
	{
		PropertyDescriptor pd[] = null;
		try
		{
			pd = Introspector.getBeanInfo(getClass()).getPropertyDescriptors();
		}
		catch (IntrospectionException e)
		{
			throw new FacesException(e);
		}
		return pd;
	}

	public Map getAttributes()
	{
		if (attributes == null)
			attributes = new AttributesMap();
		return attributes;
	}

	/**
	 * @deprecated Method getValueBinding is deprecated
	 */

	public ValueBinding getValueBinding(String name)
	{
		if (name == null)
			throw new NullPointerException();
		ValueBinding result = null;
		ValueExpression ve = null;
		if (null != (ve = getValueExpression(name)))
			if (ve.getClass() == javax/faces/component/ValueExpressionValueBindingAdapter)
				result = ((ValueExpressionValueBindingAdapter)ve).getWrapped();
			else
				result = new ValueBindingValueExpressionAdapter(ve);
		return result;
	}

	/**
	 * @deprecated Method setValueBinding is deprecated
	 */

	public void setValueBinding(String name, ValueBinding binding)
	{
		if (name == null)
			throw new NullPointerException();
		if (binding != null)
		{
			ValueExpressionValueBindingAdapter adapter = new ValueExpressionValueBindingAdapter(binding);
			setValueExpression(name, adapter);
		} else
		{
			setValueExpression(name, null);
		}
	}

	public ValueExpression getValueExpression(String name)
	{
		return super.getValueExpression(name);
	}

	public void setValueExpression(String name, ValueExpression binding)
	{
		super.setValueExpression(name, binding);
	}

	public String getClientId(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (clientId == null)
		{
			UIComponent parent = getNamingContainer();
			String parentId = null;
			if (parent != null)
				parentId = parent.getContainerClientId(context);
			clientId = id;
			if (clientId == null)
				clientId = context.getViewRoot().createUniqueId();
			if (parentId != null)
				clientId = (new StringBuilder()).append(parentId).append(':').append(clientId).toString();
			Renderer renderer = getRenderer(context);
			if (renderer != null)
				clientId = renderer.convertClientId(context, clientId);
		}
		return clientId;
	}

	private UIComponent getNamingContainer()
	{
		for (UIComponent namingContainer = getParent(); namingContainer != null; namingContainer = namingContainer.getParent())
			if (namingContainer instanceof NamingContainer)
				return namingContainer;

		return null;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		validateId(id);
		this.id = id;
		clientId = null;
	}

	public UIComponent getParent()
	{
		return parent;
	}

	public void setParent(UIComponent parent)
	{
		this.parent = parent;
	}

	public boolean isRendered()
	{
		if (renderedSet)
			return rendered;
		ValueExpression ve = getValueExpression("rendered");
		if (ve != null)
		{
			boolean result = false;
			try
			{
				result = !Boolean.FALSE.equals(ve.getValue(getFacesContext().getELContext()));
			}
			catch (ELException e)
			{
				throw new FacesException(e);
			}
			return result;
		} else
		{
			return rendered;
		}
	}

	public void setRendered(boolean rendered)
	{
		this.rendered = rendered;
		renderedSet = true;
	}

	public String getRendererType()
	{
		if (rendererType != null)
			return rendererType;
		ValueExpression ve = getValueExpression("rendererType");
		if (ve != null)
		{
			String result = null;
			try
			{
				result = (String)ve.getValue(getFacesContext().getELContext());
			}
			catch (ELException e)
			{
				throw new FacesException(e);
			}
			return result;
		} else
		{
			return null;
		}
	}

	public void setRendererType(String rendererType)
	{
		this.rendererType = rendererType;
	}

	public boolean getRendersChildren()
	{
		boolean result = false;
		Renderer renderer = null;
		if (getRendererType() != null && null != (renderer = getRenderer(getFacesContext())))
			result = renderer.getRendersChildren();
		return result;
	}

	public List getChildren()
	{
		if (children == null)
			children = new ChildrenList();
		return children;
	}

	public int getChildCount()
	{
		if (children != null)
			return children.size();
		else
			return 0;
	}

	private void eraseParent(UIComponent component)
	{
label0:
		{
			UIComponent parent = component.getParent();
			if (parent == null)
				return;
			if (parent.getChildCount() > 0)
			{
				List children = parent.getChildren();
				int index = children.indexOf(component);
				if (index >= 0)
				{
					children.remove(index);
					return;
				}
			}
			if (parent.getFacetCount() <= 0)
				break label0;
			Map facets = parent.getFacets();
			Iterator entries = facets.entrySet().iterator();
			java.util.Map.Entry entry;
			do
			{
				if (!entries.hasNext())
					break label0;
				entry = (java.util.Map.Entry)entries.next();
			} while (entry.getValue() != component);
			entries.remove();
			return;
		}
		throw new IllegalStateException("Parent was not null, but this component not related");
	}

	private void validateId(String id)
	{
		if (id == null)
			return;
		int n = id.length();
		if (n < 1)
			throw new IllegalArgumentException();
		for (int i = 0; i < n; i++)
		{
			char c = id.charAt(i);
			if (i == 0)
			{
				if (!Character.isLetter(c) && c != '_')
					throw new IllegalArgumentException(id);
				continue;
			}
			if (!Character.isLetter(c) && !Character.isDigit(c) && c != '-' && c != '_')
				throw new IllegalArgumentException(id);
		}

	}

	public UIComponent findComponent(String expr)
	{
		if (expr == null)
			throw new NullPointerException();
		UIComponent base = this;
		if (expr.charAt(0) == ':')
		{
			for (; base.getParent() != null; base = base.getParent());
			expr = expr.substring(1);
		} else
		{
			for (; base.getParent() != null && !(base instanceof NamingContainer); base = base.getParent());
		}
		UIComponent result = null;
		String segments[] = expr.split(":");
		int i = 0;
		for (int length = segments.length - 1; i < segments.length; length--)
		{
			result = findComponent(base, segments[i], length == 0);
			if (i == 0 && result == null && segments[i].equals(base.getId()))
				result = base;
			if (result == null && length > 0)
				throw new IllegalArgumentException(segments[i]);
			base = result;
			i++;
		}

		return result;
	}

	private UIComponent findComponent(UIComponent base, String id, boolean checkId)
	{
		UIComponent result;
label0:
		{
			result = null;
			Iterator i = base.getFacetsAndChildren();
			UIComponent kid;
label1:
			do
			{
				do
				{
					if (!i.hasNext())
						break;
					kid = (UIComponent)i.next();
					if (kid instanceof NamingContainer)
						continue label1;
					if (checkId && id.equals(kid.getId()))
					{
						result = kid;
						break;
					}
					result = findComponent(kid, id, checkId);
				} while (result == null);
				break label0;
			} while (!id.equals(kid.getId()));
			result = kid;
		}
		return result;
	}

	public boolean invokeOnComponent(FacesContext context, String clientId, ContextCallback callback)
		throws FacesException
	{
		return super.invokeOnComponent(context, clientId, callback);
	}

	public Map getFacets()
	{
		if (facets == null)
			facets = new FacetsMap();
		return facets;
	}

	public int getFacetCount()
	{
		if (facets != null)
			return facets.size();
		else
			return 0;
	}

	public UIComponent getFacet(String name)
	{
		if (facets != null)
			return (UIComponent)facets.get(name);
		else
			return null;
	}

	public Iterator getFacetsAndChildren()
	{
		Iterator result = null;
		int childCount = getChildCount();
		int facetCount = getFacetCount();
		if (0 == childCount && 0 == facetCount)
			result = EMPTY_ITERATOR;
		else
		if (0 == childCount)
		{
			Collection unmodifiable = Collections.unmodifiableCollection(getFacets().values());
			result = unmodifiable.iterator();
		} else
		if (0 == facetCount)
		{
			List unmodifiable = Collections.unmodifiableList(getChildren());
			result = unmodifiable.iterator();
		} else
		{
			result = new FacetsAndChildrenIterator(this);
		}
		return result;
	}

	public void broadcast(FacesEvent event)
		throws AbortProcessingException
	{
		if (event == null)
			throw new NullPointerException();
		if (listeners == null)
			return;
		Iterator iter = listeners.iterator();
		do
		{
			if (!iter.hasNext())
				break;
			FacesListener listener = (FacesListener)iter.next();
			if (event.isAppropriateListener(listener))
				event.processListener(listener);
		} while (true);
	}

	public void decode(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		String rendererType = getRendererType();
		if (rendererType != null)
			getRenderer(context).decode(context, this);
	}

	public void encodeBegin(FacesContext context)
		throws IOException
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		String rendererType = getRendererType();
		if (rendererType != null)
			getRenderer(context).encodeBegin(context, this);
	}

	public void encodeChildren(FacesContext context)
		throws IOException
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		String rendererType = getRendererType();
		if (rendererType != null)
			getRenderer(context).encodeChildren(context, this);
	}

	public void encodeEnd(FacesContext context)
		throws IOException
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		String rendererType = getRendererType();
		if (rendererType != null)
			getRenderer(context).encodeEnd(context, this);
	}

	protected void addFacesListener(FacesListener listener)
	{
		if (listener == null)
			throw new NullPointerException();
		if (listeners == null)
			listeners = new ArrayList();
		listeners.add(listener);
	}

	protected FacesListener[] getFacesListeners(Class clazz)
	{
		if (clazz == null)
			throw new NullPointerException();
		if (!javax/faces/event/FacesListener.isAssignableFrom(clazz))
			throw new IllegalArgumentException();
		if (listeners == null)
			return (FacesListener[])(FacesListener[])Array.newInstance(clazz, 0);
		List results = new ArrayList();
		Iterator items = listeners.iterator();
		do
		{
			if (!items.hasNext())
				break;
			FacesListener item = (FacesListener)items.next();
			if (clazz.isAssignableFrom(item.getClass()))
				results.add(item);
		} while (true);
		return (FacesListener[])(FacesListener[])results.toArray((Object[])(Object[])Array.newInstance(clazz, results.size()));
	}

	protected void removeFacesListener(FacesListener listener)
	{
		if (listener == null)
			throw new NullPointerException();
		if (listeners == null)
		{
			return;
		} else
		{
			listeners.remove(listener);
			return;
		}
	}

	public void queueEvent(FacesEvent event)
	{
		if (event == null)
			throw new NullPointerException();
		UIComponent parent = getParent();
		if (parent == null)
		{
			throw new IllegalStateException();
		} else
		{
			parent.queueEvent(event);
			return;
		}
	}

	public void processDecodes(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		UIComponent kid;
		for (Iterator kids = getFacetsAndChildren(); kids.hasNext(); kid.processDecodes(context))
			kid = (UIComponent)kids.next();

		try
		{
			decode(context);
		}
		catch (RuntimeException e)
		{
			context.renderResponse();
			throw e;
		}
	}

	public void processValidators(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		UIComponent kid;
		for (Iterator kids = getFacetsAndChildren(); kids.hasNext(); kid.processValidators(context))
			kid = (UIComponent)kids.next();

	}

	public void processUpdates(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (!isRendered())
			return;
		UIComponent kid;
		for (Iterator kids = getFacetsAndChildren(); kids.hasNext(); kid.processUpdates(context))
			kid = (UIComponent)kids.next();

	}

	public Object processSaveState(FacesContext context)
	{
		if (context == null)
			throw new NullPointerException();
		if (isTransient())
			return null;
		Object stateStruct[] = new Object[2];
		Object childState[] = EMPTY_ARRAY;
		stateStruct[0] = saveState(context);
		int count = getChildCount() + getFacetCount();
		if (count > 0)
		{
			List stateList = new ArrayList(count);
			if (getChildCount() > 0)
			{
				Iterator kids = getChildren().iterator();
				do
				{
					if (!kids.hasNext())
						break;
					UIComponent kid = (UIComponent)kids.next();
					if (!kid.isTransient())
						stateList.add(kid.processSaveState(context));
				} while (true);
			}
			if (getFacetCount() > 0)
			{
				Iterator myFacets = getFacets().entrySet().iterator();
				UIComponent facet = null;
				Object facetState = null;
				Object facetSaveState[] = null;
				java.util.Map.Entry entry = null;
				do
				{
					if (!myFacets.hasNext())
						break;
					entry = (java.util.Map.Entry)myFacets.next();
					facet = (UIComponent)entry.getValue();
					if (!facet.isTransient())
					{
						facetState = facet.processSaveState(context);
						facetSaveState = new Object[2];
						facetSaveState[0] = entry.getKey();
						facetSaveState[1] = facetState;
						stateList.add(((Object) (facetSaveState)));
					}
				} while (true);
			}
			childState = stateList.toArray();
		}
		stateStruct[1] = ((Object) (childState));
		return ((Object) (stateStruct));
	}

	public void processRestoreState(FacesContext context, Object state)
	{
		if (context == null)
			throw new NullPointerException();
		Object stateStruct[] = (Object[])(Object[])state;
		Object childState[] = (Object[])(Object[])stateStruct[1];
		restoreState(context, stateStruct[0]);
		int i = 0;
		if (getChildCount() > 0)
		{
			Iterator kids = getChildren().iterator();
			do
			{
				if (!kids.hasNext())
					break;
				UIComponent kid = (UIComponent)kids.next();
				if (!kid.isTransient())
				{
					Object currentState = childState[i++];
					if (currentState != null)
						kid.processRestoreState(context, currentState);
				}
			} while (true);
		}
		if (getFacetCount() > 0)
		{
			int facetsSize = getFacets().size();
			int j = 0;
			Object facetSaveState[] = null;
			String facetName = null;
			UIComponent facet = null;
			Object facetState = null;
			for (; j < facetsSize; j++)
				if (null != (facetSaveState = (Object[])(Object[])childState[i++]))
				{
					facetName = (String)facetSaveState[0];
					facetState = facetSaveState[1];
					facet = (UIComponent)getFacets().get(facetName);
					facet.processRestoreState(context, facetState);
				}

		}
	}

	protected FacesContext getFacesContext()
	{
		return FacesContext.getCurrentInstance();
	}

	protected Renderer getRenderer(FacesContext context)
	{
		String rendererType = getRendererType();
		Renderer result = null;
		if (rendererType != null)
		{
			result = context.getRenderKit().getRenderer(getFamily(), rendererType);
			if (null == result && log.isLoggable(Level.FINE))
				log.fine((new StringBuilder()).append("Can't get Renderer for type ").append(rendererType).toString());
		} else
		if (log.isLoggable(Level.FINE))
		{
			String id = getId();
			id = null == id ? getClass().getName() : id;
			log.fine((new StringBuilder()).append("No renderer-type for component ").append(id).toString());
		}
		return result;
	}

	public Object saveState(FacesContext context)
	{
		if (values == null)
			values = new Object[8];
		if (attributes != null)
		{
			Map backing = attributes.getBackingAttributes();
			if (backing != null && !backing.isEmpty())
				values[0] = backing;
		}
		values[1] = saveBindingsState(context);
		values[2] = clientId;
		values[3] = id;
		values[4] = rendered ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[5] = renderedSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[6] = rendererType;
		values[7] = saveAttachedState(context, listeners);
		if (!$assertionsDisabled && transientFlag)
			throw new AssertionError();
		else
			return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state)
	{
		values = (Object[])(Object[])state;
		if (values[0] != null)
			attributes = new AttributesMap((Map)values[0]);
		bindings = restoreBindingsState(context, values[1]);
		clientId = (String)values[2];
		id = (String)values[3];
		rendered = ((Boolean)values[4]).booleanValue();
		renderedSet = ((Boolean)values[5]).booleanValue();
		rendererType = (String)values[6];
		List restoredListeners = null;
		if (null != (restoredListeners = (List)restoreAttachedState(context, values[7])))
			if (null != listeners)
				listeners.addAll(restoredListeners);
			else
				listeners = restoredListeners;
	}

	public boolean isTransient()
	{
		return transientFlag;
	}

	public void setTransient(boolean transientFlag)
	{
		this.transientFlag = transientFlag;
	}

	public static Object saveAttachedState(FacesContext context, Object attachedObject)
	{
		if (null == context)
			throw new NullPointerException();
		if (null == attachedObject)
			return null;
		Object result = null;
		List attachedList = null;
		List resultList = null;
		Iterator listIter = null;
		if (attachedObject instanceof List)
		{
			attachedList = (List)attachedObject;
			resultList = new ArrayList(attachedList.size());
			listIter = attachedList.iterator();
			Object cur = null;
			do
			{
				if (!listIter.hasNext())
					break;
				if (null != (cur = listIter.next()))
					resultList.add(new StateHolderSaver(context, cur));
			} while (true);
			result = resultList;
		} else
		{
			result = new StateHolderSaver(context, attachedObject);
		}
		return result;
	}

	public static Object restoreAttachedState(FacesContext context, Object stateObj)
		throws IllegalStateException
	{
		if (null == context)
			throw new NullPointerException();
		if (null == stateObj)
			return null;
		Object result;
		if (stateObj instanceof List)
		{
			List stateList = (List)stateObj;
			List retList = new ArrayList(stateList.size());
			for (Iterator i$ = stateList.iterator(); i$.hasNext();)
			{
				Object item = i$.next();
				try
				{
					retList.add(((StateHolderSaver)item).restore(context));
				}
				catch (ClassCastException cce)
				{
					throw new IllegalStateException("Unknown object type");
				}
			}

			result = retList;
		} else
		if (stateObj instanceof StateHolderSaver)
		{
			StateHolderSaver saver = (StateHolderSaver)stateObj;
			result = saver.restore(context);
		} else
		{
			throw new IllegalStateException("Unknown object type");
		}
		return result;
	}

	private Map restoreBindingsState(FacesContext context, Object state)
	{
		if (state == null)
			return null;
		Object values[] = (Object[])(Object[])state;
		String names[] = (String[])(String[])values[0];
		Object states[] = (Object[])(Object[])values[1];
		Map bindings = new HashMap(names.length);
		for (int i = 0; i < names.length; i++)
			bindings.put(names[i], restoreAttachedState(context, states[i]));

		return bindings;
	}

	private Object saveBindingsState(FacesContext context)
	{
		if (bindings == null)
			return null;
		Object values[] = new Object[2];
		values[0] = ((Object) (bindings.keySet().toArray(new String[bindings.size()])));
		Object bindingValues[] = bindings.values().toArray();
		for (int i = 0; i < bindingValues.length; i++)
			bindingValues[i] = saveAttachedState(context, bindingValues[i]);

		values[1] = ((Object) (bindingValues));
		return ((Object) (values));
	}





}
