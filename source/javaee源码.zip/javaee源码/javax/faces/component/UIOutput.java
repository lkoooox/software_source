// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UIOutput.java

package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

// Referenced classes of package javax.faces.component:
//			UIComponentBase, ValueHolder

public class UIOutput extends UIComponentBase
	implements ValueHolder
{

	public static final String COMPONENT_TYPE = "javax.faces.Output";
	public static final String COMPONENT_FAMILY = "javax.faces.Output";
	private Converter converter;
	private Object value;
	private Object values[];

	public UIOutput()
	{
		converter = null;
		value = null;
		setRendererType("javax.faces.Text");
	}

	public String getFamily()
	{
		return "javax.faces.Output";
	}

	public Converter getConverter()
	{
		ValueExpression ve;
		if (converter != null)
			return converter;
		ve = getValueExpression("converter");
		if (ve == null)
			break MISSING_BLOCK_LABEL_48;
		return (Converter)ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setConverter(Converter converter)
	{
		this.converter = converter;
	}

	public Object getLocalValue()
	{
		return value;
	}

	public Object getValue()
	{
		ValueExpression ve;
		if (value != null)
			return value;
		ve = getValueExpression("value");
		if (ve == null)
			break MISSING_BLOCK_LABEL_45;
		return ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setValue(Object value)
	{
		this.value = value;
	}

	public Object saveState(FacesContext context)
	{
		if (values == null)
			values = new Object[3];
		values[0] = super.saveState(context);
		values[1] = saveAttachedState(context, converter);
		values[2] = value;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state)
	{
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		converter = (Converter)restoreAttachedState(context, values[1]);
		value = values[2];
	}
}
