// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   StateHolderSaver.java

package javax.faces.component;

import java.io.Serializable;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.component:
//			StateHolder

class StateHolderSaver
	implements Serializable
{

	private static final long serialVersionUID = 0x59cab33d939ccd4dL;
	private String className;
	private Object savedState;

	public StateHolderSaver(FacesContext context, Object toSave)
	{
		className = null;
		savedState = null;
		className = toSave.getClass().getName();
		if (toSave instanceof StateHolder)
		{
			if (!((StateHolder)toSave).isTransient())
				savedState = ((StateHolder)toSave).saveState(context);
			else
				className = null;
		} else
		if (toSave instanceof Serializable)
		{
			savedState = toSave;
			className = null;
		}
	}

	public Object restore(FacesContext context)
		throws IllegalStateException
	{
		Object result = null;
		Class toRestoreClass = null;
		if (null == className && null != savedState)
			return savedState;
		if (className == null)
			return null;
		try
		{
			toRestoreClass = loadClass(className, this);
		}
		catch (ClassNotFoundException e)
		{
			throw new IllegalStateException(e.getMessage());
		}
		if (null != toRestoreClass)
			try
			{
				result = toRestoreClass.newInstance();
			}
			catch (InstantiationException e)
			{
				throw new IllegalStateException(e.getMessage());
			}
			catch (IllegalAccessException a)
			{
				throw new IllegalStateException(a.getMessage());
			}
		if (null != result && null != savedState && (result instanceof StateHolder))
			((StateHolder)result).restoreState(context, savedState);
		return result;
	}

	private static Class loadClass(String name, Object fallbackClass)
		throws ClassNotFoundException
	{
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		if (loader == null)
			loader = fallbackClass.getClass().getClassLoader();
		return Class.forName(name, false, loader);
	}
}
