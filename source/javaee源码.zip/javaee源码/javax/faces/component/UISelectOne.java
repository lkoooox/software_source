// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UISelectOne.java

package javax.faces.component;

import java.util.Iterator;
import java.util.NoSuchElementException;
import javax.el.ExpressionFactory;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;

// Referenced classes of package javax.faces.component:
//			UIInput, MessageFactory, SelectItemsIterator

public class UISelectOne extends UIInput
{
	static class ArrayIterator
		implements Iterator
	{

		private Object items[];
		private int index;

		public boolean hasNext()
		{
			return index < items.length;
		}

		public Object next()
		{
			return items[index++];
			IndexOutOfBoundsException e;
			e;
			throw new NoSuchElementException();
		}

		public void remove()
		{
			throw new UnsupportedOperationException();
		}

		public ArrayIterator(Object items[])
		{
			index = 0;
			this.items = items;
		}
	}


	public static final String COMPONENT_TYPE = "javax.faces.SelectOne";
	public static final String COMPONENT_FAMILY = "javax.faces.SelectOne";
	public static final String INVALID_MESSAGE_ID = "javax.faces.component.UISelectOne.INVALID";

	public UISelectOne()
	{
		setRendererType("javax.faces.Menu");
	}

	public String getFamily()
	{
		return "javax.faces.SelectOne";
	}

	protected void validateValue(FacesContext context, Object value)
	{
		super.validateValue(context, value);
		if (!isValid() || value == null)
			return;
		boolean found = matchValue(value, new SelectItemsIterator(this));
		if (!found)
		{
			FacesMessage message = MessageFactory.getMessage(context, "javax.faces.component.UISelectOne.INVALID", new Object[] {
				MessageFactory.getLabel(context, this)
			});
			message.setSeverity(FacesMessage.SEVERITY_ERROR);
			context.addMessage(getClientId(context), message);
			setValid(false);
		}
	}

	private boolean matchValue(Object value, Iterator items)
	{
		while (items.hasNext()) 
		{
			SelectItem item = (SelectItem)items.next();
			if (item instanceof SelectItemGroup)
			{
				SelectItem subitems[] = ((SelectItemGroup)item).getSelectItems();
				if (subitems != null && subitems.length > 0 && matchValue(value, ((Iterator) (new ArrayIterator(subitems)))))
					return true;
			} else
			{
				Class type = value.getClass();
				Object newValue = getFacesContext().getApplication().getExpressionFactory().coerceToType(item.getValue(), type);
				if (value.equals(newValue))
					return true;
			}
		}
		return false;
	}
}
