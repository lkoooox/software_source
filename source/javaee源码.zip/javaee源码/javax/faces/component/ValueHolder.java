// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ValueHolder.java

package javax.faces.component;

import javax.faces.convert.Converter;

public interface ValueHolder
{

	public abstract Object getLocalValue();

	public abstract Object getValue();

	public abstract void setValue(Object obj);

	public abstract Converter getConverter();

	public abstract void setConverter(Converter converter);
}
