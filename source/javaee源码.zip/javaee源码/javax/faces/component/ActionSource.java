// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ActionSource.java

package javax.faces.component;

import javax.faces.el.MethodBinding;
import javax.faces.event.ActionListener;

public interface ActionSource
{

	/**
	 * @deprecated Method getAction is deprecated
	 */

	public abstract MethodBinding getAction();

	/**
	 * @deprecated Method setAction is deprecated
	 */

	public abstract void setAction(MethodBinding methodbinding);

	/**
	 * @deprecated Method getActionListener is deprecated
	 */

	public abstract MethodBinding getActionListener();

	/**
	 * @deprecated Method setActionListener is deprecated
	 */

	public abstract void setActionListener(MethodBinding methodbinding);

	public abstract boolean isImmediate();

	public abstract void setImmediate(boolean flag);

	public abstract void addActionListener(ActionListener actionlistener);

	public abstract ActionListener[] getActionListeners();

	public abstract void removeActionListener(ActionListener actionlistener);
}
