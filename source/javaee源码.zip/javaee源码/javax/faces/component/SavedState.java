// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UIData.java

package javax.faces.component;

import java.io.Serializable;

class SavedState
	implements Serializable
{

	private Object submittedValue;
	private static final long serialVersionUID = 0x2886d251d70b9559L;
	private boolean valid;
	private Object value;
	private boolean localValueSet;

	SavedState()
	{
		valid = true;
	}

	Object getSubmittedValue()
	{
		return submittedValue;
	}

	void setSubmittedValue(Object submittedValue)
	{
		this.submittedValue = submittedValue;
	}

	boolean isValid()
	{
		return valid;
	}

	void setValid(boolean valid)
	{
		this.valid = valid;
	}

	Object getValue()
	{
		return value;
	}

	public void setValue(Object value)
	{
		this.value = value;
	}

	boolean isLocalValueSet()
	{
		return localValueSet;
	}

	public void setLocalValueSet(boolean localValueSet)
	{
		this.localValueSet = localValueSet;
	}

	public String toString()
	{
		return (new StringBuilder()).append("submittedValue: ").append(submittedValue).append(" value: ").append(value).append(" localValueSet: ").append(localValueSet).toString();
	}
}
