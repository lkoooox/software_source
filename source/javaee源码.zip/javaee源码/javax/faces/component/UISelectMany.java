// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UISelectMany.java

package javax.faces.component;

import java.lang.reflect.Array;
import java.util.*;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;

// Referenced classes of package javax.faces.component:
//			UIInput, MessageFactory, SelectItemsIterator

public class UISelectMany extends UIInput
{
	static class ArrayIterator
		implements Iterator
	{

		private Object items[];
		private int index;

		public boolean hasNext()
		{
			return index < items.length;
		}

		public Object next()
		{
			return items[index++];
			IndexOutOfBoundsException e;
			e;
			throw new NoSuchElementException();
		}

		public void remove()
		{
			throw new UnsupportedOperationException();
		}

		public ArrayIterator(Object items[])
		{
			index = 0;
			this.items = items;
		}
	}


	public static final String COMPONENT_TYPE = "javax.faces.SelectMany";
	public static final String COMPONENT_FAMILY = "javax.faces.SelectMany";
	public static final String INVALID_MESSAGE_ID = "javax.faces.component.UISelectMany.INVALID";

	public UISelectMany()
	{
		setRendererType("javax.faces.Listbox");
	}

	public String getFamily()
	{
		return "javax.faces.SelectMany";
	}

	public Object[] getSelectedValues()
	{
		return (Object[])(Object[])getValue();
	}

	public void setSelectedValues(Object selectedValues[])
	{
		setValue(((Object) (selectedValues)));
	}

	/**
	 * @deprecated Method getValueBinding is deprecated
	 */

	public ValueBinding getValueBinding(String name)
	{
		if ("selectedValues".equals(name))
			return super.getValueBinding("value");
		else
			return super.getValueBinding(name);
	}

	/**
	 * @deprecated Method setValueBinding is deprecated
	 */

	public void setValueBinding(String name, ValueBinding binding)
	{
		if ("selectedValues".equals(name))
			super.setValueBinding("value", binding);
		else
			super.setValueBinding(name, binding);
	}

	public ValueExpression getValueExpression(String name)
	{
		if ("selectedValues".equals(name))
			return super.getValueExpression("value");
		else
			return super.getValueExpression(name);
	}

	public void setValueExpression(String name, ValueExpression binding)
	{
		if ("selectedValues".equals(name))
			super.setValueExpression("value", binding);
		else
			super.setValueExpression(name, binding);
	}

	protected boolean compareValues(Object previous, Object value)
	{
		if (previous == null && value != null)
			return true;
		if (previous != null && value == null)
			return true;
		if (previous == null && value == null)
			return false;
		boolean valueChanged = false;
		Object oldarray[] = null;
		Object newarray[] = null;
		if (!(previous instanceof Object[]))
			previous = ((Object) (toObjectArray(previous)));
		if (!(value instanceof Object[]))
			value = ((Object) (toObjectArray(value)));
		if (!(previous instanceof Object[]) || !(value instanceof Object[]))
			return false;
		oldarray = (Object[])(Object[])previous;
		newarray = (Object[])(Object[])value;
		if (oldarray.length != newarray.length)
			return true;
		int count1 = 0;
		int count2 = 0;
		int i = 0;
		do
		{
			if (i >= oldarray.length)
				break;
			count1 = countElementOccurrence(oldarray[i], oldarray);
			count2 = countElementOccurrence(oldarray[i], newarray);
			if (count1 != count2)
			{
				valueChanged = true;
				break;
			}
			i++;
		} while (true);
		return valueChanged;
	}

	private int countElementOccurrence(Object element, Object array[])
	{
		int count = 0;
		for (int i = 0; i < array.length; i++)
		{
			Object arrayElement = array[i];
			if (arrayElement != null && element != null && arrayElement.equals(element))
				count++;
		}

		return count;
	}

	private Object[] toObjectArray(Object primitiveArray)
	{
		if (primitiveArray == null)
			throw new NullPointerException();
		if (primitiveArray instanceof Object[])
			return (Object[])(Object[])primitiveArray;
		if (primitiveArray instanceof List)
			return ((List)primitiveArray).toArray();
		Class clazz = primitiveArray.getClass();
		if (!clazz.isArray())
			return null;
		int length = Array.getLength(primitiveArray);
		Object array[] = new Object[length];
		for (int i = 0; i < length; i++)
			array[i] = Array.get(primitiveArray, i);

		return array;
	}

	protected void validateValue(FacesContext context, Object value)
	{
		super.validateValue(context, value);
		if (!isValid() || value == null)
			return;
		boolean isList = value instanceof List;
		int length = isList ? ((List)value).size() : Array.getLength(value);
		boolean found = true;
		int i = 0;
		do
		{
			if (i >= length)
				break;
			Iterator items = new SelectItemsIterator(this);
			Object indexValue = isList ? ((List)value).get(i) : Array.get(value, i);
			found = matchValue(indexValue, items);
			if (!found)
				break;
			i++;
		} while (true);
		if (!found)
		{
			FacesMessage message = MessageFactory.getMessage(context, "javax.faces.component.UISelectMany.INVALID", new Object[] {
				MessageFactory.getLabel(context, this)
			});
			message.setSeverity(FacesMessage.SEVERITY_ERROR);
			context.addMessage(getClientId(context), message);
			setValid(false);
		}
	}

	private boolean matchValue(Object value, Iterator items)
	{
		while (items.hasNext()) 
		{
			SelectItem item = (SelectItem)items.next();
			if (item instanceof SelectItemGroup)
			{
				SelectItem subitems[] = ((SelectItemGroup)item).getSelectItems();
				if (subitems != null && subitems.length > 0 && matchValue(value, ((Iterator) (new ArrayIterator(subitems)))))
					return true;
			} else
			{
				Class type = value.getClass();
				Object newValue = getFacesContext().getApplication().getExpressionFactory().coerceToType(item.getValue(), type);
				if (value.equals(newValue))
					return true;
			}
		}
		return false;
	}
}
