// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UIGraphic.java

package javax.faces.component;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

// Referenced classes of package javax.faces.component:
//			UIComponentBase

public class UIGraphic extends UIComponentBase
{

	public static final String COMPONENT_TYPE = "javax.faces.Graphic";
	public static final String COMPONENT_FAMILY = "javax.faces.Graphic";
	private Object value;
	private Object values[];

	public UIGraphic()
	{
		value = null;
		setRendererType("javax.faces.Image");
	}

	public String getFamily()
	{
		return "javax.faces.Graphic";
	}

	public String getUrl()
	{
		return (String)getValue();
	}

	public void setUrl(String url)
	{
		setValue(url);
	}

	public Object getValue()
	{
		ValueExpression ve;
		if (value != null)
			return value;
		ve = getValueExpression("value");
		if (ve == null)
			break MISSING_BLOCK_LABEL_45;
		return ve.getValue(getFacesContext().getELContext());
		ELException e;
		e;
		throw new FacesException(e);
		return null;
	}

	public void setValue(Object value)
	{
		this.value = value;
	}

	/**
	 * @deprecated Method getValueBinding is deprecated
	 */

	public ValueBinding getValueBinding(String name)
	{
		if ("url".equals(name))
			return super.getValueBinding("value");
		else
			return super.getValueBinding(name);
	}

	/**
	 * @deprecated Method setValueBinding is deprecated
	 */

	public void setValueBinding(String name, ValueBinding binding)
	{
		if ("url".equals(name))
			super.setValueBinding("value", binding);
		else
			super.setValueBinding(name, binding);
	}

	public ValueExpression getValueExpression(String name)
	{
		if ("url".equals(name))
			return super.getValueExpression("value");
		else
			return super.getValueExpression(name);
	}

	public void setValueExpression(String name, ValueExpression binding)
	{
		if ("url".equals(name))
			super.setValueExpression("value", binding);
		else
			super.setValueExpression(name, binding);
	}

	public Object saveState(FacesContext context)
	{
		if (values == null)
			values = new Object[2];
		values[0] = super.saveState(context);
		values[1] = value;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state)
	{
		values = (Object[])(Object[])state;
		super.restoreState(context, values[0]);
		value = values[1];
	}
}
