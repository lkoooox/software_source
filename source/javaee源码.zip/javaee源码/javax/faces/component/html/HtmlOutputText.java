// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HtmlOutputText.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;

public class HtmlOutputText extends UIOutput
{

	public static final String COMPONENT_TYPE = "javax.faces.HtmlOutputText";
	private String dir;
	private boolean escape;
	private boolean escape_set;
	private String lang;
	private String style;
	private String styleClass;
	private String title;
	private Object _values[];

	public HtmlOutputText()
	{
		escape = true;
		escape_set = false;
		setRendererType("javax.faces.Text");
	}

	public String getDir()
	{
		if (null != dir)
			return dir;
		ValueExpression _ve = getValueExpression("dir");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setDir(String dir)
	{
		this.dir = dir;
	}

	public boolean isEscape()
	{
		if (escape_set)
			return escape;
		ValueExpression _ve = getValueExpression("escape");
		if (_ve != null)
		{
			Object _result = _ve.getValue(getFacesContext().getELContext());
			if (_result == null)
				return false;
			else
				return ((Boolean)_result).booleanValue();
		} else
		{
			return escape;
		}
	}

	public void setEscape(boolean escape)
	{
		this.escape = escape;
		escape_set = true;
	}

	public String getLang()
	{
		if (null != lang)
			return lang;
		ValueExpression _ve = getValueExpression("lang");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getStyle()
	{
		if (null != style)
			return style;
		ValueExpression _ve = getValueExpression("style");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyle(String style)
	{
		this.style = style;
	}

	public String getStyleClass()
	{
		if (null != styleClass)
			return styleClass;
		ValueExpression _ve = getValueExpression("styleClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyleClass(String styleClass)
	{
		this.styleClass = styleClass;
	}

	public String getTitle()
	{
		if (null != title)
			return title;
		ValueExpression _ve = getValueExpression("title");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public Object saveState(FacesContext _context)
	{
		if (_values == null)
			_values = new Object[8];
		_values[0] = super.saveState(_context);
		_values[1] = dir;
		_values[2] = escape ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[3] = escape_set ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[4] = lang;
		_values[5] = style;
		_values[6] = styleClass;
		_values[7] = title;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state)
	{
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		dir = (String)_values[1];
		escape = ((Boolean)_values[2]).booleanValue();
		escape_set = ((Boolean)_values[3]).booleanValue();
		lang = (String)_values[4];
		style = (String)_values[5];
		styleClass = (String)_values[6];
		title = (String)_values[7];
	}
}
