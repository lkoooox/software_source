// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HtmlDataTable.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIData;
import javax.faces.context.FacesContext;

public class HtmlDataTable extends UIData
{

	public static final String COMPONENT_TYPE = "javax.faces.HtmlDataTable";
	private String bgcolor;
	private int border;
	private boolean border_set;
	private String captionClass;
	private String captionStyle;
	private String cellpadding;
	private String cellspacing;
	private String columnClasses;
	private String dir;
	private String footerClass;
	private String frame;
	private String headerClass;
	private String lang;
	private String onclick;
	private String ondblclick;
	private String onkeydown;
	private String onkeypress;
	private String onkeyup;
	private String onmousedown;
	private String onmousemove;
	private String onmouseout;
	private String onmouseover;
	private String onmouseup;
	private String rowClasses;
	private String rules;
	private String style;
	private String styleClass;
	private String summary;
	private String title;
	private String width;
	private Object _values[];

	public HtmlDataTable()
	{
		border = 0x80000000;
		border_set = false;
		setRendererType("javax.faces.Table");
	}

	public String getBgcolor()
	{
		if (null != bgcolor)
			return bgcolor;
		ValueExpression _ve = getValueExpression("bgcolor");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setBgcolor(String bgcolor)
	{
		this.bgcolor = bgcolor;
	}

	public int getBorder()
	{
		if (border_set)
			return border;
		ValueExpression _ve = getValueExpression("border");
		if (_ve != null)
		{
			Object _result = _ve.getValue(getFacesContext().getELContext());
			if (_result == null)
				return 0x80000000;
			else
				return ((Integer)_result).intValue();
		} else
		{
			return border;
		}
	}

	public void setBorder(int border)
	{
		this.border = border;
		border_set = true;
	}

	public String getCaptionClass()
	{
		if (null != captionClass)
			return captionClass;
		ValueExpression _ve = getValueExpression("captionClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setCaptionClass(String captionClass)
	{
		this.captionClass = captionClass;
	}

	public String getCaptionStyle()
	{
		if (null != captionStyle)
			return captionStyle;
		ValueExpression _ve = getValueExpression("captionStyle");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setCaptionStyle(String captionStyle)
	{
		this.captionStyle = captionStyle;
	}

	public String getCellpadding()
	{
		if (null != cellpadding)
			return cellpadding;
		ValueExpression _ve = getValueExpression("cellpadding");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setCellpadding(String cellpadding)
	{
		this.cellpadding = cellpadding;
	}

	public String getCellspacing()
	{
		if (null != cellspacing)
			return cellspacing;
		ValueExpression _ve = getValueExpression("cellspacing");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setCellspacing(String cellspacing)
	{
		this.cellspacing = cellspacing;
	}

	public String getColumnClasses()
	{
		if (null != columnClasses)
			return columnClasses;
		ValueExpression _ve = getValueExpression("columnClasses");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setColumnClasses(String columnClasses)
	{
		this.columnClasses = columnClasses;
	}

	public String getDir()
	{
		if (null != dir)
			return dir;
		ValueExpression _ve = getValueExpression("dir");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setDir(String dir)
	{
		this.dir = dir;
	}

	public String getFooterClass()
	{
		if (null != footerClass)
			return footerClass;
		ValueExpression _ve = getValueExpression("footerClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setFooterClass(String footerClass)
	{
		this.footerClass = footerClass;
	}

	public String getFrame()
	{
		if (null != frame)
			return frame;
		ValueExpression _ve = getValueExpression("frame");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setFrame(String frame)
	{
		this.frame = frame;
	}

	public String getHeaderClass()
	{
		if (null != headerClass)
			return headerClass;
		ValueExpression _ve = getValueExpression("headerClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setHeaderClass(String headerClass)
	{
		this.headerClass = headerClass;
	}

	public String getLang()
	{
		if (null != lang)
			return lang;
		ValueExpression _ve = getValueExpression("lang");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getOnclick()
	{
		if (null != onclick)
			return onclick;
		ValueExpression _ve = getValueExpression("onclick");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnclick(String onclick)
	{
		this.onclick = onclick;
	}

	public String getOndblclick()
	{
		if (null != ondblclick)
			return ondblclick;
		ValueExpression _ve = getValueExpression("ondblclick");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOndblclick(String ondblclick)
	{
		this.ondblclick = ondblclick;
	}

	public String getOnkeydown()
	{
		if (null != onkeydown)
			return onkeydown;
		ValueExpression _ve = getValueExpression("onkeydown");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeydown(String onkeydown)
	{
		this.onkeydown = onkeydown;
	}

	public String getOnkeypress()
	{
		if (null != onkeypress)
			return onkeypress;
		ValueExpression _ve = getValueExpression("onkeypress");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeypress(String onkeypress)
	{
		this.onkeypress = onkeypress;
	}

	public String getOnkeyup()
	{
		if (null != onkeyup)
			return onkeyup;
		ValueExpression _ve = getValueExpression("onkeyup");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeyup(String onkeyup)
	{
		this.onkeyup = onkeyup;
	}

	public String getOnmousedown()
	{
		if (null != onmousedown)
			return onmousedown;
		ValueExpression _ve = getValueExpression("onmousedown");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmousedown(String onmousedown)
	{
		this.onmousedown = onmousedown;
	}

	public String getOnmousemove()
	{
		if (null != onmousemove)
			return onmousemove;
		ValueExpression _ve = getValueExpression("onmousemove");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmousemove(String onmousemove)
	{
		this.onmousemove = onmousemove;
	}

	public String getOnmouseout()
	{
		if (null != onmouseout)
			return onmouseout;
		ValueExpression _ve = getValueExpression("onmouseout");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseout(String onmouseout)
	{
		this.onmouseout = onmouseout;
	}

	public String getOnmouseover()
	{
		if (null != onmouseover)
			return onmouseover;
		ValueExpression _ve = getValueExpression("onmouseover");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseover(String onmouseover)
	{
		this.onmouseover = onmouseover;
	}

	public String getOnmouseup()
	{
		if (null != onmouseup)
			return onmouseup;
		ValueExpression _ve = getValueExpression("onmouseup");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseup(String onmouseup)
	{
		this.onmouseup = onmouseup;
	}

	public String getRowClasses()
	{
		if (null != rowClasses)
			return rowClasses;
		ValueExpression _ve = getValueExpression("rowClasses");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setRowClasses(String rowClasses)
	{
		this.rowClasses = rowClasses;
	}

	public String getRules()
	{
		if (null != rules)
			return rules;
		ValueExpression _ve = getValueExpression("rules");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setRules(String rules)
	{
		this.rules = rules;
	}

	public String getStyle()
	{
		if (null != style)
			return style;
		ValueExpression _ve = getValueExpression("style");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyle(String style)
	{
		this.style = style;
	}

	public String getStyleClass()
	{
		if (null != styleClass)
			return styleClass;
		ValueExpression _ve = getValueExpression("styleClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyleClass(String styleClass)
	{
		this.styleClass = styleClass;
	}

	public String getSummary()
	{
		if (null != summary)
			return summary;
		ValueExpression _ve = getValueExpression("summary");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setSummary(String summary)
	{
		this.summary = summary;
	}

	public String getTitle()
	{
		if (null != title)
			return title;
		ValueExpression _ve = getValueExpression("title");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getWidth()
	{
		if (null != width)
			return width;
		ValueExpression _ve = getValueExpression("width");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setWidth(String width)
	{
		this.width = width;
	}

	public Object saveState(FacesContext _context)
	{
		if (_values == null)
			_values = new Object[31];
		_values[0] = super.saveState(_context);
		_values[1] = bgcolor;
		_values[2] = new Integer(border);
		_values[3] = border_set ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[4] = captionClass;
		_values[5] = captionStyle;
		_values[6] = cellpadding;
		_values[7] = cellspacing;
		_values[8] = columnClasses;
		_values[9] = dir;
		_values[10] = footerClass;
		_values[11] = frame;
		_values[12] = headerClass;
		_values[13] = lang;
		_values[14] = onclick;
		_values[15] = ondblclick;
		_values[16] = onkeydown;
		_values[17] = onkeypress;
		_values[18] = onkeyup;
		_values[19] = onmousedown;
		_values[20] = onmousemove;
		_values[21] = onmouseout;
		_values[22] = onmouseover;
		_values[23] = onmouseup;
		_values[24] = rowClasses;
		_values[25] = rules;
		_values[26] = style;
		_values[27] = styleClass;
		_values[28] = summary;
		_values[29] = title;
		_values[30] = width;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state)
	{
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		bgcolor = (String)_values[1];
		border = ((Integer)_values[2]).intValue();
		border_set = ((Boolean)_values[3]).booleanValue();
		captionClass = (String)_values[4];
		captionStyle = (String)_values[5];
		cellpadding = (String)_values[6];
		cellspacing = (String)_values[7];
		columnClasses = (String)_values[8];
		dir = (String)_values[9];
		footerClass = (String)_values[10];
		frame = (String)_values[11];
		headerClass = (String)_values[12];
		lang = (String)_values[13];
		onclick = (String)_values[14];
		ondblclick = (String)_values[15];
		onkeydown = (String)_values[16];
		onkeypress = (String)_values[17];
		onkeyup = (String)_values[18];
		onmousedown = (String)_values[19];
		onmousemove = (String)_values[20];
		onmouseout = (String)_values[21];
		onmouseover = (String)_values[22];
		onmouseup = (String)_values[23];
		rowClasses = (String)_values[24];
		rules = (String)_values[25];
		style = (String)_values[26];
		styleClass = (String)_values[27];
		summary = (String)_values[28];
		title = (String)_values[29];
		width = (String)_values[30];
	}
}
