// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HtmlColumn.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIColumn;
import javax.faces.context.FacesContext;

public class HtmlColumn extends UIColumn
{

	public static final String COMPONENT_TYPE = "javax.faces.HtmlColumn";
	private String footerClass;
	private String headerClass;
	private Object _values[];

	public HtmlColumn()
	{
	}

	public String getFooterClass()
	{
		if (null != footerClass)
			return footerClass;
		ValueExpression _ve = getValueExpression("footerClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setFooterClass(String footerClass)
	{
		this.footerClass = footerClass;
	}

	public String getHeaderClass()
	{
		if (null != headerClass)
			return headerClass;
		ValueExpression _ve = getValueExpression("headerClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setHeaderClass(String headerClass)
	{
		this.headerClass = headerClass;
	}

	public Object saveState(FacesContext _context)
	{
		if (_values == null)
			_values = new Object[3];
		_values[0] = super.saveState(_context);
		_values[1] = footerClass;
		_values[2] = headerClass;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state)
	{
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		footerClass = (String)_values[1];
		headerClass = (String)_values[2];
	}
}
