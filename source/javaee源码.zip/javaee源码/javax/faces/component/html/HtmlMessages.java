// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HtmlMessages.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIMessages;
import javax.faces.context.FacesContext;

public class HtmlMessages extends UIMessages
{

	public static final String COMPONENT_TYPE = "javax.faces.HtmlMessages";
	private String dir;
	private String errorClass;
	private String errorStyle;
	private String fatalClass;
	private String fatalStyle;
	private String infoClass;
	private String infoStyle;
	private String lang;
	private String layout;
	private String style;
	private String styleClass;
	private String title;
	private boolean tooltip;
	private boolean tooltip_set;
	private String warnClass;
	private String warnStyle;
	private Object _values[];

	public HtmlMessages()
	{
		layout = "list";
		tooltip = false;
		tooltip_set = false;
		setRendererType("javax.faces.Messages");
	}

	public String getDir()
	{
		if (null != dir)
			return dir;
		ValueExpression _ve = getValueExpression("dir");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setDir(String dir)
	{
		this.dir = dir;
	}

	public String getErrorClass()
	{
		if (null != errorClass)
			return errorClass;
		ValueExpression _ve = getValueExpression("errorClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setErrorClass(String errorClass)
	{
		this.errorClass = errorClass;
	}

	public String getErrorStyle()
	{
		if (null != errorStyle)
			return errorStyle;
		ValueExpression _ve = getValueExpression("errorStyle");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setErrorStyle(String errorStyle)
	{
		this.errorStyle = errorStyle;
	}

	public String getFatalClass()
	{
		if (null != fatalClass)
			return fatalClass;
		ValueExpression _ve = getValueExpression("fatalClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setFatalClass(String fatalClass)
	{
		this.fatalClass = fatalClass;
	}

	public String getFatalStyle()
	{
		if (null != fatalStyle)
			return fatalStyle;
		ValueExpression _ve = getValueExpression("fatalStyle");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setFatalStyle(String fatalStyle)
	{
		this.fatalStyle = fatalStyle;
	}

	public String getInfoClass()
	{
		if (null != infoClass)
			return infoClass;
		ValueExpression _ve = getValueExpression("infoClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setInfoClass(String infoClass)
	{
		this.infoClass = infoClass;
	}

	public String getInfoStyle()
	{
		if (null != infoStyle)
			return infoStyle;
		ValueExpression _ve = getValueExpression("infoStyle");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setInfoStyle(String infoStyle)
	{
		this.infoStyle = infoStyle;
	}

	public String getLang()
	{
		if (null != lang)
			return lang;
		ValueExpression _ve = getValueExpression("lang");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getLayout()
	{
		if (null != layout)
			return layout;
		ValueExpression _ve = getValueExpression("layout");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setLayout(String layout)
	{
		this.layout = layout;
	}

	public String getStyle()
	{
		if (null != style)
			return style;
		ValueExpression _ve = getValueExpression("style");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyle(String style)
	{
		this.style = style;
	}

	public String getStyleClass()
	{
		if (null != styleClass)
			return styleClass;
		ValueExpression _ve = getValueExpression("styleClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyleClass(String styleClass)
	{
		this.styleClass = styleClass;
	}

	public String getTitle()
	{
		if (null != title)
			return title;
		ValueExpression _ve = getValueExpression("title");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public boolean isTooltip()
	{
		if (tooltip_set)
			return tooltip;
		ValueExpression _ve = getValueExpression("tooltip");
		if (_ve != null)
		{
			Object _result = _ve.getValue(getFacesContext().getELContext());
			if (_result == null)
				return false;
			else
				return ((Boolean)_result).booleanValue();
		} else
		{
			return tooltip;
		}
	}

	public void setTooltip(boolean tooltip)
	{
		this.tooltip = tooltip;
		tooltip_set = true;
	}

	public String getWarnClass()
	{
		if (null != warnClass)
			return warnClass;
		ValueExpression _ve = getValueExpression("warnClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setWarnClass(String warnClass)
	{
		this.warnClass = warnClass;
	}

	public String getWarnStyle()
	{
		if (null != warnStyle)
			return warnStyle;
		ValueExpression _ve = getValueExpression("warnStyle");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setWarnStyle(String warnStyle)
	{
		this.warnStyle = warnStyle;
	}

	public Object saveState(FacesContext _context)
	{
		if (_values == null)
			_values = new Object[17];
		_values[0] = super.saveState(_context);
		_values[1] = dir;
		_values[2] = errorClass;
		_values[3] = errorStyle;
		_values[4] = fatalClass;
		_values[5] = fatalStyle;
		_values[6] = infoClass;
		_values[7] = infoStyle;
		_values[8] = lang;
		_values[9] = layout;
		_values[10] = style;
		_values[11] = styleClass;
		_values[12] = title;
		_values[13] = tooltip ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[14] = tooltip_set ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[15] = warnClass;
		_values[16] = warnStyle;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state)
	{
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		dir = (String)_values[1];
		errorClass = (String)_values[2];
		errorStyle = (String)_values[3];
		fatalClass = (String)_values[4];
		fatalStyle = (String)_values[5];
		infoClass = (String)_values[6];
		infoStyle = (String)_values[7];
		lang = (String)_values[8];
		layout = (String)_values[9];
		style = (String)_values[10];
		styleClass = (String)_values[11];
		title = (String)_values[12];
		tooltip = ((Boolean)_values[13]).booleanValue();
		tooltip_set = ((Boolean)_values[14]).booleanValue();
		warnClass = (String)_values[15];
		warnStyle = (String)_values[16];
	}
}
