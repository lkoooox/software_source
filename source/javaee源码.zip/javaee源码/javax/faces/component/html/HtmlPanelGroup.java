// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HtmlPanelGroup.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIPanel;
import javax.faces.context.FacesContext;

public class HtmlPanelGroup extends UIPanel
{

	public static final String COMPONENT_TYPE = "javax.faces.HtmlPanelGroup";
	private String layout;
	private String style;
	private String styleClass;
	private Object _values[];

	public HtmlPanelGroup()
	{
		setRendererType("javax.faces.Group");
	}

	public String getLayout()
	{
		if (null != layout)
			return layout;
		ValueExpression _ve = getValueExpression("layout");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setLayout(String layout)
	{
		this.layout = layout;
	}

	public String getStyle()
	{
		if (null != style)
			return style;
		ValueExpression _ve = getValueExpression("style");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyle(String style)
	{
		this.style = style;
	}

	public String getStyleClass()
	{
		if (null != styleClass)
			return styleClass;
		ValueExpression _ve = getValueExpression("styleClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyleClass(String styleClass)
	{
		this.styleClass = styleClass;
	}

	public Object saveState(FacesContext _context)
	{
		if (_values == null)
			_values = new Object[4];
		_values[0] = super.saveState(_context);
		_values[1] = layout;
		_values[2] = style;
		_values[3] = styleClass;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state)
	{
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		layout = (String)_values[1];
		style = (String)_values[2];
		styleClass = (String)_values[3];
	}
}
