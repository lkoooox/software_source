// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HtmlOutputLink.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;

public class HtmlOutputLink extends UIOutput
{

	public static final String COMPONENT_TYPE = "javax.faces.HtmlOutputLink";
	private String accesskey;
	private String charset;
	private String coords;
	private String dir;
	private boolean disabled;
	private boolean disabled_set;
	private String hreflang;
	private String lang;
	private String onblur;
	private String onclick;
	private String ondblclick;
	private String onfocus;
	private String onkeydown;
	private String onkeypress;
	private String onkeyup;
	private String onmousedown;
	private String onmousemove;
	private String onmouseout;
	private String onmouseover;
	private String onmouseup;
	private String rel;
	private String rev;
	private String shape;
	private String style;
	private String styleClass;
	private String tabindex;
	private String target;
	private String title;
	private String type;
	private Object _values[];

	public HtmlOutputLink()
	{
		disabled = false;
		disabled_set = false;
		setRendererType("javax.faces.Link");
	}

	public String getAccesskey()
	{
		if (null != accesskey)
			return accesskey;
		ValueExpression _ve = getValueExpression("accesskey");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setAccesskey(String accesskey)
	{
		this.accesskey = accesskey;
	}

	public String getCharset()
	{
		if (null != charset)
			return charset;
		ValueExpression _ve = getValueExpression("charset");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setCharset(String charset)
	{
		this.charset = charset;
	}

	public String getCoords()
	{
		if (null != coords)
			return coords;
		ValueExpression _ve = getValueExpression("coords");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setCoords(String coords)
	{
		this.coords = coords;
	}

	public String getDir()
	{
		if (null != dir)
			return dir;
		ValueExpression _ve = getValueExpression("dir");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setDir(String dir)
	{
		this.dir = dir;
	}

	public boolean isDisabled()
	{
		if (disabled_set)
			return disabled;
		ValueExpression _ve = getValueExpression("disabled");
		if (_ve != null)
		{
			Object _result = _ve.getValue(getFacesContext().getELContext());
			if (_result == null)
				return false;
			else
				return ((Boolean)_result).booleanValue();
		} else
		{
			return disabled;
		}
	}

	public void setDisabled(boolean disabled)
	{
		this.disabled = disabled;
		disabled_set = true;
	}

	public String getHreflang()
	{
		if (null != hreflang)
			return hreflang;
		ValueExpression _ve = getValueExpression("hreflang");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setHreflang(String hreflang)
	{
		this.hreflang = hreflang;
	}

	public String getLang()
	{
		if (null != lang)
			return lang;
		ValueExpression _ve = getValueExpression("lang");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getOnblur()
	{
		if (null != onblur)
			return onblur;
		ValueExpression _ve = getValueExpression("onblur");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnblur(String onblur)
	{
		this.onblur = onblur;
	}

	public String getOnclick()
	{
		if (null != onclick)
			return onclick;
		ValueExpression _ve = getValueExpression("onclick");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnclick(String onclick)
	{
		this.onclick = onclick;
	}

	public String getOndblclick()
	{
		if (null != ondblclick)
			return ondblclick;
		ValueExpression _ve = getValueExpression("ondblclick");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOndblclick(String ondblclick)
	{
		this.ondblclick = ondblclick;
	}

	public String getOnfocus()
	{
		if (null != onfocus)
			return onfocus;
		ValueExpression _ve = getValueExpression("onfocus");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnfocus(String onfocus)
	{
		this.onfocus = onfocus;
	}

	public String getOnkeydown()
	{
		if (null != onkeydown)
			return onkeydown;
		ValueExpression _ve = getValueExpression("onkeydown");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeydown(String onkeydown)
	{
		this.onkeydown = onkeydown;
	}

	public String getOnkeypress()
	{
		if (null != onkeypress)
			return onkeypress;
		ValueExpression _ve = getValueExpression("onkeypress");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeypress(String onkeypress)
	{
		this.onkeypress = onkeypress;
	}

	public String getOnkeyup()
	{
		if (null != onkeyup)
			return onkeyup;
		ValueExpression _ve = getValueExpression("onkeyup");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeyup(String onkeyup)
	{
		this.onkeyup = onkeyup;
	}

	public String getOnmousedown()
	{
		if (null != onmousedown)
			return onmousedown;
		ValueExpression _ve = getValueExpression("onmousedown");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmousedown(String onmousedown)
	{
		this.onmousedown = onmousedown;
	}

	public String getOnmousemove()
	{
		if (null != onmousemove)
			return onmousemove;
		ValueExpression _ve = getValueExpression("onmousemove");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmousemove(String onmousemove)
	{
		this.onmousemove = onmousemove;
	}

	public String getOnmouseout()
	{
		if (null != onmouseout)
			return onmouseout;
		ValueExpression _ve = getValueExpression("onmouseout");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseout(String onmouseout)
	{
		this.onmouseout = onmouseout;
	}

	public String getOnmouseover()
	{
		if (null != onmouseover)
			return onmouseover;
		ValueExpression _ve = getValueExpression("onmouseover");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseover(String onmouseover)
	{
		this.onmouseover = onmouseover;
	}

	public String getOnmouseup()
	{
		if (null != onmouseup)
			return onmouseup;
		ValueExpression _ve = getValueExpression("onmouseup");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseup(String onmouseup)
	{
		this.onmouseup = onmouseup;
	}

	public String getRel()
	{
		if (null != rel)
			return rel;
		ValueExpression _ve = getValueExpression("rel");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setRel(String rel)
	{
		this.rel = rel;
	}

	public String getRev()
	{
		if (null != rev)
			return rev;
		ValueExpression _ve = getValueExpression("rev");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setRev(String rev)
	{
		this.rev = rev;
	}

	public String getShape()
	{
		if (null != shape)
			return shape;
		ValueExpression _ve = getValueExpression("shape");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setShape(String shape)
	{
		this.shape = shape;
	}

	public String getStyle()
	{
		if (null != style)
			return style;
		ValueExpression _ve = getValueExpression("style");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyle(String style)
	{
		this.style = style;
	}

	public String getStyleClass()
	{
		if (null != styleClass)
			return styleClass;
		ValueExpression _ve = getValueExpression("styleClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyleClass(String styleClass)
	{
		this.styleClass = styleClass;
	}

	public String getTabindex()
	{
		if (null != tabindex)
			return tabindex;
		ValueExpression _ve = getValueExpression("tabindex");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTabindex(String tabindex)
	{
		this.tabindex = tabindex;
	}

	public String getTarget()
	{
		if (null != target)
			return target;
		ValueExpression _ve = getValueExpression("target");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTarget(String target)
	{
		this.target = target;
	}

	public String getTitle()
	{
		if (null != title)
			return title;
		ValueExpression _ve = getValueExpression("title");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getType()
	{
		if (null != type)
			return type;
		ValueExpression _ve = getValueExpression("type");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public Object saveState(FacesContext _context)
	{
		if (_values == null)
			_values = new Object[30];
		_values[0] = super.saveState(_context);
		_values[1] = accesskey;
		_values[2] = charset;
		_values[3] = coords;
		_values[4] = dir;
		_values[5] = disabled ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[6] = disabled_set ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[7] = hreflang;
		_values[8] = lang;
		_values[9] = onblur;
		_values[10] = onclick;
		_values[11] = ondblclick;
		_values[12] = onfocus;
		_values[13] = onkeydown;
		_values[14] = onkeypress;
		_values[15] = onkeyup;
		_values[16] = onmousedown;
		_values[17] = onmousemove;
		_values[18] = onmouseout;
		_values[19] = onmouseover;
		_values[20] = onmouseup;
		_values[21] = rel;
		_values[22] = rev;
		_values[23] = shape;
		_values[24] = style;
		_values[25] = styleClass;
		_values[26] = tabindex;
		_values[27] = target;
		_values[28] = title;
		_values[29] = type;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state)
	{
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		accesskey = (String)_values[1];
		charset = (String)_values[2];
		coords = (String)_values[3];
		dir = (String)_values[4];
		disabled = ((Boolean)_values[5]).booleanValue();
		disabled_set = ((Boolean)_values[6]).booleanValue();
		hreflang = (String)_values[7];
		lang = (String)_values[8];
		onblur = (String)_values[9];
		onclick = (String)_values[10];
		ondblclick = (String)_values[11];
		onfocus = (String)_values[12];
		onkeydown = (String)_values[13];
		onkeypress = (String)_values[14];
		onkeyup = (String)_values[15];
		onmousedown = (String)_values[16];
		onmousemove = (String)_values[17];
		onmouseout = (String)_values[18];
		onmouseover = (String)_values[19];
		onmouseup = (String)_values[20];
		rel = (String)_values[21];
		rev = (String)_values[22];
		shape = (String)_values[23];
		style = (String)_values[24];
		styleClass = (String)_values[25];
		tabindex = (String)_values[26];
		target = (String)_values[27];
		title = (String)_values[28];
		type = (String)_values[29];
	}
}
