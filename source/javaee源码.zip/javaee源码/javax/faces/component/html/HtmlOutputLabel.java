// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HtmlOutputLabel.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIOutput;
import javax.faces.context.FacesContext;

public class HtmlOutputLabel extends UIOutput
{

	public static final String COMPONENT_TYPE = "javax.faces.HtmlOutputLabel";
	private String accesskey;
	private String dir;
	private boolean escape;
	private boolean escape_set;
	private String _for;
	private String lang;
	private String onblur;
	private String onclick;
	private String ondblclick;
	private String onfocus;
	private String onkeydown;
	private String onkeypress;
	private String onkeyup;
	private String onmousedown;
	private String onmousemove;
	private String onmouseout;
	private String onmouseover;
	private String onmouseup;
	private String style;
	private String styleClass;
	private String tabindex;
	private String title;
	private Object _values[];

	public HtmlOutputLabel()
	{
		escape = true;
		escape_set = false;
		setRendererType("javax.faces.Label");
	}

	public String getAccesskey()
	{
		if (null != accesskey)
			return accesskey;
		ValueExpression _ve = getValueExpression("accesskey");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setAccesskey(String accesskey)
	{
		this.accesskey = accesskey;
	}

	public String getDir()
	{
		if (null != dir)
			return dir;
		ValueExpression _ve = getValueExpression("dir");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setDir(String dir)
	{
		this.dir = dir;
	}

	public boolean isEscape()
	{
		if (escape_set)
			return escape;
		ValueExpression _ve = getValueExpression("escape");
		if (_ve != null)
		{
			Object _result = _ve.getValue(getFacesContext().getELContext());
			if (_result == null)
				return false;
			else
				return ((Boolean)_result).booleanValue();
		} else
		{
			return escape;
		}
	}

	public void setEscape(boolean escape)
	{
		this.escape = escape;
		escape_set = true;
	}

	public String getFor()
	{
		if (null != _for)
			return _for;
		ValueExpression _ve = getValueExpression("for");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setFor(String _for)
	{
		this._for = _for;
	}

	public String getLang()
	{
		if (null != lang)
			return lang;
		ValueExpression _ve = getValueExpression("lang");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getOnblur()
	{
		if (null != onblur)
			return onblur;
		ValueExpression _ve = getValueExpression("onblur");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnblur(String onblur)
	{
		this.onblur = onblur;
	}

	public String getOnclick()
	{
		if (null != onclick)
			return onclick;
		ValueExpression _ve = getValueExpression("onclick");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnclick(String onclick)
	{
		this.onclick = onclick;
	}

	public String getOndblclick()
	{
		if (null != ondblclick)
			return ondblclick;
		ValueExpression _ve = getValueExpression("ondblclick");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOndblclick(String ondblclick)
	{
		this.ondblclick = ondblclick;
	}

	public String getOnfocus()
	{
		if (null != onfocus)
			return onfocus;
		ValueExpression _ve = getValueExpression("onfocus");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnfocus(String onfocus)
	{
		this.onfocus = onfocus;
	}

	public String getOnkeydown()
	{
		if (null != onkeydown)
			return onkeydown;
		ValueExpression _ve = getValueExpression("onkeydown");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeydown(String onkeydown)
	{
		this.onkeydown = onkeydown;
	}

	public String getOnkeypress()
	{
		if (null != onkeypress)
			return onkeypress;
		ValueExpression _ve = getValueExpression("onkeypress");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeypress(String onkeypress)
	{
		this.onkeypress = onkeypress;
	}

	public String getOnkeyup()
	{
		if (null != onkeyup)
			return onkeyup;
		ValueExpression _ve = getValueExpression("onkeyup");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeyup(String onkeyup)
	{
		this.onkeyup = onkeyup;
	}

	public String getOnmousedown()
	{
		if (null != onmousedown)
			return onmousedown;
		ValueExpression _ve = getValueExpression("onmousedown");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmousedown(String onmousedown)
	{
		this.onmousedown = onmousedown;
	}

	public String getOnmousemove()
	{
		if (null != onmousemove)
			return onmousemove;
		ValueExpression _ve = getValueExpression("onmousemove");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmousemove(String onmousemove)
	{
		this.onmousemove = onmousemove;
	}

	public String getOnmouseout()
	{
		if (null != onmouseout)
			return onmouseout;
		ValueExpression _ve = getValueExpression("onmouseout");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseout(String onmouseout)
	{
		this.onmouseout = onmouseout;
	}

	public String getOnmouseover()
	{
		if (null != onmouseover)
			return onmouseover;
		ValueExpression _ve = getValueExpression("onmouseover");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseover(String onmouseover)
	{
		this.onmouseover = onmouseover;
	}

	public String getOnmouseup()
	{
		if (null != onmouseup)
			return onmouseup;
		ValueExpression _ve = getValueExpression("onmouseup");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseup(String onmouseup)
	{
		this.onmouseup = onmouseup;
	}

	public String getStyle()
	{
		if (null != style)
			return style;
		ValueExpression _ve = getValueExpression("style");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyle(String style)
	{
		this.style = style;
	}

	public String getStyleClass()
	{
		if (null != styleClass)
			return styleClass;
		ValueExpression _ve = getValueExpression("styleClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyleClass(String styleClass)
	{
		this.styleClass = styleClass;
	}

	public String getTabindex()
	{
		if (null != tabindex)
			return tabindex;
		ValueExpression _ve = getValueExpression("tabindex");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTabindex(String tabindex)
	{
		this.tabindex = tabindex;
	}

	public String getTitle()
	{
		if (null != title)
			return title;
		ValueExpression _ve = getValueExpression("title");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public Object saveState(FacesContext _context)
	{
		if (_values == null)
			_values = new Object[23];
		_values[0] = super.saveState(_context);
		_values[1] = accesskey;
		_values[2] = dir;
		_values[3] = escape ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[4] = escape_set ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		_values[5] = _for;
		_values[6] = lang;
		_values[7] = onblur;
		_values[8] = onclick;
		_values[9] = ondblclick;
		_values[10] = onfocus;
		_values[11] = onkeydown;
		_values[12] = onkeypress;
		_values[13] = onkeyup;
		_values[14] = onmousedown;
		_values[15] = onmousemove;
		_values[16] = onmouseout;
		_values[17] = onmouseover;
		_values[18] = onmouseup;
		_values[19] = style;
		_values[20] = styleClass;
		_values[21] = tabindex;
		_values[22] = title;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state)
	{
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		accesskey = (String)_values[1];
		dir = (String)_values[2];
		escape = ((Boolean)_values[3]).booleanValue();
		escape_set = ((Boolean)_values[4]).booleanValue();
		_for = (String)_values[5];
		lang = (String)_values[6];
		onblur = (String)_values[7];
		onclick = (String)_values[8];
		ondblclick = (String)_values[9];
		onfocus = (String)_values[10];
		onkeydown = (String)_values[11];
		onkeypress = (String)_values[12];
		onkeyup = (String)_values[13];
		onmousedown = (String)_values[14];
		onmousemove = (String)_values[15];
		onmouseout = (String)_values[16];
		onmouseover = (String)_values[17];
		onmouseup = (String)_values[18];
		style = (String)_values[19];
		styleClass = (String)_values[20];
		tabindex = (String)_values[21];
		title = (String)_values[22];
	}
}
