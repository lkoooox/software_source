// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HtmlForm.java

package javax.faces.component.html;

import javax.el.ValueExpression;
import javax.faces.component.UIForm;
import javax.faces.context.FacesContext;

public class HtmlForm extends UIForm
{

	public static final String COMPONENT_TYPE = "javax.faces.HtmlForm";
	private String accept;
	private String acceptcharset;
	private String dir;
	private String enctype;
	private String lang;
	private String onclick;
	private String ondblclick;
	private String onkeydown;
	private String onkeypress;
	private String onkeyup;
	private String onmousedown;
	private String onmousemove;
	private String onmouseout;
	private String onmouseover;
	private String onmouseup;
	private String onreset;
	private String onsubmit;
	private String style;
	private String styleClass;
	private String target;
	private String title;
	private Object _values[];

	public HtmlForm()
	{
		enctype = "application/x-www-form-urlencoded";
		setRendererType("javax.faces.Form");
	}

	public String getAccept()
	{
		if (null != accept)
			return accept;
		ValueExpression _ve = getValueExpression("accept");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setAccept(String accept)
	{
		this.accept = accept;
	}

	public String getAcceptcharset()
	{
		if (null != acceptcharset)
			return acceptcharset;
		ValueExpression _ve = getValueExpression("acceptcharset");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setAcceptcharset(String acceptcharset)
	{
		this.acceptcharset = acceptcharset;
	}

	public String getDir()
	{
		if (null != dir)
			return dir;
		ValueExpression _ve = getValueExpression("dir");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setDir(String dir)
	{
		this.dir = dir;
	}

	public String getEnctype()
	{
		if (null != enctype)
			return enctype;
		ValueExpression _ve = getValueExpression("enctype");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setEnctype(String enctype)
	{
		this.enctype = enctype;
	}

	public String getLang()
	{
		if (null != lang)
			return lang;
		ValueExpression _ve = getValueExpression("lang");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setLang(String lang)
	{
		this.lang = lang;
	}

	public String getOnclick()
	{
		if (null != onclick)
			return onclick;
		ValueExpression _ve = getValueExpression("onclick");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnclick(String onclick)
	{
		this.onclick = onclick;
	}

	public String getOndblclick()
	{
		if (null != ondblclick)
			return ondblclick;
		ValueExpression _ve = getValueExpression("ondblclick");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOndblclick(String ondblclick)
	{
		this.ondblclick = ondblclick;
	}

	public String getOnkeydown()
	{
		if (null != onkeydown)
			return onkeydown;
		ValueExpression _ve = getValueExpression("onkeydown");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeydown(String onkeydown)
	{
		this.onkeydown = onkeydown;
	}

	public String getOnkeypress()
	{
		if (null != onkeypress)
			return onkeypress;
		ValueExpression _ve = getValueExpression("onkeypress");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeypress(String onkeypress)
	{
		this.onkeypress = onkeypress;
	}

	public String getOnkeyup()
	{
		if (null != onkeyup)
			return onkeyup;
		ValueExpression _ve = getValueExpression("onkeyup");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnkeyup(String onkeyup)
	{
		this.onkeyup = onkeyup;
	}

	public String getOnmousedown()
	{
		if (null != onmousedown)
			return onmousedown;
		ValueExpression _ve = getValueExpression("onmousedown");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmousedown(String onmousedown)
	{
		this.onmousedown = onmousedown;
	}

	public String getOnmousemove()
	{
		if (null != onmousemove)
			return onmousemove;
		ValueExpression _ve = getValueExpression("onmousemove");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmousemove(String onmousemove)
	{
		this.onmousemove = onmousemove;
	}

	public String getOnmouseout()
	{
		if (null != onmouseout)
			return onmouseout;
		ValueExpression _ve = getValueExpression("onmouseout");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseout(String onmouseout)
	{
		this.onmouseout = onmouseout;
	}

	public String getOnmouseover()
	{
		if (null != onmouseover)
			return onmouseover;
		ValueExpression _ve = getValueExpression("onmouseover");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseover(String onmouseover)
	{
		this.onmouseover = onmouseover;
	}

	public String getOnmouseup()
	{
		if (null != onmouseup)
			return onmouseup;
		ValueExpression _ve = getValueExpression("onmouseup");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnmouseup(String onmouseup)
	{
		this.onmouseup = onmouseup;
	}

	public String getOnreset()
	{
		if (null != onreset)
			return onreset;
		ValueExpression _ve = getValueExpression("onreset");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnreset(String onreset)
	{
		this.onreset = onreset;
	}

	public String getOnsubmit()
	{
		if (null != onsubmit)
			return onsubmit;
		ValueExpression _ve = getValueExpression("onsubmit");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setOnsubmit(String onsubmit)
	{
		this.onsubmit = onsubmit;
	}

	public String getStyle()
	{
		if (null != style)
			return style;
		ValueExpression _ve = getValueExpression("style");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyle(String style)
	{
		this.style = style;
	}

	public String getStyleClass()
	{
		if (null != styleClass)
			return styleClass;
		ValueExpression _ve = getValueExpression("styleClass");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setStyleClass(String styleClass)
	{
		this.styleClass = styleClass;
	}

	public String getTarget()
	{
		if (null != target)
			return target;
		ValueExpression _ve = getValueExpression("target");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTarget(String target)
	{
		this.target = target;
	}

	public String getTitle()
	{
		if (null != title)
			return title;
		ValueExpression _ve = getValueExpression("title");
		if (_ve != null)
			return (String)_ve.getValue(getFacesContext().getELContext());
		else
			return null;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public Object saveState(FacesContext _context)
	{
		if (_values == null)
			_values = new Object[22];
		_values[0] = super.saveState(_context);
		_values[1] = accept;
		_values[2] = acceptcharset;
		_values[3] = dir;
		_values[4] = enctype;
		_values[5] = lang;
		_values[6] = onclick;
		_values[7] = ondblclick;
		_values[8] = onkeydown;
		_values[9] = onkeypress;
		_values[10] = onkeyup;
		_values[11] = onmousedown;
		_values[12] = onmousemove;
		_values[13] = onmouseout;
		_values[14] = onmouseover;
		_values[15] = onmouseup;
		_values[16] = onreset;
		_values[17] = onsubmit;
		_values[18] = style;
		_values[19] = styleClass;
		_values[20] = target;
		_values[21] = title;
		return ((Object) (_values));
	}

	public void restoreState(FacesContext _context, Object _state)
	{
		_values = (Object[])(Object[])_state;
		super.restoreState(_context, _values[0]);
		accept = (String)_values[1];
		acceptcharset = (String)_values[2];
		dir = (String)_values[3];
		enctype = (String)_values[4];
		lang = (String)_values[5];
		onclick = (String)_values[6];
		ondblclick = (String)_values[7];
		onkeydown = (String)_values[8];
		onkeypress = (String)_values[9];
		onkeyup = (String)_values[10];
		onmousedown = (String)_values[11];
		onmousemove = (String)_values[12];
		onmouseout = (String)_values[13];
		onmouseover = (String)_values[14];
		onmouseup = (String)_values[15];
		onreset = (String)_values[16];
		onsubmit = (String)_values[17];
		style = (String)_values[18];
		styleClass = (String)_values[19];
		target = (String)_values[20];
		title = (String)_values[21];
	}
}
