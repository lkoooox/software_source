// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodBindingMethodExpressionAdapter.java

package javax.faces.component;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Arrays;
import javax.el.ELException;
import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.el.MethodInfo;
import javax.el.MethodNotFoundException;
import javax.el.PropertyNotFoundException;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.context.FacesContext;
import javax.faces.el.EvaluationException;
import javax.faces.el.MethodBinding;

// Referenced classes of package javax.faces.component:
//			StateHolder

class MethodBindingMethodExpressionAdapter extends MethodBinding
	implements StateHolder, Serializable
{

	private static final long serialVersionUID = 0x65cae489a8789699L;
	private MethodExpression methodExpression;
	private boolean tranzient;
	static final boolean $assertionsDisabled = !javax/faces/component/MethodBindingMethodExpressionAdapter.desiredAssertionStatus();

	public MethodBindingMethodExpressionAdapter()
	{
		methodExpression = null;
	}

	MethodBindingMethodExpressionAdapter(MethodExpression methodExpression)
	{
		this.methodExpression = null;
		this.methodExpression = methodExpression;
	}

	public Object invoke(FacesContext context, Object params[])
		throws EvaluationException, javax.faces.el.MethodNotFoundException
	{
		if (!$assertionsDisabled && null == methodExpression)
			throw new AssertionError();
		if (context == null)
			throw new NullPointerException("FacesConext -> null");
		Object result = null;
		try
		{
			result = methodExpression.invoke(context.getELContext(), params);
		}
		catch (MethodNotFoundException e)
		{
			throw new javax.faces.el.MethodNotFoundException(e);
		}
		catch (PropertyNotFoundException e)
		{
			throw new EvaluationException(e);
		}
		catch (ELException e)
		{
			Throwable cause = e.getCause();
			if (cause != null)
				for (; cause.getCause() != null; cause = cause.getCause());
			else
				cause = e;
			throw new EvaluationException(cause);
		}
		catch (NullPointerException e)
		{
			throw new javax.faces.el.MethodNotFoundException(e);
		}
		return result;
	}

	public Class getType(FacesContext context)
		throws javax.faces.el.MethodNotFoundException
	{
		if (!$assertionsDisabled && null == methodExpression)
			throw new AssertionError();
		if (context == null)
			throw new NullPointerException("FacesConext -> null");
		Class result = null;
		if (context == null)
			throw new NullPointerException();
		try
		{
			MethodInfo mi = methodExpression.getMethodInfo(context.getELContext());
			result = mi.getReturnType();
		}
		catch (PropertyNotFoundException e)
		{
			throw new javax.faces.el.MethodNotFoundException(e);
		}
		catch (MethodNotFoundException e)
		{
			throw new javax.faces.el.MethodNotFoundException(e);
		}
		catch (ELException e)
		{
			throw new javax.faces.el.MethodNotFoundException(e);
		}
		return result;
	}

	public String getExpressionString()
	{
		if (!$assertionsDisabled && null == methodExpression)
			throw new AssertionError();
		else
			return methodExpression.getExpressionString();
	}

	public boolean equals(Object other)
	{
		if (this == other)
			return true;
		if (other instanceof MethodBindingMethodExpressionAdapter)
			return methodExpression.equals(((MethodBindingMethodExpressionAdapter)other).getWrapped());
		if (other instanceof MethodBinding)
		{
			MethodBinding binding = (MethodBinding)other;
			String expr = binding.getExpressionString();
			int idx = expr.indexOf('.');
			String target = expr.substring(0, idx).substring(2);
			String t = expr.substring(idx + 1);
			String method = t.substring(0, t.length() - 1);
			FacesContext context = FacesContext.getCurrentInstance();
			javax.el.ELContext elContext = context.getELContext();
			MethodInfo controlInfo = methodExpression.getMethodInfo(elContext);
			if (!controlInfo.getName().equals(method))
				return false;
			ExpressionFactory factory = context.getApplication().getExpressionFactory();
			ValueExpression ve = factory.createValueExpression(elContext, (new StringBuilder()).append("#{").append(target).append('}').toString(), java/lang/Object);
			if (ve == null)
				return false;
			Object result = ve.getValue(elContext);
			if (result == null)
				return false;
			Class type = binding.getType(context);
			Method methods[] = result.getClass().getMethods();
			Method arr$[] = methods;
			int len$ = arr$.length;
			for (int i$ = 0; i$ < len$; i$++)
			{
				Method meth = arr$[i$];
				if (meth.getName().equals(method) && type.equals(controlInfo.getReturnType()) && Arrays.equals(meth.getParameterTypes(), controlInfo.getParamTypes()))
					return true;
			}

		}
		return false;
	}

	public int hashCode()
	{
		if (!$assertionsDisabled && null == methodExpression)
			throw new AssertionError();
		else
			return methodExpression.hashCode();
	}

	public boolean isTransient()
	{
		return tranzient;
	}

	public void setTransient(boolean tranzient)
	{
		this.tranzient = tranzient;
	}

	public Object saveState(FacesContext context)
	{
		Object result = null;
		if (!tranzient)
			if (methodExpression instanceof StateHolder)
			{
				Object stateStruct[] = new Object[2];
				stateStruct[0] = ((StateHolder)methodExpression).saveState(context);
				stateStruct[1] = methodExpression.getClass().getName();
				result = ((Object) (stateStruct));
			} else
			{
				result = methodExpression;
			}
		return result;
	}

	public void restoreState(FacesContext context, Object state)
	{
		if (null == state)
			return;
		if (!(state instanceof MethodExpression))
		{
			Object stateStruct[] = (Object[])(Object[])state;
			Object savedState = stateStruct[0];
			String className = stateStruct[1].toString();
			MethodExpression result = null;
			Class toRestoreClass = null;
			if (null != className)
			{
				try
				{
					toRestoreClass = loadClass(className, this);
				}
				catch (ClassNotFoundException e)
				{
					throw new IllegalStateException(e.getMessage());
				}
				if (null != toRestoreClass)
					try
					{
						result = (MethodExpression)toRestoreClass.newInstance();
					}
					catch (InstantiationException e)
					{
						throw new IllegalStateException(e.getMessage());
					}
					catch (IllegalAccessException a)
					{
						throw new IllegalStateException(a.getMessage());
					}
				if (null != result && null != savedState)
					((StateHolder)result).restoreState(context, savedState);
				methodExpression = result;
			}
		} else
		{
			methodExpression = (MethodExpression)state;
		}
	}

	public MethodExpression getWrapped()
	{
		return methodExpression;
	}

	private static Class loadClass(String name, Object fallbackClass)
		throws ClassNotFoundException
	{
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		if (loader == null)
			loader = fallbackClass.getClass().getClassLoader();
		return Class.forName(name, true, loader);
	}

}
