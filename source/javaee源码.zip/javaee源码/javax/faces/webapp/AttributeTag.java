// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   AttributeTag.java

package javax.faces.webapp;

import java.util.Map;
import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

// Referenced classes of package javax.faces.webapp:
//			UIComponentClassicTagBase, UIComponentTag

/**
 * @deprecated Class AttributeTag is deprecated
 */

public class AttributeTag extends TagSupport
{

	private static final long serialVersionUID = 0x93fd67fd4b6acab2L;
	private String name;
	private String value;

	public AttributeTag()
	{
		name = null;
		value = null;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void setValue(String value)
	{
		this.value = value;
	}

	public int doStartTag()
		throws JspException
	{
		UIComponentClassicTagBase tag = UIComponentTag.getParentUIComponentClassicTagBase(pageContext);
		if (tag == null)
			throw new JspException("Not nested in a UIComponentTag");
		UIComponent component = tag.getComponentInstance();
		if (component == null)
			throw new JspException("No component associated with UIComponentTag");
		FacesContext context = FacesContext.getCurrentInstance();
		ExpressionFactory exprFactory = context.getApplication().getExpressionFactory();
		javax.el.ELContext elContext = context.getELContext();
		String nameVal = (String)exprFactory.createValueExpression(elContext, name, java/lang/String).getValue(elContext);
		Object valueVal = exprFactory.createValueExpression(elContext, value, java/lang/Object).getValue(elContext);
		if (component.getAttributes().get(nameVal) == null)
			component.getAttributes().put(nameVal, valueVal);
		return 0;
	}

	public int doEndTag()
		throws JspException
	{
		release();
		return 6;
	}

	public void release()
	{
		name = null;
		value = null;
	}
}
