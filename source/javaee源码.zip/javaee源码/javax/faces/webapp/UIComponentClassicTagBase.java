// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UIComponentClassicTagBase.java

package javax.faces.webapp;

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.FacesException;
import javax.faces.application.Application;
import javax.faces.component.*;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletRequest;
import javax.servlet.jsp.*;
import javax.servlet.jsp.jstl.core.LoopTag;
import javax.servlet.jsp.tagext.*;

// Referenced classes of package javax.faces.webapp:
//			UIComponentTagBase, FacetTag

public abstract class UIComponentClassicTagBase extends UIComponentTagBase
	implements JspIdConsumer, BodyTag
{

	private static final String COMPONENT_TAG_STACK_ATTR = "javax.faces.webapp.COMPONENT_TAG_STACK";
	private static final String JSP_CREATED_COMPONENT_IDS = "javax.faces.webapp.COMPONENT_IDS";
	private static final String JSP_CREATED_FACET_NAMES = "javax.faces.webapp.FACET_NAMES";
	private static final String GLOBAL_ID_VIEW = "javax.faces.webapp.GLOBAL_ID_VIEW";
	private static final String CURRENT_FACES_CONTEXT = "javax.faces.webapp.CURRENT_FACES_CONTEXT";
	private static final String CURRENT_VIEW_ROOT = "javax.faces.webapp.CURRENT_VIEW_ROOT";
	protected static final String UNIQUE_ID_PREFIX = "j_id_";
	private static final String PREVIOUS_JSP_ID_SET = "javax.faces.webapp.PREVIOUS_JSP_ID_SET";
	protected BodyContent bodyContent;
	private UIComponent component;
	private FacesContext context;
	private boolean created;
	private List createdComponents;
	private List createdFacets;
	protected PageContext pageContext;
	private Tag parent;
	private String jspId;
	private String facesJspId;
	private String id;
	private UIComponentClassicTagBase parentTag;
	private boolean isNestedInIterator;
	static final boolean $assertionsDisabled = !javax/faces/webapp/UIComponentClassicTagBase.desiredAssertionStatus();

	public UIComponentClassicTagBase()
	{
		bodyContent = null;
		component = null;
		context = null;
		created = false;
		createdComponents = null;
		createdFacets = null;
		pageContext = null;
		parent = null;
		jspId = null;
		facesJspId = null;
		id = null;
		parentTag = null;
		isNestedInIterator = false;
	}

	protected int getDoStartValue()
		throws JspException
	{
		int result = 2;
		return result;
	}

	protected int getDoEndValue()
		throws JspException
	{
		return 6;
	}

	/**
	 * @deprecated Method encodeBegin is deprecated
	 */

	protected void encodeBegin()
		throws IOException
	{
		component.encodeBegin(context);
	}

	/**
	 * @deprecated Method encodeChildren is deprecated
	 */

	protected void encodeChildren()
		throws IOException
	{
		component.encodeChildren(context);
	}

	/**
	 * @deprecated Method encodeEnd is deprecated
	 */

	protected void encodeEnd()
		throws IOException
	{
		component.encodeEnd(context);
	}

	public void setPageContext(PageContext pageContext)
	{
		this.pageContext = pageContext;
	}

	public Tag getParent()
	{
		return parent;
	}

	public void setParent(Tag parent)
	{
		this.parent = parent;
	}

	protected void setupResponseWriter()
	{
	}

	private UIComponent createChild(FacesContext context, UIComponent parent, String componentId)
		throws JspException
	{
		UIComponent component = createComponent(context, componentId);
		UIComponentTagBase parentTag = getParentUIComponentClassicTagBase(pageContext);
		int indexOfNextChildTag = parentTag.getIndexOfNextChildTag();
		if (indexOfNextChildTag > parent.getChildCount())
			indexOfNextChildTag = parent.getChildCount();
		parent.getChildren().add(indexOfNextChildTag, component);
		created = true;
		return component;
	}

	private UIComponent createFacet(FacesContext context, UIComponent parent, String name, String newId)
		throws JspException
	{
		UIComponent component = createComponent(context, newId);
		parent.getFacets().put(name, component);
		created = true;
		return component;
	}

	private UIComponent getChild(UIComponent component, String componentId)
	{
		for (Iterator kids = component.getChildren().iterator(); kids.hasNext();)
		{
			UIComponent kid = (UIComponent)kids.next();
			if (componentId.equals(kid.getId()))
				return kid;
		}

		return null;
	}

	protected UIComponent findComponent(FacesContext context)
		throws JspException
	{
		if (component != null)
			return component;
		UIComponentClassicTagBase parentTag = getParentUIComponentClassicTagBase(pageContext);
		UIComponent parentComponent = null;
		if (parentTag != null)
		{
			parentComponent = parentTag.getComponentInstance();
		} else
		{
			parentComponent = context.getViewRoot();
			if (null == parentComponent.getAttributes().get("javax.faces.webapp.CURRENT_VIEW_ROOT"))
			{
				try
				{
					setProperties(parentComponent);
				}
				catch (FacesException e)
				{
					if (e.getCause() instanceof JspException)
						throw (JspException)e.getCause();
					else
						throw e;
				}
				if (null != id)
				{
					parentComponent.setId(id);
				} else
				{
					if (!$assertionsDisabled && null == getFacesJspId())
						throw new AssertionError();
					parentComponent.setId(getFacesJspId());
				}
				parentComponent.getAttributes().put("javax.faces.webapp.CURRENT_VIEW_ROOT", "javax.faces.webapp.CURRENT_VIEW_ROOT");
				created = true;
			} else
			if (hasBinding())
				try
				{
					setProperties(parentComponent);
				}
				catch (FacesException e)
				{
					if (e.getCause() instanceof JspException)
						throw (JspException)e.getCause();
					else
						throw e;
				}
			component = parentComponent;
			return component;
		}
		String newId = createId(context, parentComponent);
		String facetName = getFacetName();
		if (facetName != null)
		{
			component = (UIComponent)parentComponent.getFacets().get(facetName);
			if (component == null)
				component = createFacet(context, parentComponent, facetName, newId);
			return component;
		}
		component = getChild(parentComponent, newId);
		if (component == null)
			component = createChild(context, parentComponent, newId);
		return component;
	}

	public static UIComponentClassicTagBase getParentUIComponentClassicTagBase(PageContext context)
	{
		FacesContext facesContext = (FacesContext)context.getAttribute("javax.faces.webapp.CURRENT_FACES_CONTEXT");
		List list = (List)facesContext.getExternalContext().getRequestMap().get("javax.faces.webapp.COMPONENT_TAG_STACK");
		if (list != null)
			return (UIComponentClassicTagBase)list.get(list.size() - 1);
		else
			return null;
	}

	protected int getIndexOfNextChildTag()
	{
		if (createdComponents != null)
			return createdComponents.size();
		else
			return 0;
	}

	protected void addChild(UIComponent child)
	{
		if (createdComponents == null)
			createdComponents = new ArrayList(32);
		createdComponents.add(child.getId());
	}

	protected void addFacet(String name)
	{
		if (createdFacets == null)
			createdFacets = new ArrayList();
		createdFacets.add(name);
	}

	private void popUIComponentClassicTagBase()
	{
		Map requestMap = context.getExternalContext().getRequestMap();
		List list = (List)requestMap.get("javax.faces.webapp.COMPONENT_TAG_STACK");
		if (list != null)
		{
			list.remove(list.size() - 1);
			if (list.size() < 1)
				requestMap.remove("javax.faces.webapp.COMPONENT_TAG_STACK");
		}
	}

	private void pushUIComponentClassicTagBase()
	{
		Map requestMap = context.getExternalContext().getRequestMap();
		List list = (List)requestMap.get("javax.faces.webapp.COMPONENT_TAG_STACK");
		if (list == null)
		{
			list = new ArrayList();
			requestMap.put("javax.faces.webapp.COMPONENT_TAG_STACK", list);
		}
		list.add(this);
	}

	private void removeOldChildren()
	{
		List oldList = (List)component.getAttributes().get("javax.faces.webapp.COMPONENT_IDS");
		if (oldList != null && oldList.size() > 0)
			if (createdComponents != null)
			{
				Iterator olds = oldList.iterator();
				do
				{
					if (!olds.hasNext())
						break;
					String old = (String)olds.next();
					if (!createdComponents.contains(old))
					{
						UIComponent child = component.findComponent(old);
						if (child != null)
							component.getChildren().remove(child);
					}
				} while (true);
			} else
			{
				UIComponent child;
				for (Iterator olds = oldList.iterator(); olds.hasNext(); component.getChildren().remove(child))
				{
					String old = (String)olds.next();
					child = component.findComponent(old);
				}

			}
		if (createdComponents != null)
			component.getAttributes().put("javax.faces.webapp.COMPONENT_IDS", createdComponents);
		else
			component.getAttributes().remove("javax.faces.webapp.COMPONENT_IDS");
		createdComponents = null;
	}

	private void removeOldFacets()
	{
		List oldList = (List)component.getAttributes().get("javax.faces.webapp.FACET_NAMES");
		if (oldList != null)
			if (createdFacets != null)
			{
				Iterator olds = oldList.iterator();
				do
				{
					if (!olds.hasNext())
						break;
					String old = (String)olds.next();
					if (!createdFacets.contains(old))
						component.getFacets().remove(old);
				} while (true);
			} else
			{
				String old;
				for (Iterator olds = oldList.iterator(); olds.hasNext(); component.getFacets().remove(old))
					old = (String)olds.next();

			}
		if (createdFacets != null)
			component.getAttributes().put("javax.faces.webapp.FACET_NAMES", createdFacets);
		else
			component.getAttributes().remove("javax.faces.webapp.FACET_NAMES");
		createdFacets = null;
	}

	protected UIComponent createVerbatimComponentFromBodyContent()
	{
		UIOutput verbatim = null;
		String bodyContentString = null;
		String trimString = null;
		if (null != bodyContent && null != (bodyContentString = bodyContent.getString()) && 0 < (trimString = bodyContent.getString().trim()).length())
			if (!trimString.startsWith("<!--") || !trimString.endsWith("-->"))
			{
				verbatim = createVerbatimComponent();
				verbatim.setValue(bodyContentString);
				bodyContent.clearBody();
			} else
			{
				bodyContent.clearBody();
			}
		return verbatim;
	}

	protected UIOutput createVerbatimComponent()
	{
		if (!$assertionsDisabled && null == getFacesContext())
		{
			throw new AssertionError();
		} else
		{
			UIOutput verbatim = null;
			Application application = getFacesContext().getApplication();
			verbatim = (UIOutput)application.createComponent("javax.faces.HtmlOutputText");
			verbatim.setTransient(true);
			verbatim.getAttributes().put("escape", Boolean.FALSE);
			verbatim.setId(getFacesContext().getViewRoot().createUniqueId());
			return verbatim;
		}
	}

	protected void addVerbatimBeforeComponent(UIComponentClassicTagBase parentTag, UIComponent verbatim, UIComponent component)
	{
		UIComponent parent = component.getParent();
		if (null == parent)
			return;
		List children = parent.getChildren();
		List createdIds = (List)parent.getAttributes().get("javax.faces.webapp.COMPONENT_IDS");
		int indexOfComponentInParent = children.indexOf(component);
		boolean replace = indexOfComponentInParent > 0 && createdIds != null && createdIds.size() == children.size();
		if (replace)
		{
			UIComponent oldVerbatim = (UIComponent)children.get(indexOfComponentInParent - 1);
			if ((oldVerbatim instanceof UIOutput) && oldVerbatim.isTransient())
				children.set(indexOfComponentInParent - 1, verbatim);
			else
				children.add(indexOfComponentInParent, verbatim);
		} else
		{
			children.add(indexOfComponentInParent, verbatim);
		}
		parentTag.addChild(verbatim);
	}

	protected void addVerbatimAfterComponent(UIComponentClassicTagBase parentTag, UIComponent verbatim, UIComponent component)
	{
		int indexOfComponentInParent = 0;
		UIComponent parent = component.getParent();
		if (null == parent)
			return;
		List children = parent.getChildren();
		indexOfComponentInParent = children.indexOf(component);
		if (children.size() - 1 == indexOfComponentInParent)
			children.add(verbatim);
		else
			children.add(indexOfComponentInParent + 1, verbatim);
		parentTag.addChild(verbatim);
	}

	public int doStartTag()
		throws JspException
	{
		createdComponents = null;
		createdFacets = null;
		UIComponent verbatim = null;
		context = getFacesContext();
		if (null == context)
			throw new JspException("Can't find FacesContext");
		parentTag = getParentUIComponentClassicTagBase(pageContext);
		Map requestMap = context.getExternalContext().getRequestMap();
		Map componentIds = null;
		if (parentTag == null)
		{
			componentIds = new HashMap();
			requestMap.put("javax.faces.webapp.GLOBAL_ID_VIEW", componentIds);
		} else
		{
			componentIds = (Map)requestMap.get("javax.faces.webapp.GLOBAL_ID_VIEW");
		}
		if (null == getFacetName() && null != parentTag)
		{
			Tag p = getParent();
			if (null == p || (p instanceof LoopTag))
			{
				JspWriter out = pageContext.getOut();
				if (!(out instanceof BodyContent))
					try
					{
						out.flush();
					}
					catch (IOException ioe)
					{
						throw new JspException(ioe);
					}
			}
			verbatim = parentTag.createVerbatimComponentFromBodyContent();
		}
		component = findComponent(context);
		if (null != verbatim)
			addVerbatimBeforeComponent(parentTag, verbatim, component);
		Object tagInstance = null;
		String clientId = null;
		if (id != null)
		{
			clientId = component.getClientId(context);
			tagInstance = componentIds.get(clientId) != this ? null : ((Object) (this));
		}
		if (tagInstance == null)
		{
			if (null != id && clientId != null)
			{
				if (componentIds.containsKey(clientId))
				{
					StringWriter writer = new StringWriter(128);
					printTree(context.getViewRoot(), clientId, writer, 0);
					String msg = (new StringBuilder()).append("Duplicate component id: '").append(clientId).append("', first used in tag: '").append(componentIds.get(clientId).getClass().getName()).append("'\n").append(writer.toString()).toString();
					throw new JspException(new IllegalStateException(msg));
				}
				componentIds.put(clientId, this);
			}
			if (parentTag != null)
				if (getFacetName() == null)
					parentTag.addChild(component);
				else
					parentTag.addFacet(getFacetName());
		}
		pushUIComponentClassicTagBase();
		return getDoStartValue();
	}

	public int doEndTag()
		throws JspException
	{
		Exception exception;
		popUIComponentClassicTagBase();
		removeOldChildren();
		removeOldFacets();
		try
		{
			UIComponent verbatim = null;
			UIComponentClassicTagBase parentTag = getParentUIComponentClassicTagBase(pageContext);
			if (null != (verbatim = createVerbatimComponentFromBodyContent()))
			{
				component.getChildren().add(verbatim);
				if (null != parentTag)
					parentTag.addChild(verbatim);
			}
		}
		catch (Throwable e)
		{
			throw new JspException(e);
		}
		finally
		{
			component = null;
		}
		component = null;
		context = null;
		break MISSING_BLOCK_LABEL_92;
		context = null;
		throw exception;
		created = false;
		release();
		return getDoEndValue();
	}

	public void release()
	{
		parent = null;
		id = null;
		jspId = null;
		facesJspId = null;
		created = false;
		bodyContent = null;
		isNestedInIterator = false;
	}

	protected int getDoAfterBodyValue()
		throws JspException
	{
		return 0;
	}

	public void setBodyContent(BodyContent bodyContent)
	{
		this.bodyContent = bodyContent;
	}

	public JspWriter getPreviousOut()
	{
		return bodyContent.getEnclosingWriter();
	}

	public BodyContent getBodyContent()
	{
		return bodyContent;
	}

	public void doInitBody()
		throws JspException
	{
	}

	public int doAfterBody()
		throws JspException
	{
		UIComponent verbatim = null;
		UIComponentClassicTagBase parentTag = getParentUIComponentClassicTagBase(pageContext);
		if ((this == parentTag || null != parentTag && parentTag.getComponentInstance().getRendersChildren()) && null != (verbatim = createVerbatimComponentFromBodyContent()))
		{
			List createdIds = (List)component.getAttributes().get("javax.faces.webapp.COMPONENT_IDS");
			if (createdIds != null)
			{
				int listIdx = component.getChildCount();
				if (createdIds.size() == listIdx)
					component.getChildren().set(listIdx - 1, verbatim);
				else
					component.getChildren().add(verbatim);
			} else
			{
				component.getChildren().add(verbatim);
			}
			parentTag.addChild(verbatim);
		}
		return getDoAfterBodyValue();
	}

	public void setId(String id)
	{
		if (null != id && id.startsWith("j_id"))
		{
			throw new IllegalArgumentException();
		} else
		{
			this.id = id;
			return;
		}
	}

	protected String getId()
	{
		return id;
	}

	protected String getFacesJspId()
	{
		if (null == facesJspId)
			if (null != jspId)
			{
				facesJspId = (new StringBuilder()).append("j_id_").append(jspId).toString();
				if (isDuplicateId(facesJspId) || isIncludedOrForwarded())
					facesJspId = generateIncrementedId(facesJspId);
			} else
			{
				facesJspId = context.getViewRoot().createUniqueId();
			}
		return facesJspId;
	}

	private boolean isDuplicateId(String componentId)
	{
		boolean result = false;
		if (parentTag != null)
		{
			if (parentTag.isNestedInIterator)
				return true;
			List childComponents = parentTag.getCreatedComponents();
			if (childComponents != null)
			{
				result = childComponents.contains(componentId);
				if (result && !isNestedInIterator)
					return true;
			}
		}
		return result;
	}

	private String generateIncrementedId(String componentId)
	{
		Map requestMap = getFacesContext().getExternalContext().getRequestMap();
		Integer serialNum = (Integer)requestMap.get(componentId);
		if (null == serialNum)
			serialNum = new Integer(1);
		else
			serialNum = new Integer(serialNum.intValue() + 1);
		requestMap.put(componentId, serialNum);
		componentId = (new StringBuilder()).append(componentId).append("j_id_").append(serialNum.intValue()).toString();
		return componentId;
	}

	protected List getCreatedComponents()
	{
		return createdComponents;
	}

	private String createId(FacesContext context, UIComponent parent)
		throws JspException
	{
		if (id == null)
			return getFacesJspId();
		if (isDuplicateId(id))
			if (isNestedInIterator)
			{
				id = generateIncrementedId(id);
			} else
			{
				if (parent != null)
				{
					UIComponent container = getNamingContainer(parent);
					if (container != null)
					{
						UIComponent comp = container.findComponent(id);
						if (comp == null || context.getExternalContext().getRequestParameterMap().containsKey("javax.faces.ViewState"))
							return id;
					}
				}
				StringWriter writer = new StringWriter(128);
				printTree(context.getViewRoot(), id, writer, 0);
				String msg = (new StringBuilder()).append("Component ID '").append(id).append("' has already been used").append(" in the view.\n").append("See below for the view up to the point of").append(" the detected error.\n").append(writer.toString()).toString();
				throw new JspException(msg);
			}
		return id;
	}

	public void setJspId(String id)
	{
		facesJspId = null;
		updatePreviousJspIdAndIteratorStatus(id);
		jspId = id;
	}

	private void updatePreviousJspIdAndIteratorStatus(String id)
	{
		Set previousJspIdSet = null;
		if (null == (previousJspIdSet = (Set)pageContext.getRequest().getAttribute("javax.faces.webapp.PREVIOUS_JSP_ID_SET")))
			pageContext.getRequest().setAttribute("javax.faces.webapp.PREVIOUS_JSP_ID_SET", previousJspIdSet = new HashSet());
		if (!$assertionsDisabled && null == previousJspIdSet)
			throw new AssertionError();
		if (previousJspIdSet.contains(id) && !isIncludedOrForwarded())
		{
			if (log.isLoggable(Level.FINEST))
				log.log(Level.FINEST, (new StringBuilder()).append("Id ").append(id).append(" is nested within an iterating tag.").toString());
			isNestedInIterator = true;
		} else
		{
			isNestedInIterator = false;
			previousJspIdSet.add(id);
		}
	}

	private boolean isIncludedOrForwarded()
	{
		return getFacesContext().getExternalContext().getRequestMap().containsKey("javax.servlet.include.request_uri");
	}

	public String getJspId()
	{
		return jspId;
	}

	protected abstract void setProperties(UIComponent uicomponent);

	protected abstract UIComponent createComponent(FacesContext facescontext, String s)
		throws JspException;

	protected abstract boolean hasBinding();

	public UIComponent getComponentInstance()
	{
		return component;
	}

	public boolean getCreated()
	{
		return created;
	}

	protected FacesContext getFacesContext()
	{
		if (context == null && null == (context = (FacesContext)pageContext.getAttribute("javax.faces.webapp.CURRENT_FACES_CONTEXT")))
		{
			context = FacesContext.getCurrentInstance();
			if (context == null)
				throw new RuntimeException("Cannot find FacesContext");
			pageContext.setAttribute("javax.faces.webapp.CURRENT_FACES_CONTEXT", context);
		}
		return context;
	}

	protected String getFacetName()
	{
		Tag parent = getParent();
		if (parent instanceof FacetTag)
			return ((FacetTag)parent).getName();
		else
			return null;
	}

	private static void printTree(UIComponent root, String duplicateId, Writer out, int curDepth)
	{
		if (null == root)
			return;
		if (duplicateId.equals(root.getId()))
			indentPrintln(out, (new StringBuilder()).append("+id: ").append(root.getId()).append("  <===============").toString(), curDepth);
		else
			indentPrintln(out, (new StringBuilder()).append("+id: ").append(root.getId()).toString(), curDepth);
		indentPrintln(out, (new StringBuilder()).append(" type: ").append(root.toString()).toString(), curDepth);
		curDepth++;
		UIComponent uiComponent;
		for (Iterator i$ = root.getFacets().values().iterator(); i$.hasNext(); printTree(uiComponent, duplicateId, out, curDepth))
			uiComponent = (UIComponent)i$.next();

		UIComponent uiComponent;
		for (Iterator i$ = root.getChildren().iterator(); i$.hasNext(); printTree(uiComponent, duplicateId, out, curDepth))
			uiComponent = (UIComponent)i$.next();

	}

	private static void indentPrintln(Writer out, String str, int curDepth)
	{
		try
		{
			for (int i = 0; i < curDepth; i++)
				out.write("  ");

			out.write((new StringBuilder()).append(str).append("\n").toString());
		}
		catch (IOException ex) { }
	}

	private UIComponent getNamingContainer(UIComponent component)
	{
		for (UIComponent namingContainer = component; namingContainer != null; namingContainer = namingContainer.getParent())
			if (namingContainer instanceof NamingContainer)
				return namingContainer;

		return null;
	}

}
