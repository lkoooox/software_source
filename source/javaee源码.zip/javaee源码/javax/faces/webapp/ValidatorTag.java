// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ValidatorTag.java

package javax.faces.webapp;

import javax.el.ExpressionFactory;
import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.component.EditableValueHolder;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

// Referenced classes of package javax.faces.webapp:
//			UIComponentClassicTagBase, UIComponentTag

/**
 * @deprecated Class ValidatorTag is deprecated
 */

public class ValidatorTag extends TagSupport
{

	private static final long serialVersionUID = 0xb2cd974b37cd30ecL;
	private String validatorId;
	private String binding;

	public ValidatorTag()
	{
		validatorId = null;
		binding = null;
	}

	public void setValidatorId(String validatorId)
	{
		this.validatorId = validatorId;
	}

	public void setBinding(String binding)
		throws JspException
	{
		if (binding != null && !UIComponentTag.isValueReference(binding))
		{
			throw new JspException((new StringBuilder()).append("Invalid Expression:").append(binding).toString());
		} else
		{
			this.binding = binding;
			return;
		}
	}

	public int doStartTag()
		throws JspException
	{
		Validator validator = null;
		UIComponentClassicTagBase tag = UIComponentTag.getParentUIComponentClassicTagBase(pageContext);
		if (tag == null)
			throw new JspException((new StringBuilder()).append("Not nested in a UIComponentTag Error for tag with handler class:").append(getClass().getName()).toString());
		if (!tag.getCreated())
			return 0;
		javax.faces.component.UIComponent component = tag.getComponentInstance();
		if (component == null)
			throw new JspException("Can't create Component from tag.");
		if (!(component instanceof EditableValueHolder))
			throw new JspException((new StringBuilder()).append("Not nested in a tag of proper type. Error for tag with handler class:").append(getClass().getName()).toString());
		validator = createValidator();
		if (validator == null)
		{
			String validateError = null;
			if (binding != null)
				validateError = binding;
			if (validatorId != null)
				if (validateError != null)
					validateError = (new StringBuilder()).append(validateError).append(" or ").append(validatorId).toString();
				else
					validateError = validatorId;
			throw new JspException((new StringBuilder()).append("Can't create class of type:javax.faces.validator.Validator from:").append(validateError).toString());
		} else
		{
			((EditableValueHolder)component).addValidator(validator);
			return 0;
		}
	}

	public void release()
	{
		id = null;
	}

	protected Validator createValidator()
		throws JspException
	{
		FacesContext context;
		Validator validator;
		ValueExpression vb;
		context = FacesContext.getCurrentInstance();
		validator = null;
		vb = null;
		if (binding == null)
			break MISSING_BLOCK_LABEL_74;
		vb = context.getApplication().getExpressionFactory().createValueExpression(context.getELContext(), binding, java/lang/Object);
		if (vb == null)
			break MISSING_BLOCK_LABEL_74;
		validator = (Validator)vb.getValue(context.getELContext());
		if (validator != null)
			return validator;
		break MISSING_BLOCK_LABEL_74;
		Exception e;
		e;
		throw new JspException(e);
		if (validatorId != null)
			try
			{
				String validatorIdVal = validatorId;
				if (UIComponentTag.isValueReference(validatorId))
				{
					ValueExpression idBinding = context.getApplication().getExpressionFactory().createValueExpression(context.getELContext(), validatorId, java/lang/Object);
					validatorIdVal = (String)idBinding.getValue(context.getELContext());
				}
				validator = context.getApplication().createValidator(validatorIdVal);
				if (validator != null && vb != null)
					vb.setValue(context.getELContext(), validator);
			}
			// Misplaced declaration of an exception variable
			catch (String validatorIdVal)
			{
				throw new JspException(validatorIdVal);
			}
		return validator;
	}
}
