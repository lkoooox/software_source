// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UIComponentELTag.java

package javax.faces.webapp;

import javax.el.*;
import javax.faces.FacesException;
import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;

// Referenced classes of package javax.faces.webapp:
//			UIComponentClassicTagBase

public abstract class UIComponentELTag extends UIComponentClassicTagBase
	implements Tag
{

	private ValueExpression binding;
	private ValueExpression rendered;

	public UIComponentELTag()
	{
		binding = null;
		rendered = null;
	}

	public void setBinding(ValueExpression binding)
		throws JspException
	{
		this.binding = binding;
	}

	protected boolean hasBinding()
	{
		return null != binding;
	}

	public void setRendered(ValueExpression rendered)
	{
		this.rendered = rendered;
	}

	protected ELContext getELContext()
	{
		FacesContext fc = getFacesContext();
		ELContext result = null;
		if (null != fc)
			result = fc.getELContext();
		return result;
	}

	public void release()
	{
		binding = null;
		rendered = null;
		super.release();
	}

	protected void setProperties(UIComponent component)
	{
		if (rendered != null)
			if (rendered.isLiteralText())
				try
				{
					component.setRendered(Boolean.valueOf(rendered.getExpressionString()).booleanValue());
				}
				catch (ELException e)
				{
					throw new FacesException(e);
				}
			else
				component.setValueExpression("rendered", rendered);
		if (getRendererType() != null)
			component.setRendererType(getRendererType());
	}

	protected UIComponent createComponent(FacesContext context, String newId)
		throws JspException
	{
		UIComponent component = null;
		Application application = context.getApplication();
		if (binding != null)
		{
			component = application.createComponent(binding, context, getComponentType());
			component.setValueExpression("binding", binding);
		} else
		{
			component = application.createComponent(getComponentType());
		}
		component.setId(newId);
		setProperties(component);
		return component;
	}
}
