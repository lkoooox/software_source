// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodExpressionActionListener.java

package javax.faces.event;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.el.ELException;
import javax.el.MethodExpression;
import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.event:
//			AbortProcessingException, ActionEvent, ActionListener

public class MethodExpressionActionListener
	implements ActionListener, StateHolder
{

	private static final Logger LOGGER = Logger.getLogger("javax.faces.event", "javax.faces.LogStrings");
	private MethodExpression methodExpression;
	private boolean isTransient;

	public MethodExpressionActionListener()
	{
		methodExpression = null;
	}

	public MethodExpressionActionListener(MethodExpression methodExpression)
	{
		this.methodExpression = null;
		this.methodExpression = methodExpression;
	}

	public void processAction(ActionEvent actionEvent)
		throws AbortProcessingException
	{
		if (actionEvent == null)
			throw new NullPointerException();
		try
		{
			FacesContext context = FacesContext.getCurrentInstance();
			javax.el.ELContext elContext = context.getELContext();
			methodExpression.invoke(elContext, new Object[] {
				actionEvent
			});
		}
		catch (ELException ee)
		{
			if (LOGGER.isLoggable(Level.SEVERE))
			{
				LOGGER.log(Level.SEVERE, "severe.event.exception_invoking_processaction", new Object[] {
					ee.getCause().getClass().getName(), methodExpression.getExpressionString(), actionEvent.getComponent().getId()
				});
				StringWriter writer = new StringWriter(1024);
				ee.getCause().printStackTrace(new PrintWriter(writer));
				LOGGER.severe(writer.toString());
			}
			throw new AbortProcessingException(ee.getMessage(), ee.getCause());
		}
	}

	public Object saveState(FacesContext context)
	{
		return ((Object) (new Object[] {
			methodExpression
		}));
	}

	public void restoreState(FacesContext context, Object state)
	{
		methodExpression = (MethodExpression)((Object[])(Object[])state)[0];
	}

	public boolean isTransient()
	{
		return isTransient;
	}

	public void setTransient(boolean newTransientValue)
	{
		isTransient = newTransientValue;
	}

}
