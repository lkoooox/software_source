// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ValueChangeListener.java

package javax.faces.event;


// Referenced classes of package javax.faces.event:
//			AbortProcessingException, FacesListener, ValueChangeEvent

public interface ValueChangeListener
	extends FacesListener
{

	public abstract void processValueChange(ValueChangeEvent valuechangeevent)
		throws AbortProcessingException;
}
