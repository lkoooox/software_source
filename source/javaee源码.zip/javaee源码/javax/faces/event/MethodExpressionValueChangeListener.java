// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodExpressionValueChangeListener.java

package javax.faces.event;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.faces.component.StateHolder;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.event:
//			AbortProcessingException, ValueChangeListener, ValueChangeEvent

public class MethodExpressionValueChangeListener
	implements ValueChangeListener, StateHolder
{

	private MethodExpression methodExpression;
	private boolean isTransient;

	public MethodExpressionValueChangeListener()
	{
		methodExpression = null;
	}

	public MethodExpressionValueChangeListener(MethodExpression methodExpression)
	{
		this.methodExpression = null;
		this.methodExpression = methodExpression;
	}

	public void processValueChange(ValueChangeEvent valueChangeEvent)
		throws AbortProcessingException
	{
		if (valueChangeEvent == null)
			throw new NullPointerException();
		try
		{
			FacesContext context = FacesContext.getCurrentInstance();
			javax.el.ELContext elContext = context.getELContext();
			methodExpression.invoke(elContext, new Object[] {
				valueChangeEvent
			});
		}
		catch (ELException ee)
		{
			throw new AbortProcessingException(ee.getMessage(), ee.getCause());
		}
	}

	public Object saveState(FacesContext context)
	{
		return ((Object) (new Object[] {
			methodExpression
		}));
	}

	public void restoreState(FacesContext context, Object state)
	{
		methodExpression = (MethodExpression)((Object[])(Object[])state)[0];
	}

	public boolean isTransient()
	{
		return isTransient;
	}

	public void setTransient(boolean newTransientValue)
	{
		isTransient = newTransientValue;
	}
}
