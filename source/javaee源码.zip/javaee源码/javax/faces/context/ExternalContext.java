// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExternalContext.java

package javax.faces.context;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.Principal;
import java.util.*;

public abstract class ExternalContext
{

	public static final String BASIC_AUTH = "BASIC";
	public static final String CLIENT_CERT_AUTH = "CLIENT_CERT";
	public static final String DIGEST_AUTH = "DIGEST";
	public static final String FORM_AUTH = "FORM";

	public ExternalContext()
	{
	}

	public abstract void dispatch(String s)
		throws IOException;

	public abstract String encodeActionURL(String s);

	public abstract String encodeNamespace(String s);

	public abstract String encodeResourceURL(String s);

	public abstract Map getApplicationMap();

	public abstract String getAuthType();

	public abstract Object getContext();

	public abstract String getInitParameter(String s);

	public abstract Map getInitParameterMap();

	public abstract String getRemoteUser();

	public abstract Object getRequest();

	public void setRequest(Object request)
	{
		ExternalContext impl = null;
		if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
		{
			impl.setRequest(request);
			return;
		} else
		{
			throw new UnsupportedOperationException();
		}
	}

	public void setRequestCharacterEncoding(String encoding)
		throws UnsupportedEncodingException
	{
		ExternalContext impl = null;
		if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
		{
			impl.setRequestCharacterEncoding(encoding);
			return;
		} else
		{
			throw new UnsupportedOperationException();
		}
	}

	public abstract String getRequestContextPath();

	public abstract Map getRequestCookieMap();

	public abstract Map getRequestHeaderMap();

	public abstract Map getRequestHeaderValuesMap();

	public abstract Locale getRequestLocale();

	public abstract Iterator getRequestLocales();

	public abstract Map getRequestMap();

	public abstract Map getRequestParameterMap();

	public abstract Iterator getRequestParameterNames();

	public abstract Map getRequestParameterValuesMap();

	public abstract String getRequestPathInfo();

	public abstract String getRequestServletPath();

	public String getRequestCharacterEncoding()
	{
		ExternalContext impl = null;
		if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
			return impl.getRequestCharacterEncoding();
		else
			throw new UnsupportedOperationException();
	}

	public String getRequestContentType()
	{
		ExternalContext impl = null;
		if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
			return impl.getRequestContentType();
		else
			throw new UnsupportedOperationException();
	}

	public String getResponseCharacterEncoding()
	{
		ExternalContext impl = null;
		if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
			return impl.getResponseCharacterEncoding();
		else
			throw new UnsupportedOperationException();
	}

	public String getResponseContentType()
	{
		ExternalContext impl = null;
		if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
			return impl.getResponseContentType();
		else
			throw new UnsupportedOperationException();
	}

	public abstract URL getResource(String s)
		throws MalformedURLException;

	public abstract InputStream getResourceAsStream(String s);

	public abstract Set getResourcePaths(String s);

	public abstract Object getResponse();

	public void setResponse(Object response)
	{
		ExternalContext impl = null;
		if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
		{
			impl.setResponse(response);
			return;
		} else
		{
			throw new UnsupportedOperationException();
		}
	}

	public void setResponseCharacterEncoding(String encoding)
	{
		ExternalContext impl = null;
		if (null != (impl = (ExternalContext)getRequestMap().get("com.sun.faces.ExternalContextImpl")))
		{
			impl.setResponseCharacterEncoding(encoding);
			return;
		} else
		{
			throw new UnsupportedOperationException();
		}
	}

	public abstract Object getSession(boolean flag);

	public abstract Map getSessionMap();

	public abstract Principal getUserPrincipal();

	public abstract boolean isUserInRole(String s);

	public abstract void log(String s);

	public abstract void log(String s, Throwable throwable);

	public abstract void redirect(String s)
		throws IOException;
}
