// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FacesContextFactory.java

package javax.faces.context;

import javax.faces.FacesException;
import javax.faces.lifecycle.Lifecycle;

// Referenced classes of package javax.faces.context:
//			FacesContext

public abstract class FacesContextFactory
{

	public FacesContextFactory()
	{
	}

	public abstract FacesContext getFacesContext(Object obj, Object obj1, Object obj2, Lifecycle lifecycle)
		throws FacesException;
}
