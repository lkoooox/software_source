// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ResponseWriterWrapper.java

package javax.faces.context;

import java.io.IOException;
import java.io.Writer;
import javax.faces.component.UIComponent;

// Referenced classes of package javax.faces.context:
//			ResponseWriter

public abstract class ResponseWriterWrapper extends ResponseWriter
{

	public ResponseWriterWrapper()
	{
	}

	protected abstract ResponseWriter getWrapped();

	public String getContentType()
	{
		return getWrapped().getContentType();
	}

	public String getCharacterEncoding()
	{
		return getWrapped().getCharacterEncoding();
	}

	public void flush()
		throws IOException
	{
		getWrapped().flush();
	}

	public void startDocument()
		throws IOException
	{
		getWrapped().startDocument();
	}

	public void endDocument()
		throws IOException
	{
		getWrapped().endDocument();
	}

	public void startElement(String name, UIComponent component)
		throws IOException
	{
		getWrapped().startElement(name, component);
	}

	public void endElement(String name)
		throws IOException
	{
		getWrapped().endElement(name);
	}

	public void writeAttribute(String name, Object value, String property)
		throws IOException
	{
		getWrapped().writeAttribute(name, value, property);
	}

	public void writeURIAttribute(String name, Object value, String property)
		throws IOException
	{
		getWrapped().writeURIAttribute(name, value, property);
	}

	public void writeComment(Object comment)
		throws IOException
	{
		getWrapped().writeComment(comment);
	}

	public void writeText(Object text, String property)
		throws IOException
	{
		getWrapped().writeText(text, property);
	}

	public void writeText(Object text, UIComponent component, String property)
		throws IOException
	{
		getWrapped().writeText(text, component, property);
	}

	public void writeText(char text[], int off, int len)
		throws IOException
	{
		getWrapped().writeText(text, off, len);
	}

	public ResponseWriter cloneWithWriter(Writer writer)
	{
		return getWrapped().cloneWithWriter(writer);
	}

	public void close()
		throws IOException
	{
		getWrapped().close();
	}

	public void write(char cbuf[], int off, int len)
		throws IOException
	{
		getWrapped().write(cbuf, off, len);
	}
}
