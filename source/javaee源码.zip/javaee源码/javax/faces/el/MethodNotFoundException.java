// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodNotFoundException.java

package javax.faces.el;


// Referenced classes of package javax.faces.el:
//			EvaluationException

/**
 * @deprecated Class MethodNotFoundException is deprecated
 */

public class MethodNotFoundException extends EvaluationException
{

	public MethodNotFoundException()
	{
	}

	public MethodNotFoundException(String message)
	{
		super(message);
	}

	public MethodNotFoundException(Throwable cause)
	{
		super(cause);
	}

	public MethodNotFoundException(String message, Throwable cause)
	{
		super(message, cause);
	}
}
