// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   EvaluationException.java

package javax.faces.el;

import javax.faces.FacesException;

/**
 * @deprecated Class EvaluationException is deprecated
 */

public class EvaluationException extends FacesException
{

	public EvaluationException()
	{
	}

	public EvaluationException(String message)
	{
		super(message);
	}

	public EvaluationException(Throwable cause)
	{
		super(cause);
	}

	public EvaluationException(String message, Throwable cause)
	{
		super(message, cause);
	}
}
