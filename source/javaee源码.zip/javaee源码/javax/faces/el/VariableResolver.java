// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   VariableResolver.java

package javax.faces.el;

import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.el:
//			EvaluationException

/**
 * @deprecated Class VariableResolver is deprecated
 */

public abstract class VariableResolver
{

	public VariableResolver()
	{
	}

	public abstract Object resolveVariable(FacesContext facescontext, String s)
		throws EvaluationException;
}
