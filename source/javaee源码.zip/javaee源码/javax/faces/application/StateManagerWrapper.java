// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   StateManagerWrapper.java

package javax.faces.application;

import java.io.IOException;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.application:
//			StateManager

public abstract class StateManagerWrapper extends StateManager
{

	public StateManagerWrapper()
	{
	}

	protected abstract StateManager getWrapped();

	public StateManager.SerializedView saveSerializedView(FacesContext context)
	{
		return getWrapped().saveSerializedView(context);
	}

	public Object saveView(FacesContext context)
	{
		return getWrapped().saveView(context);
	}

	protected Object getTreeStructureToSave(FacesContext context)
	{
		return getWrapped().getTreeStructureToSave(context);
	}

	protected Object getComponentStateToSave(FacesContext context)
	{
		return getWrapped().getComponentStateToSave(context);
	}

	public void writeState(FacesContext context, Object state)
		throws IOException
	{
		getWrapped().writeState(context, state);
	}

	public void writeState(FacesContext context, StateManager.SerializedView state)
		throws IOException
	{
		getWrapped().writeState(context, state);
	}

	public UIViewRoot restoreView(FacesContext context, String viewId, String renderKitId)
	{
		return getWrapped().restoreView(context, viewId, renderKitId);
	}

	protected UIViewRoot restoreTreeStructure(FacesContext context, String viewId, String renderKitId)
	{
		return getWrapped().restoreTreeStructure(context, viewId, renderKitId);
	}

	protected void restoreComponentState(FacesContext context, UIViewRoot viewRoot, String renderKitId)
	{
		getWrapped().restoreComponentState(context, viewRoot, renderKitId);
	}

	public boolean isSavingStateInClient(FacesContext context)
	{
		return getWrapped().isSavingStateInClient(context);
	}
}
