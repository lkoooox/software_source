// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ViewExpiredException.java

package javax.faces.application;

import javax.faces.FacesException;

public class ViewExpiredException extends FacesException
{

	private String viewId;

	public ViewExpiredException()
	{
		viewId = null;
	}

	public ViewExpiredException(String viewId)
	{
		this.viewId = null;
		this.viewId = viewId;
	}

	public ViewExpiredException(String message, String viewId)
	{
		super(message);
		this.viewId = null;
		this.viewId = viewId;
	}

	public ViewExpiredException(Throwable cause, String viewId)
	{
		super(cause);
		this.viewId = null;
		this.viewId = viewId;
	}

	public ViewExpiredException(String message, Throwable cause, String viewId)
	{
		super(message, cause);
		this.viewId = null;
		this.viewId = viewId;
	}

	public String getViewId()
	{
		return viewId;
	}

	public String getMessage()
	{
		if (viewId != null)
			return (new StringBuilder()).append("viewId:").append(viewId).append(" - ").append(super.getMessage()).toString();
		else
			return super.getMessage();
	}
}
