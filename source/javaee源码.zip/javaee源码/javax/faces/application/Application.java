// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Application.java

package javax.faces.application;

import java.util.*;
import javax.el.*;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.el.*;
import javax.faces.event.ActionListener;
import javax.faces.validator.Validator;

// Referenced classes of package javax.faces.application:
//			NavigationHandler, ViewHandler, StateManager

public abstract class Application
{

	public Application()
	{
	}

	public abstract ActionListener getActionListener();

	public abstract void setActionListener(ActionListener actionlistener);

	public abstract Locale getDefaultLocale();

	public abstract void setDefaultLocale(Locale locale);

	public abstract String getDefaultRenderKitId();

	public abstract void setDefaultRenderKitId(String s);

	public abstract String getMessageBundle();

	public abstract void setMessageBundle(String s);

	public abstract NavigationHandler getNavigationHandler();

	public abstract void setNavigationHandler(NavigationHandler navigationhandler);

	/**
	 * @deprecated Method getPropertyResolver is deprecated
	 */

	public abstract PropertyResolver getPropertyResolver();

	/**
	 * @deprecated Method setPropertyResolver is deprecated
	 */

	public abstract void setPropertyResolver(PropertyResolver propertyresolver);

	public ResourceBundle getResourceBundle(FacesContext ctx, String name)
	{
		Application impl = null;
		if (null != (impl = (Application)ctx.getExternalContext().getApplicationMap().get("com.sun.faces.ApplicationImpl")))
			return impl.getResourceBundle(ctx, name);
		else
			throw new UnsupportedOperationException();
	}

	/**
	 * @deprecated Method getVariableResolver is deprecated
	 */

	public abstract VariableResolver getVariableResolver();

	/**
	 * @deprecated Method setVariableResolver is deprecated
	 */

	public abstract void setVariableResolver(VariableResolver variableresolver);

	public void addELResolver(ELResolver resolver)
	{
		throw new UnsupportedOperationException();
	}

	public ELResolver getELResolver()
	{
		throw new UnsupportedOperationException();
	}

	public abstract ViewHandler getViewHandler();

	public abstract void setViewHandler(ViewHandler viewhandler);

	public abstract StateManager getStateManager();

	public abstract void setStateManager(StateManager statemanager);

	public abstract void addComponent(String s, String s1);

	public abstract UIComponent createComponent(String s)
		throws FacesException;

	/**
	 * @deprecated Method createComponent is deprecated
	 */

	public abstract UIComponent createComponent(ValueBinding valuebinding, FacesContext facescontext, String s)
		throws FacesException;

	public UIComponent createComponent(ValueExpression componentExpression, FacesContext context, String componentType)
		throws FacesException
	{
		if (null == componentExpression || null == context || null == componentType)
		{
			String message = "null parameters";
			message = (new StringBuilder()).append(message).append(" componentExpression ").append(componentExpression).append(" context ").append(context).append(" componentType ").append(componentType).toString();
			throw new NullPointerException(message);
		}
		Object result = null;
		boolean createOne = false;
		try
		{
			if (null != (result = componentExpression.getValue(context.getELContext())))
				createOne = !(result instanceof UIComponent);
			if (null == result || createOne)
			{
				result = createComponent(componentType);
				componentExpression.setValue(context.getELContext(), result);
			}
		}
		catch (ELException elex)
		{
			throw new FacesException(elex);
		}
		return (UIComponent)result;
	}

	public abstract Iterator getComponentTypes();

	public abstract void addConverter(String s, String s1);

	public abstract void addConverter(Class class1, String s);

	public abstract Converter createConverter(String s);

	public abstract Converter createConverter(Class class1);

	public abstract Iterator getConverterIds();

	public abstract Iterator getConverterTypes();

	public ExpressionFactory getExpressionFactory()
	{
		throw new UnsupportedOperationException();
	}

	public Object evaluateExpressionGet(FacesContext context, String expression, Class expectedType)
		throws ELException
	{
		throw new UnsupportedOperationException();
	}

	/**
	 * @deprecated Method createMethodBinding is deprecated
	 */

	public abstract MethodBinding createMethodBinding(String s, Class aclass[])
		throws ReferenceSyntaxException;

	public abstract Iterator getSupportedLocales();

	public abstract void setSupportedLocales(Collection collection);

	public void addELContextListener(ELContextListener listener)
	{
		throw new UnsupportedOperationException();
	}

	public void removeELContextListener(ELContextListener listener)
	{
		throw new UnsupportedOperationException();
	}

	public ELContextListener[] getELContextListeners()
	{
		throw new UnsupportedOperationException();
	}

	public abstract void addValidator(String s, String s1);

	public abstract Validator createValidator(String s)
		throws FacesException;

	public abstract Iterator getValidatorIds();

	/**
	 * @deprecated Method createValueBinding is deprecated
	 */

	public abstract ValueBinding createValueBinding(String s)
		throws ReferenceSyntaxException;
}
