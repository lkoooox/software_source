// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   StateManager.java

package javax.faces.application;

import java.io.IOException;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

public abstract class StateManager
{
	/**
	 * @deprecated Class SerializedView is deprecated
	 */

	public class SerializedView
	{

		private Object structure;
		private Object state;
		final StateManager this$0;

		public Object getStructure()
		{
			return structure;
		}

		public Object getState()
		{
			return state;
		}

		public SerializedView(Object newStructure, Object newState)
		{
			this$0 = StateManager.this;
			super();
			structure = null;
			state = null;
			structure = newStructure;
			state = newState;
		}
	}


	public static final String STATE_SAVING_METHOD_PARAM_NAME = "javax.faces.STATE_SAVING_METHOD";
	public static final String STATE_SAVING_METHOD_CLIENT = "client";
	public static final String STATE_SAVING_METHOD_SERVER = "server";
	private Boolean savingStateInClient;

	public StateManager()
	{
		savingStateInClient = null;
	}

	/**
	 * @deprecated Method saveSerializedView is deprecated
	 */

	public SerializedView saveSerializedView(FacesContext context)
	{
		return null;
	}

	public Object saveView(FacesContext context)
	{
		SerializedView view = saveSerializedView(context);
		Object stateArray[] = {
			view.getStructure(), view.getState()
		};
		return ((Object) (stateArray));
	}

	/**
	 * @deprecated Method getTreeStructureToSave is deprecated
	 */

	protected Object getTreeStructureToSave(FacesContext context)
	{
		return null;
	}

	/**
	 * @deprecated Method getComponentStateToSave is deprecated
	 */

	protected Object getComponentStateToSave(FacesContext context)
	{
		return null;
	}

	public void writeState(FacesContext context, Object state)
		throws IOException
	{
		if (null != state && state.getClass().isArray() && state.getClass().getComponentType().equals(java/lang/Object))
		{
			Object stateArray[] = (Object[])(Object[])state;
			if (2 == stateArray.length)
			{
				SerializedView view = new SerializedView(stateArray[0], stateArray[1]);
				writeState(context, view);
			}
		}
	}

	/**
	 * @deprecated Method writeState is deprecated
	 */

	public void writeState(FacesContext facescontext, SerializedView serializedview)
		throws IOException
	{
	}

	public abstract UIViewRoot restoreView(FacesContext facescontext, String s, String s1);

	/**
	 * @deprecated Method restoreTreeStructure is deprecated
	 */

	protected UIViewRoot restoreTreeStructure(FacesContext context, String viewId, String renderKitId)
	{
		return null;
	}

	/**
	 * @deprecated Method restoreComponentState is deprecated
	 */

	protected void restoreComponentState(FacesContext facescontext, UIViewRoot uiviewroot, String s)
	{
	}

	public boolean isSavingStateInClient(FacesContext context)
	{
		if (null != savingStateInClient)
			return savingStateInClient.booleanValue();
		savingStateInClient = Boolean.FALSE;
		String saveStateParam = context.getExternalContext().getInitParameter("javax.faces.STATE_SAVING_METHOD");
		if (saveStateParam != null && saveStateParam.equalsIgnoreCase("client"))
			savingStateInClient = Boolean.TRUE;
		return savingStateInClient.booleanValue();
	}
}
