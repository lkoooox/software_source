// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ValidatorException.java

package javax.faces.validator;

import javax.faces.FacesException;
import javax.faces.application.FacesMessage;

public class ValidatorException extends FacesException
{

	private FacesMessage message;

	public ValidatorException(FacesMessage message)
	{
		super(message.getSummary());
		this.message = message;
	}

	public ValidatorException(FacesMessage message, Throwable cause)
	{
		super(message.getSummary(), cause);
		this.message = message;
	}

	public FacesMessage getFacesMessage()
	{
		return message;
	}
}
