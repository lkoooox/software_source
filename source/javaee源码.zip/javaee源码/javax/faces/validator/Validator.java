// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Validator.java

package javax.faces.validator;

import java.util.EventListener;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.validator:
//			ValidatorException

public interface Validator
	extends EventListener
{

	/**
	 * @deprecated Field NOT_IN_RANGE_MESSAGE_ID is deprecated
	 */
	public static final String NOT_IN_RANGE_MESSAGE_ID = "javax.faces.validator.NOT_IN_RANGE";

	public abstract void validate(FacesContext facescontext, UIComponent uicomponent, Object obj)
		throws ValidatorException;
}
