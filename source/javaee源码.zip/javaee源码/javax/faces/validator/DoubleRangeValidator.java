// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DoubleRangeValidator.java

package javax.faces.validator;

import javax.faces.application.Application;
import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

// Referenced classes of package javax.faces.validator:
//			MessageFactory, Validator, ValidatorException

public class DoubleRangeValidator
	implements Validator, StateHolder
{

	public static final String VALIDATOR_ID = "javax.faces.DoubleRange";
	public static final String MAXIMUM_MESSAGE_ID = "javax.faces.validator.DoubleRangeValidator.MAXIMUM";
	public static final String MINIMUM_MESSAGE_ID = "javax.faces.validator.DoubleRangeValidator.MINIMUM";
	public static final String NOT_IN_RANGE_MESSAGE_ID = "javax.faces.validator.DoubleRangeValidator.NOT_IN_RANGE";
	public static final String TYPE_MESSAGE_ID = "javax.faces.validator.DoubleRangeValidator.TYPE";
	private double maximum;
	private boolean maximumSet;
	private double minimum;
	private boolean minimumSet;
	private boolean transientValue;

	public DoubleRangeValidator()
	{
		maximum = 1.7976931348623157E+308D;
		maximumSet = false;
		minimum = 4.9406564584124654E-324D;
		minimumSet = false;
		transientValue = false;
	}

	public DoubleRangeValidator(double maximum)
	{
		this.maximum = 1.7976931348623157E+308D;
		maximumSet = false;
		minimum = 4.9406564584124654E-324D;
		minimumSet = false;
		transientValue = false;
		setMaximum(maximum);
	}

	public DoubleRangeValidator(double maximum, double minimum)
	{
		this.maximum = 1.7976931348623157E+308D;
		maximumSet = false;
		this.minimum = 4.9406564584124654E-324D;
		minimumSet = false;
		transientValue = false;
		setMaximum(maximum);
		setMinimum(minimum);
	}

	public double getMaximum()
	{
		return maximum;
	}

	public void setMaximum(double maximum)
	{
		this.maximum = maximum;
		maximumSet = true;
	}

	public double getMinimum()
	{
		return minimum;
	}

	public void setMinimum(double minimum)
	{
		this.minimum = minimum;
		minimumSet = true;
	}

	public void validate(FacesContext context, UIComponent component, Object value)
		throws ValidatorException
	{
		if (context == null || component == null)
			throw new NullPointerException();
		if (value != null)
			try
			{
				double converted = doubleValue(value);
				if (maximumSet && converted > maximum)
					if (minimumSet)
						throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.DoubleRangeValidator.NOT_IN_RANGE", new Object[] {
							stringValue(component, new Double(minimum)), stringValue(component, new Double(maximum)), MessageFactory.getLabel(context, component)
						}));
					else
						throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.DoubleRangeValidator.MAXIMUM", new Object[] {
							stringValue(component, new Double(maximum)), MessageFactory.getLabel(context, component)
						}));
				if (minimumSet && converted < minimum)
					if (maximumSet)
						throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.DoubleRangeValidator.NOT_IN_RANGE", new Object[] {
							stringValue(component, new Double(minimum)), stringValue(component, new Double(maximum)), MessageFactory.getLabel(context, component)
						}));
					else
						throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.DoubleRangeValidator.MINIMUM", new Object[] {
							stringValue(component, new Double(minimum)), MessageFactory.getLabel(context, component)
						}));
			}
			catch (NumberFormatException e)
			{
				throw new ValidatorException(MessageFactory.getMessage(context, "javax.faces.validator.DoubleRangeValidator.TYPE", new Object[] {
					MessageFactory.getLabel(context, component)
				}));
			}
	}

	public boolean equals(Object otherObj)
	{
		if (!(otherObj instanceof DoubleRangeValidator))
		{
			return false;
		} else
		{
			DoubleRangeValidator other = (DoubleRangeValidator)otherObj;
			return maximum == other.maximum && minimum == other.minimum && maximumSet == other.maximumSet && minimumSet == other.minimumSet;
		}
	}

	public int hashCode()
	{
		int hashCode = (new Double(minimum)).hashCode() + (new Double(maximum)).hashCode() + Boolean.valueOf(minimumSet).hashCode() + Boolean.valueOf(maximumSet).hashCode();
		return hashCode;
	}

	private double doubleValue(Object attributeValue)
		throws NumberFormatException
	{
		if (attributeValue instanceof Number)
			return ((Number)attributeValue).doubleValue();
		else
			return Double.parseDouble(attributeValue.toString());
	}

	private String stringValue(UIComponent component, Double toConvert)
	{
		String result = null;
		Converter converter = null;
		FacesContext context = FacesContext.getCurrentInstance();
		converter = context.getApplication().createConverter("javax.faces.Number");
		result = converter.getAsString(context, component, toConvert);
		return result;
	}

	public Object saveState(FacesContext context)
	{
		Object values[] = new Object[4];
		values[0] = new Double(maximum);
		values[1] = maximumSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		values[2] = new Double(minimum);
		values[3] = minimumSet ? ((Object) (Boolean.TRUE)) : ((Object) (Boolean.FALSE));
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state)
	{
		Object values[] = (Object[])(Object[])state;
		maximum = ((Double)values[0]).doubleValue();
		maximumSet = ((Boolean)values[1]).booleanValue();
		minimum = ((Double)values[2]).doubleValue();
		minimumSet = ((Boolean)values[3]).booleanValue();
	}

	public boolean isTransient()
	{
		return transientValue;
	}

	public void setTransient(boolean transientValue)
	{
		this.transientValue = transientValue;
	}
}
