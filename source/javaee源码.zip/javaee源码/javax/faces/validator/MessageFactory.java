// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageFactory.java

package javax.faces.validator;

import java.text.MessageFormat;
import java.util.*;
import javax.el.ValueExpression;
import javax.faces.FactoryFinder;
import javax.faces.application.*;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

class MessageFactory
{
	static class BindingFacesMessage extends FacesMessage
	{

		private Locale locale;
		private Object parameters[];
		private Object resolvedParameters[];

		public String getSummary()
		{
			String pattern = super.getSummary();
			resolveBindings();
			return getFormattedString(pattern, resolvedParameters);
		}

		public String getDetail()
		{
			String pattern = super.getDetail();
			resolveBindings();
			return getFormattedString(pattern, resolvedParameters);
		}

		private void resolveBindings()
		{
			FacesContext context = null;
			if (parameters != null)
			{
				for (int i = 0; i < parameters.length; i++)
				{
					Object o = parameters[i];
					if (o instanceof ValueBinding)
					{
						if (context == null)
							context = FacesContext.getCurrentInstance();
						o = ((ValueBinding)o).getValue(context);
					}
					if (o instanceof ValueExpression)
					{
						if (context == null)
							context = FacesContext.getCurrentInstance();
						o = ((ValueExpression)o).getValue(context.getELContext());
					}
					if (o == null)
						o = "";
					resolvedParameters[i] = o;
				}

			}
		}

		private String getFormattedString(String msgtext, Object params[])
		{
			String localizedStr = null;
			if (params == null || msgtext == null)
				return msgtext;
			StringBuffer b = new StringBuffer(100);
			MessageFormat mf = new MessageFormat(msgtext);
			if (locale != null)
			{
				mf.setLocale(locale);
				b.append(mf.format(((Object) (params))));
				localizedStr = b.toString();
			}
			return localizedStr;
		}

		BindingFacesMessage(Locale locale, String messageFormat, String detailMessageFormat, Object parameters[])
		{
			super(messageFormat, detailMessageFormat);
			this.locale = locale;
			this.parameters = parameters;
			if (parameters != null)
				resolvedParameters = new Object[parameters.length];
		}
	}


	private MessageFactory()
	{
	}

	static transient FacesMessage getMessage(String messageId, Object params[])
	{
		Locale locale = null;
		FacesContext context = FacesContext.getCurrentInstance();
		if (context != null && context.getViewRoot() != null)
		{
			locale = context.getViewRoot().getLocale();
			if (locale == null)
				locale = Locale.getDefault();
		} else
		{
			locale = Locale.getDefault();
		}
		return getMessage(locale, messageId, params);
	}

	static transient FacesMessage getMessage(Locale locale, String messageId, Object params[])
	{
		String summary;
		String detail;
		ResourceBundle bundle;
		summary = null;
		detail = null;
		String bundleName;
		if (null != (bundleName = getApplication().getMessageBundle()) && null != (bundle = ResourceBundle.getBundle(bundleName, locale, getCurrentLoader(bundleName))))
			try
			{
				summary = bundle.getString(messageId);
				detail = bundle.getString((new StringBuilder()).append(messageId).append("_detail").toString());
			}
			catch (MissingResourceException e) { }
		if (null != summary)
			break MISSING_BLOCK_LABEL_151;
		bundle = ResourceBundle.getBundle("javax.faces.Messages", locale, getCurrentLoader(bundleName));
		if (null == bundle)
			throw new NullPointerException();
		summary = bundle.getString(messageId);
		if (null == summary)
			return null;
		try
		{
			detail = bundle.getString((new StringBuilder()).append(messageId).append("_detail").toString());
		}
		catch (MissingResourceException e) { }
		return new BindingFacesMessage(locale, summary, detail, params);
	}

	static transient FacesMessage getMessage(FacesContext context, String messageId, Object params[])
	{
		if (context == null || messageId == null)
			throw new NullPointerException((new StringBuilder()).append(" context ").append(context).append(" messageId ").append(messageId).toString());
		Locale locale;
		if (context.getViewRoot() != null)
			locale = context.getViewRoot().getLocale();
		else
			locale = Locale.getDefault();
		if (null == locale)
			throw new NullPointerException(" locale is null ");
		FacesMessage message = getMessage(locale, messageId, params);
		if (message != null)
		{
			return message;
		} else
		{
			locale = Locale.getDefault();
			return getMessage(locale, messageId, params);
		}
	}

	static Object getLabel(FacesContext context, UIComponent component)
	{
		Object o = component.getAttributes().get("label");
		if (o == null || (o instanceof String) && ((String)o).length() == 0)
			o = component.getValueExpression("label");
		if (o == null)
			o = component.getClientId(context);
		return o;
	}

	protected static Application getApplication()
	{
		FacesContext context = FacesContext.getCurrentInstance();
		if (context != null)
		{
			return FacesContext.getCurrentInstance().getApplication();
		} else
		{
			ApplicationFactory afactory = (ApplicationFactory)FactoryFinder.getFactory("javax.faces.application.ApplicationFactory");
			return afactory.getApplication();
		}
	}

	protected static ClassLoader getCurrentLoader(Object fallbackClass)
	{
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		if (loader == null)
			loader = fallbackClass.getClass().getClassLoader();
		return loader;
	}
}
