// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MethodExpressionValidator.java

package javax.faces.validator;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.faces.application.FacesMessage;
import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

// Referenced classes of package javax.faces.validator:
//			Validator, ValidatorException

public class MethodExpressionValidator
	implements Validator, StateHolder
{

	private MethodExpression methodExpression;
	private boolean transientValue;

	public MethodExpressionValidator()
	{
		methodExpression = null;
		transientValue = false;
	}

	public MethodExpressionValidator(MethodExpression methodExpression)
	{
		this.methodExpression = null;
		transientValue = false;
		this.methodExpression = methodExpression;
	}

	public void validate(FacesContext context, UIComponent component, Object value)
		throws ValidatorException
	{
		if (context == null || component == null)
			throw new NullPointerException();
		if (value != null)
			try
			{
				javax.el.ELContext elContext = context.getELContext();
				methodExpression.invoke(elContext, new Object[] {
					context, component, value
				});
			}
			catch (ELException ee)
			{
				Throwable e = ee.getCause();
				if (e instanceof ValidatorException)
				{
					throw (ValidatorException)e;
				} else
				{
					FacesMessage message = new FacesMessage(ee.getMessage());
					throw new ValidatorException(message, ee.getCause());
				}
			}
	}

	public Object saveState(FacesContext context)
	{
		Object values[] = new Object[1];
		values[0] = methodExpression;
		return ((Object) (values));
	}

	public void restoreState(FacesContext context, Object state)
	{
		Object values[] = (Object[])(Object[])state;
		methodExpression = (MethodExpression)values[0];
	}

	public boolean isTransient()
	{
		return transientValue;
	}

	public void setTransient(boolean transientValue)
	{
		this.transientValue = transientValue;
	}
}
