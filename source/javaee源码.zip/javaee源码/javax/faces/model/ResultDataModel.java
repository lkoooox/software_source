// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ResultDataModel.java

package javax.faces.model;

import java.util.SortedMap;
import javax.servlet.jsp.jstl.sql.Result;

// Referenced classes of package javax.faces.model:
//			DataModel, DataModelEvent, DataModelListener

public class ResultDataModel extends DataModel
{

	private int index;
	private Result result;
	private SortedMap rows[];

	public ResultDataModel()
	{
		this(null);
	}

	public ResultDataModel(Result result)
	{
		index = -1;
		this.result = null;
		rows = null;
		setWrappedData(result);
	}

	public boolean isRowAvailable()
	{
		if (result == null)
			return false;
		return index >= 0 && index < rows.length;
	}

	public int getRowCount()
	{
		if (result == null)
			return -1;
		else
			return rows.length;
	}

	public Object getRowData()
	{
		if (result == null)
			return null;
		if (!isRowAvailable())
			throw new IllegalArgumentException();
		else
			return rows[index];
	}

	public int getRowIndex()
	{
		return index;
	}

	public void setRowIndex(int rowIndex)
	{
		if (rowIndex < -1)
			throw new IllegalArgumentException();
		int old = index;
		index = rowIndex;
		if (result == null)
			return;
		DataModelListener listeners[] = getDataModelListeners();
		if (old != index && listeners != null)
		{
			Object rowData = null;
			if (isRowAvailable())
				rowData = getRowData();
			DataModelEvent event = new DataModelEvent(this, index, rowData);
			int n = listeners.length;
			for (int i = 0; i < n; i++)
				if (null != listeners[i])
					listeners[i].rowSelected(event);

		}
	}

	public Object getWrappedData()
	{
		return result;
	}

	public void setWrappedData(Object data)
	{
		if (data == null)
		{
			result = null;
			rows = null;
			setRowIndex(-1);
		} else
		{
			result = (Result)data;
			rows = result.getRows();
			index = -1;
			setRowIndex(0);
		}
	}
}
