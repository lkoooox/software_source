// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ActivationDataFlavor.java

package javax.activation;

import java.awt.datatransfer.DataFlavor;

// Referenced classes of package javax.activation:
//			MimeType, MimeTypeParseException

public class ActivationDataFlavor extends DataFlavor
{

	private String mimeType;
	private MimeType mimeObject;
	private String humanPresentableName;
	private Class representationClass;

	public ActivationDataFlavor(Class representationClass, String mimeType, String humanPresentableName)
	{
		super(mimeType, humanPresentableName);
		this.mimeType = null;
		mimeObject = null;
		this.humanPresentableName = null;
		this.representationClass = null;
		this.mimeType = mimeType;
		this.humanPresentableName = humanPresentableName;
		this.representationClass = representationClass;
	}

	public ActivationDataFlavor(Class representationClass, String humanPresentableName)
	{
		super(representationClass, humanPresentableName);
		mimeType = null;
		mimeObject = null;
		this.humanPresentableName = null;
		this.representationClass = null;
		mimeType = super.getMimeType();
		this.representationClass = representationClass;
		this.humanPresentableName = humanPresentableName;
	}

	public ActivationDataFlavor(String mimeType, String humanPresentableName)
	{
		super(mimeType, humanPresentableName);
		this.mimeType = null;
		mimeObject = null;
		this.humanPresentableName = null;
		representationClass = null;
		this.mimeType = mimeType;
		try
		{
			representationClass = Class.forName("java.io.InputStream");
		}
		catch (ClassNotFoundException ex) { }
		this.humanPresentableName = humanPresentableName;
	}

	public String getMimeType()
	{
		return mimeType;
	}

	public Class getRepresentationClass()
	{
		return representationClass;
	}

	public String getHumanPresentableName()
	{
		return humanPresentableName;
	}

	public void setHumanPresentableName(String humanPresentableName)
	{
		this.humanPresentableName = humanPresentableName;
	}

	public boolean equals(DataFlavor dataFlavor)
	{
		return isMimeTypeEqual(dataFlavor) && dataFlavor.getRepresentationClass() == representationClass;
	}

	public boolean isMimeTypeEqual(String mimeType)
	{
		MimeType mt = null;
		try
		{
			if (mimeObject == null)
				mimeObject = new MimeType(this.mimeType);
			mt = new MimeType(mimeType);
		}
		catch (MimeTypeParseException e) { }
		return mimeObject.match(mt);
	}

	/**
	 * @deprecated Method normalizeMimeTypeParameter is deprecated
	 */

	protected String normalizeMimeTypeParameter(String parameterName, String parameterValue)
	{
		return parameterValue;
	}

	/**
	 * @deprecated Method normalizeMimeType is deprecated
	 */

	protected String normalizeMimeType(String mimeType)
	{
		return mimeType;
	}
}
