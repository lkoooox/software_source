// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DataHandler.java

package javax.activation;

import java.awt.datatransfer.*;
import java.io.*;
import java.net.URL;

// Referenced classes of package javax.activation:
//			CommandInfo, CommandMap, DataContentHandler, DataContentHandlerFactory, 
//			DataHandlerDataSource, DataSource, DataSourceDataContentHandler, MimeType, 
//			MimeTypeParseException, ObjectDataContentHandler, SecuritySupport, URLDataSource, 
//			UnsupportedDataTypeException

public class DataHandler
	implements Transferable
{

	private DataSource dataSource;
	private DataSource objDataSource;
	private Object object;
	private String objectMimeType;
	private CommandMap currentCommandMap;
	private static final DataFlavor emptyFlavors[] = new DataFlavor[0];
	private DataFlavor transferFlavors[];
	private DataContentHandler dataContentHandler;
	private DataContentHandler factoryDCH;
	private static DataContentHandlerFactory factory = null;
	private DataContentHandlerFactory oldFactory;
	private String shortType;

	public DataHandler(DataSource ds)
	{
		dataSource = null;
		objDataSource = null;
		object = null;
		objectMimeType = null;
		currentCommandMap = null;
		transferFlavors = emptyFlavors;
		dataContentHandler = null;
		factoryDCH = null;
		oldFactory = null;
		shortType = null;
		dataSource = ds;
		oldFactory = factory;
	}

	public DataHandler(Object obj, String mimeType)
	{
		dataSource = null;
		objDataSource = null;
		object = null;
		objectMimeType = null;
		currentCommandMap = null;
		transferFlavors = emptyFlavors;
		dataContentHandler = null;
		factoryDCH = null;
		oldFactory = null;
		shortType = null;
		object = obj;
		objectMimeType = mimeType;
		oldFactory = factory;
	}

	public DataHandler(URL url)
	{
		dataSource = null;
		objDataSource = null;
		object = null;
		objectMimeType = null;
		currentCommandMap = null;
		transferFlavors = emptyFlavors;
		dataContentHandler = null;
		factoryDCH = null;
		oldFactory = null;
		shortType = null;
		dataSource = new URLDataSource(url);
		oldFactory = factory;
	}

	private synchronized CommandMap getCommandMap()
	{
		if (currentCommandMap != null)
			return currentCommandMap;
		else
			return CommandMap.getDefaultCommandMap();
	}

	public DataSource getDataSource()
	{
		if (dataSource == null)
		{
			if (objDataSource == null)
				objDataSource = new DataHandlerDataSource(this);
			return objDataSource;
		} else
		{
			return dataSource;
		}
	}

	public String getName()
	{
		if (dataSource != null)
			return dataSource.getName();
		else
			return null;
	}

	public String getContentType()
	{
		if (dataSource != null)
			return dataSource.getContentType();
		else
			return objectMimeType;
	}

	public InputStream getInputStream()
		throws IOException
	{
		InputStream ins = null;
		if (dataSource != null)
		{
			ins = dataSource.getInputStream();
		} else
		{
			DataContentHandler dch = getDataContentHandler();
			if (dch == null)
				throw new UnsupportedDataTypeException("no DCH for MIME type " + getBaseType());
			if ((dch instanceof ObjectDataContentHandler) && ((ObjectDataContentHandler)dch).getDCH() == null)
				throw new UnsupportedDataTypeException("no object DCH for MIME type " + getBaseType());
			final DataContentHandler fdch = dch;
			final PipedOutputStream pos = new PipedOutputStream();
			PipedInputStream pin = new PipedInputStream(pos);
			(new Thread(new Runnable() {

				public void run()
				{
label0:
					{
						try
						{
							fdch.writeTo(object, objectMimeType, pos);
						}
						catch (IOException e)
						{
							try
							{
								pos.close();
							}
							catch (IOException ie) { }
							break label0;
						}
						finally
						{
							try
							{
								pos.close();
							}
							catch (IOException ie) { }
							throw exception;
						}
						try
						{
							pos.close();
						}
						catch (IOException ie) { }
						break label0;
					}
				}

			
			{
				super();
			}
			}, "DataHandler.getInputStream")).start();
			ins = pin;
		}
		return ins;
	}

	public void writeTo(OutputStream os)
		throws IOException
	{
		InputStream is;
		byte data[];
		if (dataSource == null)
			break MISSING_BLOCK_LABEL_70;
		is = null;
		data = new byte[8192];
		is = dataSource.getInputStream();
		int bytes_read;
		while ((bytes_read = is.read(data)) > 0) 
			os.write(data, 0, bytes_read);
		is.close();
		is = null;
		break MISSING_BLOCK_LABEL_90;
		Exception exception;
		exception;
		is.close();
		is = null;
		throw exception;
		DataContentHandler dch = getDataContentHandler();
		dch.writeTo(object, objectMimeType, os);
	}

	public OutputStream getOutputStream()
		throws IOException
	{
		if (dataSource != null)
			return dataSource.getOutputStream();
		else
			return null;
	}

	public synchronized DataFlavor[] getTransferDataFlavors()
	{
		if (factory != oldFactory)
			transferFlavors = emptyFlavors;
		if (transferFlavors == emptyFlavors)
			transferFlavors = getDataContentHandler().getTransferDataFlavors();
		return transferFlavors;
	}

	public boolean isDataFlavorSupported(DataFlavor flavor)
	{
		DataFlavor lFlavors[] = getTransferDataFlavors();
		for (int i = 0; i < lFlavors.length; i++)
			if (lFlavors[i].equals(flavor))
				return true;

		return false;
	}

	public Object getTransferData(DataFlavor flavor)
		throws UnsupportedFlavorException, IOException
	{
		return getDataContentHandler().getTransferData(flavor, dataSource);
	}

	public synchronized void setCommandMap(CommandMap commandMap)
	{
		if (commandMap != currentCommandMap || commandMap == null)
		{
			transferFlavors = emptyFlavors;
			dataContentHandler = null;
			currentCommandMap = commandMap;
		}
	}

	public CommandInfo[] getPreferredCommands()
	{
		if (dataSource != null)
			return getCommandMap().getPreferredCommands(getBaseType(), dataSource);
		else
			return getCommandMap().getPreferredCommands(getBaseType());
	}

	public CommandInfo[] getAllCommands()
	{
		if (dataSource != null)
			return getCommandMap().getAllCommands(getBaseType(), dataSource);
		else
			return getCommandMap().getAllCommands(getBaseType());
	}

	public CommandInfo getCommand(String cmdName)
	{
		if (dataSource != null)
			return getCommandMap().getCommand(getBaseType(), cmdName, dataSource);
		else
			return getCommandMap().getCommand(getBaseType(), cmdName);
	}

	public Object getContent()
		throws IOException
	{
		if (object != null)
			return object;
		else
			return getDataContentHandler().getContent(getDataSource());
	}

	public Object getBean(CommandInfo cmdinfo)
	{
		Object bean = null;
		try
		{
			ClassLoader cld = null;
			cld = SecuritySupport.getContextClassLoader();
			if (cld == null)
				cld = getClass().getClassLoader();
			bean = cmdinfo.getCommandObject(this, cld);
		}
		catch (IOException e) { }
		catch (ClassNotFoundException e) { }
		return bean;
	}

	private synchronized DataContentHandler getDataContentHandler()
	{
		if (factory != oldFactory)
		{
			oldFactory = factory;
			factoryDCH = null;
			dataContentHandler = null;
			transferFlavors = emptyFlavors;
		}
		if (dataContentHandler != null)
			return dataContentHandler;
		String simpleMT = getBaseType();
		if (factoryDCH == null && factory != null)
			factoryDCH = factory.createDataContentHandler(simpleMT);
		if (factoryDCH != null)
			dataContentHandler = factoryDCH;
		if (dataContentHandler == null)
			if (dataSource != null)
				dataContentHandler = getCommandMap().createDataContentHandler(simpleMT, dataSource);
			else
				dataContentHandler = getCommandMap().createDataContentHandler(simpleMT);
		if (dataSource != null)
			dataContentHandler = new DataSourceDataContentHandler(dataContentHandler, dataSource);
		else
			dataContentHandler = new ObjectDataContentHandler(dataContentHandler, object, objectMimeType);
		return dataContentHandler;
	}

	private synchronized String getBaseType()
	{
		if (shortType == null)
		{
			String ct = getContentType();
			try
			{
				MimeType mt = new MimeType(ct);
				shortType = mt.getBaseType();
			}
			catch (MimeTypeParseException e)
			{
				shortType = ct;
			}
		}
		return shortType;
	}

	public static synchronized void setDataContentHandlerFactory(DataContentHandlerFactory newFactory)
	{
		if (factory != null)
			throw new Error("DataContentHandlerFactory already defined");
		SecurityManager security = System.getSecurityManager();
		if (security != null)
			try
			{
				security.checkSetFactory();
			}
			catch (SecurityException ex)
			{
				if ((javax.activation.DataHandler.class).getClassLoader() != newFactory.getClass().getClassLoader())
					throw ex;
			}
		factory = newFactory;
	}



}
