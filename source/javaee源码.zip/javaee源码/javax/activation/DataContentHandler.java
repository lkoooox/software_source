// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DataContentHandler.java

package javax.activation;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.io.OutputStream;

// Referenced classes of package javax.activation:
//			DataSource

public interface DataContentHandler
{

	public abstract DataFlavor[] getTransferDataFlavors();

	public abstract Object getTransferData(DataFlavor dataflavor, DataSource datasource)
		throws UnsupportedFlavorException, IOException;

	public abstract Object getContent(DataSource datasource)
		throws IOException;

	public abstract void writeTo(Object obj, String s, OutputStream outputstream)
		throws IOException;
}
