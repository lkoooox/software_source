// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FileTypeMap.java

package javax.activation;

import java.io.File;

// Referenced classes of package javax.activation:
//			MimetypesFileTypeMap

public abstract class FileTypeMap
{

	private static FileTypeMap defaultMap = null;

	public FileTypeMap()
	{
	}

	public abstract String getContentType(File file);

	public abstract String getContentType(String s);

	public static void setDefaultFileTypeMap(FileTypeMap map)
	{
		SecurityManager security = System.getSecurityManager();
		if (security != null)
			try
			{
				security.checkSetFactory();
			}
			catch (SecurityException ex)
			{
				if ((javax.activation.FileTypeMap.class).getClassLoader() != map.getClass().getClassLoader())
					throw ex;
			}
		defaultMap = map;
	}

	public static FileTypeMap getDefaultFileTypeMap()
	{
		if (defaultMap == null)
			defaultMap = new MimetypesFileTypeMap();
		return defaultMap;
	}

}
