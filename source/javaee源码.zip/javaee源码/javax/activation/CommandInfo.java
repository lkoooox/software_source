// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   CommandInfo.java

package javax.activation;

import java.beans.Beans;
import java.io.*;

// Referenced classes of package javax.activation:
//			CommandObject, DataHandler

public class CommandInfo
{

	private String verb;
	private String className;

	public CommandInfo(String verb, String className)
	{
		this.verb = verb;
		this.className = className;
	}

	public String getCommandName()
	{
		return verb;
	}

	public String getCommandClass()
	{
		return className;
	}

	public Object getCommandObject(DataHandler dh, ClassLoader loader)
		throws IOException, ClassNotFoundException
	{
		Object new_bean = null;
		new_bean = Beans.instantiate(loader, className);
		if (new_bean != null)
			if (new_bean instanceof CommandObject)
				((CommandObject)new_bean).setCommandContext(verb, dh);
			else
			if ((new_bean instanceof Externalizable) && dh != null)
			{
				java.io.InputStream is = dh.getInputStream();
				if (is != null)
					((Externalizable)new_bean).readExternal(new ObjectInputStream(is));
			}
		return new_bean;
	}
}
