// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MimeTypeParameterList.java

package javax.activation;

import java.util.Enumeration;
import java.util.Hashtable;

// Referenced classes of package javax.activation:
//			MimeTypeParseException

public class MimeTypeParameterList
{

	private Hashtable parameters;
	private static final String TSPECIALS = "()<>@,;:/[]?=\\\"";

	public MimeTypeParameterList()
	{
		parameters = new Hashtable();
	}

	public MimeTypeParameterList(String parameterList)
		throws MimeTypeParseException
	{
		parameters = new Hashtable();
		parse(parameterList);
	}

	protected void parse(String parameterList)
		throws MimeTypeParseException
	{
		if (parameterList == null)
			return;
		int length = parameterList.length();
		if (length <= 0)
			return;
		int i;
		char c;
		for (i = skipWhiteSpace(parameterList, 0); i < length && (c = parameterList.charAt(i)) == ';'; i = skipWhiteSpace(parameterList, i))
		{
			i++;
			i = skipWhiteSpace(parameterList, i);
			if (i >= length)
				return;
			int lastIndex = i;
			for (; i < length && isTokenChar(parameterList.charAt(i)); i++);
			String name = parameterList.substring(lastIndex, i).toLowerCase();
			i = skipWhiteSpace(parameterList, i);
			if (i >= length || parameterList.charAt(i) != '=')
				throw new MimeTypeParseException("Couldn't find the '=' that separates a parameter name from its value.");
			i++;
			i = skipWhiteSpace(parameterList, i);
			if (i >= length)
				throw new MimeTypeParseException("Couldn't find a value for parameter named " + name);
			c = parameterList.charAt(i);
			String value;
			if (c == '"')
			{
				if (++i >= length)
					throw new MimeTypeParseException("Encountered unterminated quoted parameter value.");
				lastIndex = i;
				for (; i < length; i++)
				{
					c = parameterList.charAt(i);
					if (c == '"')
						break;
					if (c == '\\')
						i++;
				}

				if (c != '"')
					throw new MimeTypeParseException("Encountered unterminated quoted parameter value.");
				value = unquote(parameterList.substring(lastIndex, i));
				i++;
			} else
			if (isTokenChar(c))
			{
				lastIndex = i;
				for (; i < length && isTokenChar(parameterList.charAt(i)); i++);
				value = parameterList.substring(lastIndex, i);
			} else
			{
				throw new MimeTypeParseException("Unexpected character encountered at index " + i);
			}
			parameters.put(name, value);
		}

		if (i < length)
			throw new MimeTypeParseException("More characters encountered in input than expected.");
		else
			return;
	}

	public int size()
	{
		return parameters.size();
	}

	public boolean isEmpty()
	{
		return parameters.isEmpty();
	}

	public String get(String name)
	{
		return (String)parameters.get(name.trim().toLowerCase());
	}

	public void set(String name, String value)
	{
		parameters.put(name.trim().toLowerCase(), value);
	}

	public void remove(String name)
	{
		parameters.remove(name.trim().toLowerCase());
	}

	public Enumeration getNames()
	{
		return parameters.keys();
	}

	public String toString()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.ensureCapacity(parameters.size() * 16);
		String key;
		for (Enumeration keys = parameters.keys(); keys.hasMoreElements(); buffer.append(quote((String)parameters.get(key))))
		{
			key = (String)keys.nextElement();
			buffer.append("; ");
			buffer.append(key);
			buffer.append('=');
		}

		return buffer.toString();
	}

	private static boolean isTokenChar(char c)
	{
		return c > ' ' && c < '\177' && "()<>@,;:/[]?=\\\"".indexOf(c) < 0;
	}

	private static int skipWhiteSpace(String rawdata, int i)
	{
		for (int length = rawdata.length(); i < length && Character.isWhitespace(rawdata.charAt(i)); i++);
		return i;
	}

	private static String quote(String value)
	{
		boolean needsQuotes = false;
		int length = value.length();
		for (int i = 0; i < length && !needsQuotes; i++)
			needsQuotes = !isTokenChar(value.charAt(i));

		if (needsQuotes)
		{
			StringBuffer buffer = new StringBuffer();
			buffer.ensureCapacity((int)((double)length * 1.5D));
			buffer.append('"');
			for (int i = 0; i < length; i++)
			{
				char c = value.charAt(i);
				if (c == '\\' || c == '"')
					buffer.append('\\');
				buffer.append(c);
			}

			buffer.append('"');
			return buffer.toString();
		} else
		{
			return value;
		}
	}

	private static String unquote(String value)
	{
		int valueLength = value.length();
		StringBuffer buffer = new StringBuffer();
		buffer.ensureCapacity(valueLength);
		boolean escaped = false;
		for (int i = 0; i < valueLength; i++)
		{
			char currentChar = value.charAt(i);
			if (!escaped && currentChar != '\\')
			{
				buffer.append(currentChar);
				continue;
			}
			if (escaped)
			{
				buffer.append(currentChar);
				escaped = false;
			} else
			{
				escaped = true;
			}
		}

		return buffer.toString();
	}
}
