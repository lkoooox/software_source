// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   WebParam.java

package javax.jws;

import java.lang.annotation.Annotation;

public interface WebParam
	extends Annotation
{
	public static final class Mode extends Enum
	{

		public static final Mode IN;
		public static final Mode OUT;
		public static final Mode INOUT;
		private static final Mode $VALUES[];

		public static final Mode[] values()
		{
			return (Mode[])$VALUES.clone();
		}

		public static Mode valueOf(String name)
		{
			return (Mode)Enum.valueOf(javax/jws/WebParam$Mode, name);
		}

		static 
		{
			IN = new Mode("IN", 0);
			OUT = new Mode("OUT", 1);
			INOUT = new Mode("INOUT", 2);
			$VALUES = (new Mode[] {
				IN, OUT, INOUT
			});
		}

		private Mode(String s, int i)
		{
			super(s, i);
		}
	}


	public abstract String name();

	public abstract String partName();

	public abstract String targetNamespace();

	public abstract Mode mode();

	public abstract boolean header();
}
