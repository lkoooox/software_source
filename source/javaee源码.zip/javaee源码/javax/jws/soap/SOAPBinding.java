// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SOAPBinding.java

package javax.jws.soap;

import java.lang.annotation.Annotation;

public interface SOAPBinding
	extends Annotation
{
	public static final class ParameterStyle extends Enum
	{

		public static final ParameterStyle BARE;
		public static final ParameterStyle WRAPPED;
		private static final ParameterStyle $VALUES[];

		public static final ParameterStyle[] values()
		{
			return (ParameterStyle[])$VALUES.clone();
		}

		public static ParameterStyle valueOf(String name)
		{
			return (ParameterStyle)Enum.valueOf(javax/jws/soap/SOAPBinding$ParameterStyle, name);
		}

		static 
		{
			BARE = new ParameterStyle("BARE", 0);
			WRAPPED = new ParameterStyle("WRAPPED", 1);
			$VALUES = (new ParameterStyle[] {
				BARE, WRAPPED
			});
		}

		private ParameterStyle(String s, int i)
		{
			super(s, i);
		}
	}

	public static final class Style extends Enum
	{

		public static final Style DOCUMENT;
		public static final Style RPC;
		private static final Style $VALUES[];

		public static final Style[] values()
		{
			return (Style[])$VALUES.clone();
		}

		public static Style valueOf(String name)
		{
			return (Style)Enum.valueOf(javax/jws/soap/SOAPBinding$Style, name);
		}

		static 
		{
			DOCUMENT = new Style("DOCUMENT", 0);
			RPC = new Style("RPC", 1);
			$VALUES = (new Style[] {
				DOCUMENT, RPC
			});
		}

		private Style(String s, int i)
		{
			super(s, i);
		}
	}

	public static final class Use extends Enum
	{

		public static final Use LITERAL;
		public static final Use ENCODED;
		private static final Use $VALUES[];

		public static final Use[] values()
		{
			return (Use[])$VALUES.clone();
		}

		public static Use valueOf(String name)
		{
			return (Use)Enum.valueOf(javax/jws/soap/SOAPBinding$Use, name);
		}

		static 
		{
			LITERAL = new Use("LITERAL", 0);
			ENCODED = new Use("ENCODED", 1);
			$VALUES = (new Use[] {
				LITERAL, ENCODED
			});
		}

		private Use(String s, int i)
		{
			super(s, i);
		}
	}


	public abstract Style style();

	public abstract Use use();

	public abstract ParameterStyle parameterStyle();
}
