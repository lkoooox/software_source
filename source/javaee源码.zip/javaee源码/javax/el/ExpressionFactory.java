// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExpressionFactory.java

package javax.el;


// Referenced classes of package javax.el:
//			ELContext, ValueExpression, MethodExpression

public abstract class ExpressionFactory
{

	public ExpressionFactory()
	{
	}

	public abstract ValueExpression createValueExpression(ELContext elcontext, String s, Class class1);

	public abstract ValueExpression createValueExpression(Object obj, Class class1);

	public abstract MethodExpression createMethodExpression(ELContext elcontext, String s, Class class1, Class aclass[]);

	public abstract Object coerceToType(Object obj, Class class1);
}
