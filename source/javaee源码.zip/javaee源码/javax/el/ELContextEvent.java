// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ELContextEvent.java

package javax.el;

import java.util.EventObject;

// Referenced classes of package javax.el:
//			ELContext

public class ELContextEvent extends EventObject
{

	public ELContextEvent(ELContext source)
	{
		super(source);
	}

	public ELContext getELContext()
	{
		return (ELContext)getSource();
	}
}
