// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ELException.java

package javax.el;


public class ELException extends RuntimeException
{

	public ELException()
	{
	}

	public ELException(String pMessage)
	{
		super(pMessage);
	}

	public ELException(Throwable pRootCause)
	{
		super(pRootCause);
	}

	public ELException(String pMessage, Throwable pRootCause)
	{
		super(pMessage, pRootCause);
	}
}
