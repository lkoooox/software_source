// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BeanELResolver.java

package javax.el;

import java.beans.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

// Referenced classes of package javax.el:
//			ELResolver, ELContext, ELException, ELUtil, 
//			PropertyNotFoundException, PropertyNotWritableException

public class BeanELResolver extends ELResolver
{
	protected static final class BeanProperties
	{

		private final Class baseClass;
		private final Map propertyMap = new HashMap();

		public BeanProperty getBeanProperty(String property)
		{
			return (BeanProperty)propertyMap.get(property);
		}

		public BeanProperties(Class baseClass)
		{
			this.baseClass = baseClass;
			PropertyDescriptor descriptors[];
			try
			{
				BeanInfo info = Introspector.getBeanInfo(baseClass);
				descriptors = info.getPropertyDescriptors();
			}
			catch (IntrospectionException ie)
			{
				throw new ELException(ie);
			}
			PropertyDescriptor arr$[] = descriptors;
			int len$ = arr$.length;
			for (int i$ = 0; i$ < len$; i$++)
			{
				PropertyDescriptor pd = arr$[i$];
				propertyMap.put(pd.getName(), new BeanProperty(baseClass, pd));
			}

		}
	}

	protected static final class BeanProperty
	{

		private Method readMethod;
		private Method writeMethod;
		private Class baseClass;
		private PropertyDescriptor descriptor;

		public Class getPropertyType()
		{
			return descriptor.getPropertyType();
		}

		public boolean isReadOnly()
		{
			return getWriteMethod() == null;
		}

		public Method getReadMethod()
		{
			if (readMethod == null)
				readMethod = BeanELResolver.getMethod(baseClass, descriptor.getReadMethod());
			return readMethod;
		}

		public Method getWriteMethod()
		{
			if (writeMethod == null)
				writeMethod = BeanELResolver.getMethod(baseClass, descriptor.getWriteMethod());
			return writeMethod;
		}

		public BeanProperty(Class baseClass, PropertyDescriptor descriptor)
		{
			this.baseClass = baseClass;
			this.descriptor = descriptor;
		}
	}


	private boolean isReadOnly;
	private static final int SIZE = 2000;
	private static final Map properties = new ConcurrentHashMap(2000);
	private static final Map properties2 = new ConcurrentHashMap(2000);

	public BeanELResolver()
	{
		isReadOnly = false;
	}

	public BeanELResolver(boolean isReadOnly)
	{
		this.isReadOnly = isReadOnly;
	}

	public Class getType(ELContext context, Object base, Object property)
	{
		if (context == null)
			throw new NullPointerException();
		if (base == null || property == null)
		{
			return null;
		} else
		{
			BeanProperty bp = getBeanProperty(context, base, property);
			context.setPropertyResolved(true);
			return bp.getPropertyType();
		}
	}

	public Object getValue(ELContext context, Object base, Object property)
	{
		if (context == null)
			throw new NullPointerException();
		if (base == null || property == null)
			return null;
		BeanProperty bp = getBeanProperty(context, base, property);
		Method method = bp.getReadMethod();
		if (method == null)
			throw new PropertyNotFoundException(ELUtil.getExceptionMessageString(context, "propertyNotReadable", new Object[] {
				base.getClass().getName(), property.toString()
			}));
		Object value;
		try
		{
			value = method.invoke(base, new Object[0]);
			context.setPropertyResolved(true);
		}
		catch (ELException ex)
		{
			throw ex;
		}
		catch (InvocationTargetException ite)
		{
			throw new ELException(ite.getCause());
		}
		catch (Exception ex)
		{
			throw new ELException(ex);
		}
		return value;
	}

	public void setValue(ELContext context, Object base, Object property, Object val)
	{
		if (context == null)
			throw new NullPointerException();
		if (base == null || property == null)
			return;
		if (isReadOnly)
			throw new PropertyNotWritableException(ELUtil.getExceptionMessageString(context, "resolverNotwritable", new Object[] {
				base.getClass().getName()
			}));
		BeanProperty bp = getBeanProperty(context, base, property);
		Method method = bp.getWriteMethod();
		if (method == null)
			throw new PropertyNotWritableException(ELUtil.getExceptionMessageString(context, "propertyNotWritable", new Object[] {
				base.getClass().getName(), property.toString()
			}));
		try
		{
			method.invoke(base, new Object[] {
				val
			});
			context.setPropertyResolved(true);
		}
		catch (ELException ex)
		{
			throw ex;
		}
		catch (InvocationTargetException ite)
		{
			throw new ELException(ite.getCause());
		}
		catch (Exception ex)
		{
			if (null == val)
				val = "null";
			String message = ELUtil.getExceptionMessageString(context, "setPropertyFailed", new Object[] {
				property.toString(), base.getClass().getName(), val
			});
			throw new ELException(message, ex);
		}
	}

	public boolean isReadOnly(ELContext context, Object base, Object property)
	{
		if (context == null)
			throw new NullPointerException();
		if (base == null || property == null)
			return false;
		context.setPropertyResolved(true);
		if (isReadOnly)
		{
			return true;
		} else
		{
			BeanProperty bp = getBeanProperty(context, base, property);
			return bp.isReadOnly();
		}
	}

	public Iterator getFeatureDescriptors(ELContext context, Object base)
	{
		if (base == null)
			return null;
		BeanInfo info = null;
		try
		{
			info = Introspector.getBeanInfo(base.getClass());
		}
		catch (Exception ex) { }
		if (info == null)
			return null;
		ArrayList list = new ArrayList(info.getPropertyDescriptors().length);
		PropertyDescriptor arr$[] = info.getPropertyDescriptors();
		int len$ = arr$.length;
		for (int i$ = 0; i$ < len$; i$++)
		{
			PropertyDescriptor pd = arr$[i$];
			pd.setValue("type", pd.getPropertyType());
			pd.setValue("resolvableAtDesignTime", Boolean.TRUE);
			list.add(pd);
		}

		return list.iterator();
	}

	public Class getCommonPropertyType(ELContext context, Object base)
	{
		if (base == null)
			return null;
		else
			return java/lang/Object;
	}

	private static Method getMethod(Class cl, Method method)
	{
		Class interfaces[];
		int i;
		if (Modifier.isPublic(cl.getModifiers()))
			return method;
		interfaces = cl.getInterfaces();
		i = 0;
_L3:
		if (i >= interfaces.length) goto _L2; else goto _L1
_L1:
		Class c;
		Method m;
		c = interfaces[i];
		m = null;
		m = c.getMethod(method.getName(), method.getParameterTypes());
		c = m.getDeclaringClass();
		if ((m = getMethod(c, m)) != null)
			return m;
		continue; /* Loop/switch isn't completed */
		NoSuchMethodException ex;
		ex;
		i++;
		  goto _L3
_L2:
		Class c;
		Method m;
		c = cl.getSuperclass();
		if (c == null)
			break MISSING_BLOCK_LABEL_134;
		m = null;
		m = c.getMethod(method.getName(), method.getParameterTypes());
		c = m.getDeclaringClass();
		if ((m = getMethod(c, m)) != null)
			return m;
		break MISSING_BLOCK_LABEL_134;
		NoSuchMethodException ex;
		ex;
		return null;
	}

	private BeanProperty getBeanProperty(ELContext context, Object base, Object prop)
	{
		String property = prop.toString();
		Class baseClass = base.getClass();
		BeanProperties bps = (BeanProperties)properties.get(baseClass);
		if (bps == null && (bps = (BeanProperties)properties2.get(baseClass)) == null)
		{
			if (properties.size() > 2000)
			{
				properties2.clear();
				properties2.putAll(properties);
				properties.clear();
			}
			bps = new BeanProperties(baseClass);
			properties.put(baseClass, bps);
		}
		BeanProperty bp = bps.getBeanProperty(property);
		if (bp == null)
			throw new PropertyNotFoundException(ELUtil.getExceptionMessageString(context, "propertyNotFound", new Object[] {
				baseClass.getName(), property
			}));
		else
			return bp;
	}


}
