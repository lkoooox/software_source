// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ResourceBundleELResolver.java

package javax.el;

import java.beans.FeatureDescriptor;
import java.util.*;

// Referenced classes of package javax.el:
//			ELResolver, ELContext, PropertyNotWritableException

public class ResourceBundleELResolver extends ELResolver
{

	public ResourceBundleELResolver()
	{
	}

	public Object getValue(ELContext context, Object base, Object property)
	{
		if (context == null)
			throw new NullPointerException();
		if (!(base instanceof ResourceBundle))
			break MISSING_BLOCK_LABEL_67;
		context.setPropertyResolved(true);
		if (property == null)
			break MISSING_BLOCK_LABEL_67;
		return ((ResourceBundle)base).getObject(property.toString());
		MissingResourceException e;
		e;
		return (new StringBuilder()).append("???").append(property).append("???").toString();
		return null;
	}

	public Class getType(ELContext context, Object base, Object property)
	{
		if (context == null)
			throw new NullPointerException();
		if (base instanceof ResourceBundle)
			context.setPropertyResolved(true);
		return null;
	}

	public void setValue(ELContext context, Object base, Object property, Object value)
	{
		if (context == null)
			throw new NullPointerException();
		if (base instanceof ResourceBundle)
		{
			context.setPropertyResolved(true);
			throw new PropertyNotWritableException("ResourceBundles are immutable");
		} else
		{
			return;
		}
	}

	public boolean isReadOnly(ELContext context, Object base, Object property)
	{
		if (context == null)
			throw new NullPointerException();
		if (base instanceof ResourceBundle)
		{
			context.setPropertyResolved(true);
			return true;
		} else
		{
			return false;
		}
	}

	public Iterator getFeatureDescriptors(ELContext context, Object base)
	{
		if (base instanceof ResourceBundle)
		{
			ResourceBundle bundle = (ResourceBundle)base;
			List features = new ArrayList();
			String key = null;
			FeatureDescriptor desc = null;
			for (Enumeration e = bundle.getKeys(); e.hasMoreElements(); features.add(desc))
			{
				key = (String)e.nextElement();
				desc = new FeatureDescriptor();
				desc.setDisplayName(key);
				desc.setExpert(false);
				desc.setHidden(false);
				desc.setName(key);
				desc.setPreferred(true);
				desc.setValue("type", java/lang/String);
				desc.setValue("resolvableAtDesignTime", Boolean.TRUE);
			}

			return features.iterator();
		} else
		{
			return null;
		}
	}

	public Class getCommonPropertyType(ELContext context, Object base)
	{
		if (base instanceof ResourceBundle)
			return java/lang/String;
		else
			return null;
	}
}
