// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Expression.java

package javax.el;

import java.io.Serializable;

public abstract class Expression
	implements Serializable
{

	public Expression()
	{
	}

	public abstract String getExpressionString();

	public abstract boolean equals(Object obj);

	public abstract int hashCode();

	public abstract boolean isLiteralText();
}
