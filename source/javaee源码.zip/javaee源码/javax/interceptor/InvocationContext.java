// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   InvocationContext.java

package javax.interceptor;

import java.lang.reflect.Method;
import java.util.Map;

public interface InvocationContext
{

	public abstract Object getTarget();

	public abstract Method getMethod();

	public abstract Object[] getParameters();

	public abstract void setParameters(Object aobj[]);

	public abstract Map getContextData();

	public abstract Object proceed()
		throws Exception;
}
