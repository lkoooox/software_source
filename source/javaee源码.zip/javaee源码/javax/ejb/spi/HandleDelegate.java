// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   HandleDelegate.java

package javax.ejb.spi;

import java.io.*;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;

public interface HandleDelegate
{

	public abstract void writeEJBObject(EJBObject ejbobject, ObjectOutputStream objectoutputstream)
		throws IOException;

	public abstract EJBObject readEJBObject(ObjectInputStream objectinputstream)
		throws IOException, ClassNotFoundException;

	public abstract void writeEJBHome(EJBHome ejbhome, ObjectOutputStream objectoutputstream)
		throws IOException;

	public abstract EJBHome readEJBHome(ObjectInputStream objectinputstream)
		throws IOException, ClassNotFoundException;
}
