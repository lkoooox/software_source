// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageDriven.java

package javax.ejb;

import java.lang.annotation.Annotation;

// Referenced classes of package javax.ejb:
//			ActivationConfigProperty

public interface MessageDriven
	extends Annotation
{

	public abstract String name();

	public abstract Class messageListenerInterface();

	public abstract ActivationConfigProperty[] activationConfig();

	public abstract String mappedName();

	public abstract String description();
}
