// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransactionAttributeType.java

package javax.ejb;


public final class TransactionAttributeType extends Enum
{

	public static final TransactionAttributeType MANDATORY;
	public static final TransactionAttributeType REQUIRED;
	public static final TransactionAttributeType REQUIRES_NEW;
	public static final TransactionAttributeType SUPPORTS;
	public static final TransactionAttributeType NOT_SUPPORTED;
	public static final TransactionAttributeType NEVER;
	private static final TransactionAttributeType $VALUES[];

	public static final TransactionAttributeType[] values()
	{
		return (TransactionAttributeType[])$VALUES.clone();
	}

	public static TransactionAttributeType valueOf(String name)
	{
		return (TransactionAttributeType)Enum.valueOf(javax/ejb/TransactionAttributeType, name);
	}

	private TransactionAttributeType(String s, int i)
	{
		super(s, i);
	}

	static 
	{
		MANDATORY = new TransactionAttributeType("MANDATORY", 0);
		REQUIRED = new TransactionAttributeType("REQUIRED", 1);
		REQUIRES_NEW = new TransactionAttributeType("REQUIRES_NEW", 2);
		SUPPORTS = new TransactionAttributeType("SUPPORTS", 3);
		NOT_SUPPORTED = new TransactionAttributeType("NOT_SUPPORTED", 4);
		NEVER = new TransactionAttributeType("NEVER", 5);
		$VALUES = (new TransactionAttributeType[] {
			MANDATORY, REQUIRED, REQUIRES_NEW, SUPPORTS, NOT_SUPPORTED, NEVER
		});
	}
}
