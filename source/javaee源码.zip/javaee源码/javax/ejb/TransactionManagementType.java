// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransactionManagementType.java

package javax.ejb;


public final class TransactionManagementType extends Enum
{

	public static final TransactionManagementType CONTAINER;
	public static final TransactionManagementType BEAN;
	private static final TransactionManagementType $VALUES[];

	public static final TransactionManagementType[] values()
	{
		return (TransactionManagementType[])$VALUES.clone();
	}

	public static TransactionManagementType valueOf(String name)
	{
		return (TransactionManagementType)Enum.valueOf(javax/ejb/TransactionManagementType, name);
	}

	private TransactionManagementType(String s, int i)
	{
		super(s, i);
	}

	static 
	{
		CONTAINER = new TransactionManagementType("CONTAINER", 0);
		BEAN = new TransactionManagementType("BEAN", 1);
		$VALUES = (new TransactionManagementType[] {
			CONTAINER, BEAN
		});
	}
}
