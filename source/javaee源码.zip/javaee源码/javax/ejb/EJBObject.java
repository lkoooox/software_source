// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   EJBObject.java

package javax.ejb;

import java.rmi.Remote;
import java.rmi.RemoteException;

// Referenced classes of package javax.ejb:
//			RemoveException, EJBHome, Handle

public interface EJBObject
	extends Remote
{

	public abstract EJBHome getEJBHome()
		throws RemoteException;

	public abstract Object getPrimaryKey()
		throws RemoteException;

	public abstract void remove()
		throws RemoteException, RemoveException;

	public abstract Handle getHandle()
		throws RemoteException;

	public abstract boolean isIdentical(EJBObject ejbobject)
		throws RemoteException;
}
