// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TimerHandle.java

package javax.ejb;

import java.io.Serializable;

// Referenced classes of package javax.ejb:
//			EJBException, NoSuchObjectLocalException, Timer

public interface TimerHandle
	extends Serializable
{

	public abstract Timer getTimer()
		throws IllegalStateException, NoSuchObjectLocalException, EJBException;
}
